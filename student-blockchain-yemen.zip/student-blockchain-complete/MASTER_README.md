# 🎓 نظام التحقق من بيانات الطلاب باستخدام البلوك تشين
# Student Verification System using Blockchain

[![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)](https://github.com)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen.svg)](https://nodejs.org)
[![React](https://img.shields.io/badge/react-18.2.0-blue.svg)](https://reactjs.org)

---

## 📦 محتويات المشروع - Project Contents

```
student-blockchain-complete/
├── 📁 api/                          # Backend REST API
│   ├── src/
│   │   ├── controllers/             # HTTP Request Handlers
│   │   ├── services/                # Business Logic
│   │   ├── middleware/              # Auth & Validation
│   │   └── routes/                  # API Routes
│   └── config/                      # Configuration
│
├── 📁 frontend/                     # React Frontend  ✨ NEW
│   ├── src/
│   │   ├── components/              # Reusable Components
│   │   ├── pages/                   # Page Components
│   │   │   ├── Login.js            # Login Page
│   │   │   ├── Dashboard.js        # Dashboard
│   │   │   ├── StudentList.js      # Students List
│   │   │   ├── StudentCreate.js    # Create Student
│   │   │   ├── StudentView.js      # View Student
│   │   │   ├── TransferList.js     # Transfers List
│   │   │   └── TransferCreate.js   # Create Transfer
│   │   ├── context/                 # React Context
│   │   └── services/                # API Services
│   └── public/                      # Static Files
│
├── 📁 chaincode/                    # Smart Contracts
│   └── student-records/             # Student Records Chaincode
│
├── 📁 network/                      # Blockchain Network Config
│   ├── docker-compose-ministry.yml  # Ministry Containers
│   ├── docker-compose-univ1.yml     # University 1
│   ├── docker-compose-univ2.yml     # University 2
│   └── scripts/                     # Setup Scripts
│
└── 📁 docs/                         # Documentation
    ├── API.md
    ├── ARCHITECTURE.md
    └── ARABIC_EXPLANATION.md
```

---

## 🚀 سيناريوهات الاستخدام - Usage Scenarios

### 🔹 السيناريو 1: تجربة سريعة (جهاز واحد)

**للاختبار السريع بدون VMs:**

```powershell
# 1. فك الضغط
Expand-Archive student-blockchain-complete.zip -DestinationPath C:\blockchain

# 2. تشغيل API
cd C:\blockchain\student-blockchain-complete\api
npm install
copy .env.example .env
npm start

# 3. تشغيل Frontend (terminal جديد)
cd C:\blockchain\student-blockchain-complete\frontend
npm install
npm start
```

**📖 راجع:** `QUICK_START_WINDOWS.md`

---

### 🔹 السيناريو 2: نشر كامل (Host + 2 VMs)

**للنشر الكامل على 3 أجهزة:**

1. **Host (الوزارة)** - Ministry + Orderer
2. **VM1 (جامعة 1)** - Peer + API + Frontend
3. **VM2 (جامعة 2)** - Peer + API + Frontend

**📖 راجع:** `COMPLETE_DEPLOYMENT_GUIDE.md`

---

## ⚡ البدء السريع - Quick Start

### المتطلبات:
- ✅ Windows 10/11
- ✅ Node.js 18+
- ✅ Docker Desktop (للنشر الكامل)
- ✅ 8GB RAM
- ✅ 50GB Disk Space

### التثبيت السريع:

```powershell
# تثبيت البرامج المطلوبة
winget install Docker.DockerDesktop
winget install OpenJS.NodeJS.LTS

# فك الضغط والتشغيل
Expand-Archive student-blockchain-complete.zip
cd student-blockchain-complete

# API
cd api && npm install && npm start

# Frontend (terminal جديد)
cd frontend && npm install && npm start
```

---

## 🎯 الميزات - Features

### ✅ Phase 1 (Complete):
- Smart Contracts (Hyperledger Fabric)
- Backend REST API
- Authentication & Authorization
- Student CRUD Operations
- Transfer Workflow
- Audit Trail

### ✨ Phase 2 (NEW - Complete):
- **React Frontend** with Material-UI
- **Login Page** with JWT authentication
- **Dashboard** with statistics
- **Student Management** (List, Create, View)
- **Transfer Management** (List, Create, Approve)
- **Responsive Design** (Desktop + Mobile)
- **Real-time Updates** with React Hooks
- **Arabic RTL Support**

---

## 🖥️ واجهات المستخدم - User Interfaces

### 1. صفحة تسجيل الدخول - Login Page
```
- تصميم احترافي وسهل
- دعم عربي كامل
- مصادقة JWT آمنة
```

### 2. لوحة التحكم - Dashboard
```
- إحصائيات فورية
- عرض سريع للبيانات
- تنقل سهل
```

### 3. إدارة الطلاب - Student Management
```
- قائمة الطلاب مع بحث وفلترة
- إضافة طالب جديد
- عرض وتعديل البيانات
- سجل التعديلات
```

### 4. إدارة النقل - Transfer Management
```
- طلب نقل بين الجامعات
- الموافقة على الطلبات
- تتبع حالة النقل
```

---

## 👥 المستخدمون الافتراضيون - Default Users

| الجهاز | Username | Password | Role | Port |
|--------|----------|----------|------|------|
| Host (Ministry) | admin | admin123 | Admin | 3000/3001 |
| VM1 (Univ1) | univ1_admin | univ1_123 | Univ Admin | 3001/3002 |
| VM2 (Univ2) | univ2_admin | univ2_123 | Univ Admin | 3002/3003 |

---

## 📝 الأدلة المتوفرة - Available Guides

1. **QUICK_START_WINDOWS.md** ⚡
   - للبدء السريع على جهاز واحد
   - اختبار النظام بسرعة
   - 10 دقائق

2. **COMPLETE_DEPLOYMENT_GUIDE.md** 📚
   - نشر كامل على 3 أجهزة
   - إعداد Fabric Network
   - ساعة واحدة

3. **API.md** 🔌
   - توثيق كامل للـ API
   - أمثلة على الاستخدام
   - جميع Endpoints

4. **ARCHITECTURE.md** 🏗️
   - البنية المعمارية
   - Clean Code Principles
   - Best Practices

5. **ARABIC_EXPLANATION.md** 🇸🇦
   - شرح مفصل بالعربية
   - أمثلة عملية
   - مفاهيم البلوك تشين

---

## 🔧 الأوامر المفيدة - Useful Commands

### API:
```powershell
cd api
npm install          # تثبيت
npm start           # تشغيل عادي
npm run dev         # تشغيل تطوير
npm test            # اختبار
```

### Frontend:
```powershell
cd frontend
npm install          # تثبيت
npm start           # تشغيل (http://localhost:3001)
npm run build       # بناء للإنتاج
npm test            # اختبار
```

### Docker:
```powershell
docker-compose up -d              # تشغيل
docker-compose down               # إيقاف
docker-compose logs -f            # السجلات
docker ps                         # الحاويات النشطة
```

---

## 🌐 URLs and Ports

### Single Machine:
- API: `http://localhost:3000`
- Frontend: `http://localhost:3001`

### Multi-Machine (Example IPs):
```
Host (Ministry):
- API: http://192.168.1.100:3000
- Frontend: http://192.168.1.100:3001

VM1 (University 1):
- API: http://192.168.1.101:3001
- Frontend: http://192.168.1.101:3002

VM2 (University 2):
- API: http://192.168.1.102:3002
- Frontend: http://192.168.1.102:3003
```

---

## 🎨 التقنيات المستخدمة - Technologies

### Backend:
- Node.js 18+
- Express.js
- Hyperledger Fabric SDK
- JWT Authentication
- Bcrypt

### Frontend (NEW):
- React 18.2
- Material-UI (MUI) 5
- React Router v6
- Axios
- React Toastify
- Formik & Yup

### Blockchain:
- Hyperledger Fabric 2.x
- CouchDB
- Docker & Docker Compose

---

## 🔒 الأمان - Security

- ✅ JWT Token Authentication
- ✅ Role-Based Access Control (RBAC)
- ✅ Password Hashing (Bcrypt)
- ✅ Input Validation
- ✅ Rate Limiting
- ✅ HTTPS Ready
- ✅ Digital Signatures (Blockchain)
- ✅ Encrypted Sensitive Data

---

## 🧪 الاختبار - Testing

### Test API:
```powershell
# Login
curl -X POST http://localhost:3000/api/auth/login -H "Content-Type: application/json" -d "{\"username\":\"admin\",\"password\":\"admin123\"}"

# Create Student  
curl -X POST http://localhost:3000/api/students -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"nationalId\":\"1234567890\",\"fullName\":\"أحمد محمد\",\"college\":\"الحاسب\",\"major\":\"علوم حاسب\",\"dateOfBirth\":\"2000-01-01\",\"enrollmentDate\":\"2020-09-01\"}"
```

### Test Frontend:
1. افتح `http://localhost:3001`
2. سجل دخول بـ `admin` / `admin123`
3. جرب إضافة طالب
4. جرب البحث والعرض

---

## 📊 الإحصائيات - Statistics

### Project Size:
- **Total Files:** 50+
- **Lines of Code:** 5000+
- **Components:** 20+
- **API Endpoints:** 15+
- **Smart Contract Functions:** 8+

### Documentation:
- **Guides:** 5 comprehensive guides
- **Languages:** Arabic + English
- **Pages:** 100+ pages

---

## 🚧 استكشاف الأخطاء - Troubleshooting

### مشكلة: npm install يفشل
```powershell
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

### مشكلة: Port مستخدم
```powershell
# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### مشكلة: Frontend لا يتصل بالـ API
```
تحقق من:
1. API يعمل على Port 3000
2. ملف .env صحيح
3. CORS مفعّل
```

---

## 📈 الخطوات القادمة - Next Steps

### للطلاب:
1. ✅ اقرأ التوثيق
2. ✅ جرب النظام
3. ✅ افهم الكود
4. ✅ حضّر العرض

### للتطوير المستقبلي:
- [ ] Mobile App (React Native)
- [ ] Real-time Notifications
- [ ] Advanced Analytics
- [ ] File Upload
- [ ] Bulk Operations
- [ ] Export Reports
- [ ] Multi-language Support

---

## 🤝 المساهمة - Contributing

للمساهمة في المشروع:
1. Fork the repository
2. Create feature branch
3. Make changes
4. Submit pull request

---

## 📞 الدعم - Support

### للمساعدة:
- 📧 Email: your.email@example.com
- 📱 Phone: +966-XXX-XXXX
- 🌐 GitHub: github.com/your-repo

### الموارد المفيدة:
- [Hyperledger Fabric Docs](https://hyperledger-fabric.readthedocs.io/)
- [React Documentation](https://react.dev/)
- [Material-UI Docs](https://mui.com/)
- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)

---

## 📜 الترخيص - License

MIT License - انظر ملف [LICENSE](LICENSE)

---

## 🏆 Credits

- **المطور:** [اسمك]
- **المشرف:** [اسم المشرف]
- **الجامعة:** [اسم الجامعة]
- **السنة:** 2024

---

## ⭐ Star the Project

إذا أعجبك المشروع، لا تنسى إضافة نجمة ⭐

---

**Made with ❤️ for Education**

**Last Updated:** November 2024
**Version:** 2.0.0 - Complete with Frontend ✨

---

## 🎉 ملخص التحديثات - Update Summary

### Version 2.0.0 (NEW):
- ✨ Complete React Frontend
- ✨ Material-UI Design System
- ✨ All CRUD Operations with GUI
- ✨ Authentication & Authorization UI
- ✨ Responsive Design
- ✨ Arabic RTL Support
- ✨ Real-time Updates
- ✨ Toast Notifications
- ✨ Form Validation
- ✨ Error Handling

### Version 1.0.0:
- ✅ Smart Contracts
- ✅ Backend API
- ✅ Documentation
- ✅ Clean Code Architecture

---

**🚀 المشروع جاهز للعرض والتطبيق!**
