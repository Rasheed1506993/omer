# 🚀 دليل النشر الشامل - Complete Deployment Guide

## نظرة عامة - Overview

هذا الدليل يشرح كيفية نشر نظام التحقق من بيانات الطلاب على:
- **Host Machine (الوزارة)** - Ministry Organization  
- **VM1 (جامعة 1)** - University 1
- **VM2 (جامعة 2)** - University 2

---

## البنية المعمارية - Architecture

```
┌────────────────────────────────────────┐
│   Host Machine (Ministry)              │
│   - Orderer Node                       │
│   - CA Server                          │
│   - API Server                         │
│   - Frontend                           │
│   IP: 192.168.1.100                    │
└────────────────────────────────────────┘
              │
              │
    ┌─────────┴──────────┐
    │                    │
┌───▼──────────┐   ┌────▼─────────┐
│ VM1 (Univ1)  │   │ VM2 (Univ2)  │
│ - Peer Node  │   │ - Peer Node  │
│ - CouchDB    │   │ - CouchDB    │
│ - API        │   │ - API        │
│ - Frontend   │   │ - Frontend   │
│ 192.168.1.101│   │ 192.168.1.102│
└──────────────┘   └──────────────┘
```

---

## المتطلبات - Prerequisites

### لكل جهاز (Host + VMs):

1. **نظام التشغيل:**
   - Windows 10/11 Pro or Server
   - أو Windows with WSL2

2. **البرامج المطلوبة:**
   ```powershell
   # Docker Desktop for Windows
   winget install Docker.DockerDesktop
   
   # Node.js 18+
   winget install OpenJS.NodeJS.LTS
   
   # Git
   winget install Git.Git
   ```

3. **المتطلبات الأساسية:**
   - RAM: 8GB minimum
   - Disk: 50GB free space
   - Network: Same subnet

---

## الخطوة 1: إعداد الشبكة - Network Setup

### على Host (الوزارة):

```powershell
# 1. فك ضغط المشروع
Expand-Archive -Path student-blockchain-complete.zip -DestinationPath C:\blockchain

# 2. الانتقال إلى المجلد
cd C:\blockchain\student-blockchain-complete

# 3. تعديل ملف الإعدادات
notepad network\.env

# أضف:
MINISTRY_IP=192.168.1.100
UNIV1_IP=192.168.1.101
UNIV2_IP=192.168.1.102
```

### على VM1 و VM2:

نفس الخطوات، فقط قم بتعديل الـ IPs حسب الجهاز.

---

## الخطوة 2: إنشاء شبكة Fabric - Create Fabric Network

### على Host فقط:

```powershell
cd C:\blockchain\student-blockchain-complete\network

# 1. توليد الشهادات
.\scripts\generate-certs.bat

# 2. إنشاء القناة
.\scripts\create-channel.bat

# 3. نشر العقود الذكية
.\scripts\deploy-chaincode.bat
```

هذا سيقوم بـ:
- ✅ إنشاء شهادات لجميع الأطراف
- ✅ إنشاء قناة blockchain
- ✅ نشر smart contracts

---

## الخطوة 3: تشغيل الـ Docker Containers

### على Host (Ministry):

```powershell
cd network
docker-compose -f docker-compose-ministry.yml up -d

# تحقق من الحالة
docker ps
```

يجب أن ترى:
- orderer.ministry.com
- ca.ministry.com

### على VM1 (University 1):

```powershell
cd network
docker-compose -f docker-compose-univ1.yml up -d

# تحقق
docker ps
```

يجب أن ترى:
- peer0.univ1.com
- couchdb.univ1
- ca.univ1.com

### على VM2 (University 2):

```powershell
cd network
docker-compose -f docker-compose-univ2.yml up -d
```

---

## الخطوة 4: إعداد وتشغيل API

### على كل جهاز (Host + VM1 + VM2):

```powershell
cd C:\blockchain\student-blockchain-complete\api

# 1. نسخ ملف البيئة
copy .env.example .env

# 2. تعديل الإعدادات
notepad .env

# للـ Host (Ministry):
PORT=3000
MSP_ID=MinistryMSP
USER_ID=admin

# للـ VM1:
PORT=3001
MSP_ID=Univ1MSP
USER_ID=admin

# للـ VM2:
PORT=3002
MSP_ID=Univ2MSP
USER_ID=admin

# 3. تثبيت المكتبات
npm install

# 4. تشغيل الخادم
npm start
```

---

## الخطوة 5: إعداد وتشغيل Frontend

### على كل جهاز:

```powershell
cd C:\blockchain\student-blockchain-complete\frontend

# 1. تثبيت المكتبات
npm install

# 2. تعديل ملف البيئة
notepad .env

# للـ Host:
REACT_APP_API_URL=http://localhost:3000

# للـ VM1:
REACT_APP_API_URL=http://localhost:3001

# للـ VM2:
REACT_APP_API_URL=http://localhost:3002

# 3. تشغيل التطبيق
npm start
```

سيفتح المتصفح تلقائياً على `http://localhost:3001`

---

## الخطوة 6: اختبار النظام

### 1. تسجيل الدخول

على كل واجهة، استخدم:

**للوزارة (Host):**
- Username: `admin`
- Password: `admin123`

**للجامعة 1 (VM1):**
- Username: `univ1_admin`
- Password: `univ1_123`

**للجامعة 2 (VM2):**
- Username: `univ2_admin`
- Password: `univ2_123`

### 2. إنشاء طالب

من واجهة جامعة 1:
1. اذهب إلى "الطلاب"
2. اضغط "إضافة طالب"
3. املأ البيانات
4. احفظ

### 3. طلب نقل

من واجهة جامعة 2:
1. اذهب إلى "النقل"
2. اضغط "طلب نقل"
3. أدخل معرف الطالب
4. اختر من جامعة 1
5. أرسل الطلب

### 4. الموافقة على النقل

من واجهة جامعة 1:
1. اذهب إلى "النقل"
2. ستجد طلب معلق
3. اضغط "موافقة"

من واجهة الوزارة:
1. اذهب إلى "النقل"
2. اضغط "موافقة نهائية"
3. سيتم النقل تلقائياً

---

## استكشاف الأخطاء - Troubleshooting

### مشكلة: Docker لا يعمل

```powershell
# تأكد من تشغيل Docker Desktop
Get-Service docker
Start-Service docker
```

### مشكلة: لا يمكن الاتصال بين الأجهزة

```powershell
# تحقق من الـ Firewall
New-NetFirewallRule -DisplayName "Blockchain" -Direction Inbound -Port 7050-7060 -Protocol TCP -Action Allow

# اختبار الاتصال
Test-NetConnection -ComputerName 192.168.1.100 -Port 7050
```

### مشكلة: API لا يستجيب

```powershell
# تحقق من السجلات
cd api
npm run dev

# تحقق من البورت
netstat -ano | findstr :3000
```

---

## الأوامر المفيدة - Useful Commands

### Docker

```powershell
# عرض الحاويات
docker ps

# إيقاف جميع الحاويات
docker-compose down

# عرض السجلات
docker logs orderer.ministry.com

# حذف كل شيء والبدء من جديد
docker-compose down -v
docker system prune -a
```

### Blockchain

```powershell
# التحقق من القناة
docker exec peer0.univ1.com peer channel list

# التحقق من Chaincode
docker exec peer0.univ1.com peer chaincode list --installed
```

---

## البيانات الافتراضية - Default Data

### المستخدمون:

| المستخدم | كلمة المرور | الدور | الجامعة |
|---------|-------------|------|---------|
| admin | admin123 | Admin | Ministry |
| univ1_admin | univ1_123 | University Admin | UNIV1 |
| univ2_admin | univ2_123 | University Admin | UNIV2 |
| univ1_registrar | reg123 | Registrar | UNIV1 |
| univ2_registrar | reg123 | Registrar | UNIV2 |

---

## الصيانة - Maintenance

### النسخ الاحتياطي

```powershell
# نسخ احتياطي للبيانات
docker exec peer0.univ1.com tar -czf /tmp/ledger.tar.gz /var/hyperledger/production

docker cp peer0.univ1.com:/tmp/ledger.tar.gz ./backup/
```

### التحديث

```powershell
# تحديث Chaincode
cd network
.\scripts\update-chaincode.bat

# إعادة تشغيل API
cd api
npm restart
```

---

## الأمان - Security

### نصائح مهمة:

1. **غير كلمات المرور** في بيئة الإنتاج
2. **فعّل HTTPS** لجميع الاتصالات
3. **استخدم Firewall** لحماية البورتات
4. **راقب السجلات** باستمرار
5. **حدّث البرامج** بانتظام

---

## المراقبة - Monitoring

### استخدم هذه الأدوات:

```powershell
# مراقبة استخدام الموارد
docker stats

# مراقبة السجلات
docker-compose logs -f

# مراقبة الشبكة
netstat -an | findstr "LISTEN"
```

---

## الدعم - Support

للمساعدة:
1. راجع السجلات أولاً
2. تحقق من الاتصال بالشبكة
3. راجع التوثيق
4. اتصل بالدعم الفني

---

**ملاحظة:** هذا دليل مبسط لـ PoC. في بيئة الإنتاج، ستحتاج إلى:
- شهادات SSL حقيقية
- Load balancers
- Backup systems
- Monitoring tools
- Security hardening

---

**تم بنجاح! 🎉**
