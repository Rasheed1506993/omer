# Quick Start Guide - دليل البدء السريع

## English Version

### Prerequisites
1. Node.js (v18 or higher)
2. npm (v8 or higher)
3. Docker & Docker Compose (for full Fabric network)

### Installation Steps

```bash
# 1. Clone the repository
git clone <your-repo-url>
cd student-verification-blockchain

# 2. Install all dependencies
npm run install:all

# 3. Start the API server (without Fabric for testing)
cd api
cp .env.example .env
npm run dev

# 4. Test the API
curl http://localhost:3000/api/health
```

### Testing the API

#### 1. Login
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }'
```

Save the `accessToken` from the response.

#### 2. Create a Student
```bash
curl -X POST http://localhost:3000/api/students \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -d '{
    "nationalId": "1234567890",
    "fullName": "أحمد محمد علي",
    "fullNameEn": "Ahmed Mohammed Ali",
    "dateOfBirth": "2000-05-15",
    "college": "College of Computer Science",
    "major": "Computer Science",
    "enrollmentDate": "2020-09-01",
    "email": "ahmed@example.com",
    "phone": "+966501234567"
  }'
```

#### 3. Get Student
```bash
curl -X GET http://localhost:3000/api/students/STU001 \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### Available Endpoints

- `POST /api/auth/login` - Login
- `GET /api/auth/profile` - Get user profile
- `POST /api/students` - Create student
- `GET /api/students/:id` - Get student
- `PUT /api/students/:id` - Update student
- `GET /api/students/:id/history` - Get student history
- `POST /api/transfers` - Request transfer
- `PUT /api/transfers/:id/approve` - Approve transfer

### Default Users

| Username | Password | Role | University |
|----------|----------|------|------------|
| admin | admin123 | admin | MINISTRY |
| ksu_admin | ksu123 | university_admin | UNI001 |
| ksu_registrar | registrar123 | registrar | UNI001 |

---

## النسخة العربية

### المتطلبات الأساسية
1. Node.js (الإصدار 18 أو أحدث)
2. npm (الإصدار 8 أو أحدث)
3. Docker و Docker Compose (لشبكة Fabric كاملة)

### خطوات التثبيت

```bash
# 1. نسخ المشروع
git clone <your-repo-url>
cd student-verification-blockchain

# 2. تثبيت جميع المكتبات
npm run install:all

# 3. تشغيل خادم API (بدون Fabric للاختبار)
cd api
cp .env.example .env
npm run dev

# 4. اختبار الـ API
curl http://localhost:3000/api/health
```

### اختبار الـ API

#### 1. تسجيل الدخول
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }'
```

احفظ الـ `accessToken` من النتيجة.

#### 2. إنشاء طالب
```bash
curl -X POST http://localhost:3000/api/students \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -d '{
    "nationalId": "1234567890",
    "fullName": "أحمد محمد علي",
    "fullNameEn": "Ahmed Mohammed Ali",
    "dateOfBirth": "2000-05-15",
    "college": "كلية علوم الحاسب",
    "major": "علوم الحاسب",
    "enrollmentDate": "2020-09-01",
    "email": "ahmed@example.com",
    "phone": "+966501234567"
  }'
```

#### 3. الحصول على بيانات الطالب
```bash
curl -X GET http://localhost:3000/api/students/STU001 \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### المسارات المتاحة

- `POST /api/auth/login` - تسجيل الدخول
- `GET /api/auth/profile` - الحصول على معلومات المستخدم
- `POST /api/students` - إنشاء طالب
- `GET /api/students/:id` - الحصول على بيانات طالب
- `PUT /api/students/:id` - تحديث بيانات طالب
- `GET /api/students/:id/history` - الحصول على سجل التعديلات
- `POST /api/transfers` - طلب نقل طالب
- `PUT /api/transfers/:id/approve` - الموافقة على النقل

### المستخدمون الافتراضيون

| اسم المستخدم | كلمة المرور | الدور | الجامعة |
|--------------|-------------|--------|----------|
| admin | admin123 | مدير | الوزارة |
| ksu_admin | ksu123 | مدير جامعة | جامعة الملك سعود |
| ksu_registrar | registrar123 | مسجل | جامعة الملك سعود |

---

## Project Structure

```
student-verification-blockchain/
├── api/                    # Backend REST API
│   ├── src/
│   │   ├── controllers/   # HTTP handlers
│   │   ├── services/      # Business logic
│   │   ├── middleware/    # Authentication, validation
│   │   └── routes/        # API routes
│   └── config/            # Configuration
│
├── chaincode/             # Smart Contracts
│   └── student-records/   # Student records chaincode
│       └── lib/           # Contract implementation
│
├── network/               # Blockchain network config
│   ├── configtx/         # Channel configuration
│   ├── crypto-config/    # Certificates
│   └── docker/           # Docker compose files
│
├── frontend/              # React Frontend (to be implemented)
│   └── src/
│
└── docs/                  # Documentation
    ├── API.md            # API documentation
    ├── ARCHITECTURE.md   # Architecture details
    └── ARABIC_EXPLANATION.md  # Detailed Arabic explanation
```

---

## Next Steps

1. **Complete Frontend Development**
   - Build React components
   - Integrate with API
   - Add authentication

2. **Setup Fabric Network**
   - Configure organizations
   - Deploy chaincode
   - Test with real blockchain

3. **Add More Features**
   - File uploads
   - Advanced search
   - Analytics dashboard
   - Notifications

4. **Testing**
   - Unit tests
   - Integration tests
   - E2E tests

5. **Deployment**
   - Setup production environment
   - Configure CI/CD
   - Deploy to cloud

---

## Troubleshooting

### Port Already in Use
```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9
```

### Module Not Found
```bash
# Reinstall dependencies
rm -rf node_modules
npm install
```

### Database Issues
```bash
# Reset user database
rm api/data/users.json
# Restart API (will recreate with default users)
```

---

## Resources

- [Hyperledger Fabric Documentation](https://hyperledger-fabric.readthedocs.io/)
- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)
- [React Documentation](https://react.dev/)
- [Clean Code Principles](https://github.com/ryanmcdermott/clean-code-javascript)

---

## Support

For questions or issues:
- Email: your.email@example.com
- GitHub Issues: [Create an issue](https://github.com/yourusername/student-verification-blockchain/issues)

---

Made with ❤️ for Education
