'use strict';

const transferService = require('../services/transferService');

/**
 * TransferController - Handles HTTP requests for transfer operations
 */
class TransferController {
    
    /**
     * Request student transfer
     * POST /api/transfers
     */
    async requestTransfer(req, res) {
        try {
            const transferData = req.body;
            const requestingUniversity = req.user.universityId;

            const result = await transferService.requestTransfer(
                transferData,
                requestingUniversity
            );

            res.status(201).json(result);
        } catch (error) {
            console.error('Error in requestTransfer:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to request transfer'
            });
        }
    }

    /**
     * Approve transfer
     * PUT /api/transfers/:id/approve
     */
    async approveTransfer(req, res) {
        try {
            const transferId = req.params.id;
            const approvingEntity = req.user.universityId;

            const result = await transferService.approveTransfer(
                transferId,
                approvingEntity
            );

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in approveTransfer:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to approve transfer'
            });
        }
    }

    /**
     * Reject transfer
     * PUT /api/transfers/:id/reject
     */
    async rejectTransfer(req, res) {
        try {
            const transferId = req.params.id;
            const rejectingEntity = req.user.universityId;
            const { reason } = req.body;

            const result = await transferService.rejectTransfer(
                transferId,
                rejectingEntity,
                reason
            );

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in rejectTransfer:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to reject transfer'
            });
        }
    }

    /**
     * Get transfer details
     * GET /api/transfers/:id
     */
    async getTransfer(req, res) {
        try {
            const transferId = req.params.id;

            const result = await transferService.getTransfer(transferId);

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in getTransfer:', error);
            res.status(404).json({
                success: false,
                message: error.message || 'Transfer not found'
            });
        }
    }

    /**
     * Get pending transfers for university
     * GET /api/transfers/pending
     */
    async getPendingTransfers(req, res) {
        try {
            const universityId = req.user.universityId;

            const result = await transferService.getPendingTransfers(universityId);

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in getPendingTransfers:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to get pending transfers'
            });
        }
    }
}

module.exports = new TransferController();
