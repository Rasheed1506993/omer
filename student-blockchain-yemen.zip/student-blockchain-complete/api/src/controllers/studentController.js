'use strict';

const studentService = require('../services/studentService');

/**
 * StudentController - Handles HTTP requests for student operations
 */
class StudentController {
    
    /**
     * Get all students
     * GET /api/students
     */
    async getAllStudents(req, res) {
        try {
            const result = await studentService.getAllStudents(req.user);

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in getAllStudents:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to get students'
            });
        }
    }

    /**
     * Create a new student
     * POST /api/students
     */
    async createStudent(req, res) {
        try {
            const studentData = req.body;
            const universityId = req.user.universityId;

            const result = await studentService.createStudent(studentData, universityId);

            res.status(201).json(result);
        } catch (error) {
            console.error('Error in createStudent:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to create student'
            });
        }
    }

    /**
     * Get student by ID
     * GET /api/students/:id
     */
    async getStudent(req, res) {
        try {
            const studentId = req.params.id;

            const result = await studentService.getStudent(studentId);

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in getStudent:', error);
            res.status(404).json({
                success: false,
                message: error.message || 'Student not found'
            });
        }
    }

    /**
     * Update student
     * PUT /api/students/:id
     */
    async updateStudent(req, res) {
        try {
            const studentId = req.params.id;
            const updateData = req.body;

            const result = await studentService.updateStudent(studentId, updateData);

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in updateStudent:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to update student'
            });
        }
    }

    /**
     * Get student history
     * GET /api/students/:id/history
     */
    async getStudentHistory(req, res) {
        try {
            const studentId = req.params.id;

            const result = await studentService.getStudentHistory(studentId);

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in getStudentHistory:', error);
            res.status(404).json({
                success: false,
                message: error.message || 'Failed to get student history'
            });
        }
    }

    /**
     * Get students by university
     * GET /api/universities/:universityId/students
     */
    async getStudentsByUniversity(req, res) {
        try {
            const universityId = req.params.universityId || req.user.universityId;

            const result = await studentService.getStudentsByUniversity(universityId);

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in getStudentsByUniversity:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to get students'
            });
        }
    }

    /**
     * Search students
     * GET /api/students/search
     */
    async searchStudents(req, res) {
        try {
            const criteria = req.query;

            const result = await studentService.searchStudents(criteria);

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in searchStudents:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to search students'
            });
        }
    }
}

module.exports = new StudentController();
