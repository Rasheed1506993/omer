'use strict';

const authService = require('../services/authService');

/**
 * AuthController - Handles authentication and authorization requests
 */
class AuthController {
    
    /**
     * Login
     * POST /api/auth/login
     */
    async login(req, res) {
        try {
            const { username, password } = req.body;

            // Validate input
            if (!username || !password) {
                return res.status(400).json({
                    success: false,
                    message: 'Username and password are required'
                });
            }

            const result = await authService.login(username, password);

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in login:', error);
            res.status(401).json({
                success: false,
                message: error.message || 'Login failed'
            });
        }
    }

    /**
     * Register new user
     * POST /api/auth/register
     */
    async register(req, res) {
        try {
            const userData = req.body;

            const result = await authService.register(userData);

            res.status(201).json(result);
        } catch (error) {
            console.error('Error in register:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Registration failed'
            });
        }
    }

    /**
     * Refresh access token
     * POST /api/auth/refresh
     */
    async refreshToken(req, res) {
        try {
            const { refreshToken } = req.body;

            if (!refreshToken) {
                return res.status(400).json({
                    success: false,
                    message: 'Refresh token is required'
                });
            }

            const result = await authService.refreshToken(refreshToken);

            res.status(200).json(result);
        } catch (error) {
            console.error('Error in refreshToken:', error);
            res.status(401).json({
                success: false,
                message: error.message || 'Token refresh failed'
            });
        }
    }

    /**
     * Get current user profile
     * GET /api/auth/profile
     */
    async getProfile(req, res) {
        try {
            // User is already attached by auth middleware
            res.status(200).json({
                success: true,
                data: req.user
            });
        } catch (error) {
            console.error('Error in getProfile:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to get profile'
            });
        }
    }

    /**
     * Update user profile
     * PUT /api/auth/profile
     */
    async updateProfile(req, res) {
        try {
            const userId = req.user.id;
            const updateData = req.body;

            const updatedUser = authService.updateUser(userId, updateData);

            res.status(200).json({
                success: true,
                message: 'Profile updated successfully',
                data: updatedUser
            });
        } catch (error) {
            console.error('Error in updateProfile:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Failed to update profile'
            });
        }
    }

    /**
     * Logout (client-side token removal)
     * POST /api/auth/logout
     */
    async logout(req, res) {
        try {
            // In a real implementation, you might want to:
            // - Blacklist the token
            // - Remove from session storage
            // For now, we'll just send success response
            
            res.status(200).json({
                success: true,
                message: 'Logged out successfully'
            });
        } catch (error) {
            console.error('Error in logout:', error);
            res.status(400).json({
                success: false,
                message: error.message || 'Logout failed'
            });
        }
    }
}

module.exports = new AuthController();
