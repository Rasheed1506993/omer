'use strict';

const fabricNetwork = require('./fabricNetwork');
const { v4: uuidv4 } = require('uuid');

/**
 * StudentService - Business logic for student operations
 * 
 * This service handles:
 * - Student CRUD operations
 * - Data validation
 * - Business rules enforcement
 */
class StudentService {
    
    /**
     * Get all students (for ministry) or university students
     * 
     * @param {Object} user - Current user
     * @returns {Promise<Object>} List of students
     */
    async getAllStudents(user) {
        try {
            let students = [];
            
            if (user.universityId === 'MINISTRY') {
                // Ministry can see all students from all universities
                students = await fabricNetwork.getAllStudents();
            } else {
                // University users can only see their university's students
                students = await fabricNetwork.getStudentsByUniversity(user.universityId);
            }

            return {
                success: true,
                data: {
                    count: students.length,
                    students: students
                }
            };
        } catch (error) {
            console.error('Error getting all students:', error);
            throw {
                success: false,
                message: error.message || 'Failed to get students',
                error: error
            };
        }
    }

    /**
     * Create a new student
     * 
     * @param {Object} studentData - Student information
     * @param {string} universityId - Creating university ID
     * @returns {Promise<Object>} Created student
     */
    async createStudent(studentData, universityId) {
        try {
            // Generate student ID if not provided
            if (!studentData.studentId) {
                studentData.studentId = this._generateStudentId();
            }

            // Validate student data
            this._validateStudentData(studentData);

            // Set university
            studentData.currentUniversity = universityId;

            // Set defaults
            studentData.status = studentData.status || 'active';
            studentData.gpa = studentData.gpa || 0.0;
            studentData.totalCredits = studentData.totalCredits || 0;

            // Submit to blockchain
            const result = await fabricNetwork.createStudent(studentData);

            return {
                success: true,
                message: 'Student created successfully',
                data: result
            };
        } catch (error) {
            console.error('Error creating student:', error);
            throw {
                success: false,
                message: error.message || 'Failed to create student',
                error: error
            };
        }
    }

    /**
     * Get student by ID
     * 
     * @param {string} studentId - Student ID
     * @returns {Promise<Object>} Student data
     */
    async getStudent(studentId) {
        try {
            if (!studentId) {
                throw new Error('Student ID is required');
            }

            const student = await fabricNetwork.getStudent(studentId);

            return {
                success: true,
                data: student
            };
        } catch (error) {
            console.error('Error getting student:', error);
            throw {
                success: false,
                message: error.message || 'Failed to get student',
                error: error
            };
        }
    }

    /**
     * Update student information
     * 
     * @param {string} studentId - Student ID
     * @param {Object} updateData - Data to update
     * @returns {Promise<Object>} Updated student
     */
    async updateStudent(studentId, updateData) {
        try {
            if (!studentId) {
                throw new Error('Student ID is required');
            }

            // Validate update data
            this._validateUpdateData(updateData);

            // Submit to blockchain
            const result = await fabricNetwork.updateStudent(studentId, updateData);

            return {
                success: true,
                message: 'Student updated successfully',
                data: result
            };
        } catch (error) {
            console.error('Error updating student:', error);
            throw {
                success: false,
                message: error.message || 'Failed to update student',
                error: error
            };
        }
    }

    /**
     * Get student history
     * 
     * @param {string} studentId - Student ID
     * @returns {Promise<Object>} Student history
     */
    async getStudentHistory(studentId) {
        try {
            if (!studentId) {
                throw new Error('Student ID is required');
            }

            const history = await fabricNetwork.getStudentHistory(studentId);

            return {
                success: true,
                data: {
                    studentId: studentId,
                    history: history
                }
            };
        } catch (error) {
            console.error('Error getting student history:', error);
            throw {
                success: false,
                message: error.message || 'Failed to get student history',
                error: error
            };
        }
    }

    /**
     * Get all students for a university
     * 
     * @param {string} universityId - University ID
     * @returns {Promise<Object>} List of students
     */
    async getStudentsByUniversity(universityId) {
        try {
            if (!universityId) {
                throw new Error('University ID is required');
            }

            const students = await fabricNetwork.getStudentsByUniversity(universityId);

            return {
                success: true,
                data: {
                    universityId: universityId,
                    count: students.length,
                    students: students
                }
            };
        } catch (error) {
            console.error('Error getting students by university:', error);
            throw {
                success: false,
                message: error.message || 'Failed to get students',
                error: error
            };
        }
    }

    /**
     * Search students (simplified version)
     * 
     * @param {Object} criteria - Search criteria
     * @returns {Promise<Object>} Search results
     */
    async searchStudents(criteria) {
        try {
            // In a real implementation, this would use a more sophisticated query
            // For PoC, we'll get all students and filter
            const { name, nationalId, university } = criteria;

            let students = [];
            
            if (university) {
                students = await fabricNetwork.getStudentsByUniversity(university);
            }

            // Filter results (basic implementation)
            if (name) {
                students = students.filter(s => 
                    s.fullName.includes(name) || 
                    (s.fullNameEn && s.fullNameEn.toLowerCase().includes(name.toLowerCase()))
                );
            }

            return {
                success: true,
                data: {
                    count: students.length,
                    students: students
                }
            };
        } catch (error) {
            console.error('Error searching students:', error);
            throw {
                success: false,
                message: error.message || 'Failed to search students',
                error: error
            };
        }
    }

    // ========== VALIDATION METHODS ==========

    /**
     * Validate student data
     * 
     * @param {Object} data - Student data to validate
     * @throws {Error} Validation error
     */
    _validateStudentData(data) {
        const requiredFields = [
            'nationalId',
            'fullName',
            'dateOfBirth',
            'college',
            'major',
            'enrollmentDate'
        ];

        // Check required fields
        for (const field of requiredFields) {
            if (!data[field]) {
                throw new Error(`Missing required field: ${field}`);
            }
        }

        // Validate national ID format (Saudi Arabia example: 10 digits)
        if (!/^\d{10}$/.test(data.nationalId)) {
            throw new Error('Invalid national ID format. Must be 10 digits');
        }

        // Validate email if provided
        if (data.email && !this._isValidEmail(data.email)) {
            throw new Error('Invalid email format');
        }

        // Validate phone if provided
        if (data.phone && !this._isValidPhone(data.phone)) {
            throw new Error('Invalid phone number format');
        }

        // Validate GPA if provided
        if (data.gpa !== undefined && (data.gpa < 0 || data.gpa > 5.0)) {
            throw new Error('GPA must be between 0 and 5.0');
        }

        // Validate date of birth
        const dob = new Date(data.dateOfBirth);
        const today = new Date();
        const age = today.getFullYear() - dob.getFullYear();
        
        if (age < 16 || age > 100) {
            throw new Error('Invalid date of birth');
        }
    }

    /**
     * Validate update data
     * 
     * @param {Object} data - Update data to validate
     * @throws {Error} Validation error
     */
    _validateUpdateData(data) {
        // Prevent updating critical fields
        const protectedFields = ['studentId', 'nationalId', 'createdBy', 'createdAt'];
        
        for (const field of protectedFields) {
            if (data.hasOwnProperty(field)) {
                throw new Error(`Cannot update protected field: ${field}`);
            }
        }

        // Validate email if being updated
        if (data.email && !this._isValidEmail(data.email)) {
            throw new Error('Invalid email format');
        }

        // Validate GPA if being updated
        if (data.gpa !== undefined && (data.gpa < 0 || data.gpa > 5.0)) {
            throw new Error('GPA must be between 0 and 5.0');
        }
    }

    /**
     * Validate email format
     */
    _isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    /**
     * Validate phone number
     */
    _isValidPhone(phone) {
        // Saudi Arabia phone format: +966XXXXXXXXX or 05XXXXXXXX
        const phoneRegex = /^(\+966|966|05)\d{8}$/;
        return phoneRegex.test(phone);
    }

    /**
     * Generate unique student ID
     */
    _generateStudentId() {
        const timestamp = Date.now().toString().slice(-8);
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        return `STU${timestamp}${random}`;
    }
}

module.exports = new StudentService();
