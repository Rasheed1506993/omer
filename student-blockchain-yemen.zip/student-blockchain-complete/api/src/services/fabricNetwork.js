'use strict';

const { Gateway, Wallets } = require('fabric-network');
const FabricCAServices = require('fabric-ca-client');
const fs = require('fs');
const path = require('path');
const config = require('../../config/config');

/**
 * FabricNetworkService - Handles all interactions with Hyperledger Fabric
 * 
 * This service provides methods to:
 * - Connect to the blockchain network
 * - Submit transactions to smart contracts
 * - Query data from the ledger
 * - Manage user identities and wallets
 */
class FabricNetworkService {
    constructor() {
        this.gateway = null;
        this.network = null;
        this.contract = null;
        this.wallet = null;
    }

    /**
     * Initialize connection to the Fabric network
     * 
     * @param {string} userId - User identity to use for connection
     * @returns {Promise<void>}
     */
    async connect(userId = config.fabric.userId) {
        try {
            console.log('Connecting to Fabric network...');

            // Load connection profile
            const ccpPath = path.resolve(__dirname, config.fabric.connectionProfile);
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

            // Create wallet
            const walletPath = path.resolve(__dirname, config.fabric.walletPath);
            this.wallet = await Wallets.newFileSystemWallet(walletPath);

            // Check if user identity exists in wallet
            const identity = await this.wallet.get(userId);
            if (!identity) {
                console.error(`Identity ${userId} not found in wallet`);
                throw new Error(`Identity ${userId} does not exist in the wallet`);
            }

            // Create gateway
            this.gateway = new Gateway();
            
            // Connection options
            const connectionOptions = {
                wallet: this.wallet,
                identity: userId,
                discovery: { 
                    enabled: true, 
                    asLocalhost: process.env.NODE_ENV === 'development' 
                }
            };

            // Connect to gateway
            await this.gateway.connect(ccp, connectionOptions);

            // Get network (channel)
            this.network = await this.gateway.getNetwork(config.fabric.channelName);

            // Get contract (chaincode)
            this.contract = this.network.getContract(config.fabric.chaincodeName);

            console.log('Successfully connected to Fabric network');
        } catch (error) {
            console.error(`Failed to connect to Fabric network: ${error.message}`);
            throw error;
        }
    }

    /**
     * Disconnect from the Fabric network
     */
    async disconnect() {
        if (this.gateway) {
            await this.gateway.disconnect();
            this.gateway = null;
            this.network = null;
            this.contract = null;
            console.log('Disconnected from Fabric network');
        }
    }

    /**
     * Submit a transaction to the blockchain
     * 
     * @param {string} functionName - Name of the smart contract function
     * @param {...string} args - Arguments for the function
     * @returns {Promise<any>} Transaction result
     */
    async submitTransaction(functionName, ...args) {
        try {
            if (!this.contract) {
                await this.connect();
            }

            console.log(`Submitting transaction: ${functionName}`);
            const result = await this.contract.submitTransaction(functionName, ...args);
            
            if (result && result.length > 0) {
                return JSON.parse(result.toString());
            }
            
            return result;
        } catch (error) {
            console.error(`Failed to submit transaction ${functionName}: ${error.message}`);
            throw error;
        }
    }

    /**
     * Evaluate a transaction (query only, no state change)
     * 
     * @param {string} functionName - Name of the smart contract function
     * @param {...string} args - Arguments for the function
     * @returns {Promise<any>} Query result
     */
    async evaluateTransaction(functionName, ...args) {
        try {
            if (!this.contract) {
                await this.connect();
            }

            console.log(`Evaluating transaction: ${functionName}`);
            const result = await this.contract.evaluateTransaction(functionName, ...args);
            
            if (result && result.length > 0) {
                return JSON.parse(result.toString());
            }
            
            return result;
        } catch (error) {
            console.error(`Failed to evaluate transaction ${functionName}: ${error.message}`);
            throw error;
        }
    }

    // ========== STUDENT OPERATIONS ==========

    /**
     * Create a new student record
     * 
     * @param {Object} studentData - Student information
     * @returns {Promise<Object>} Created student
     */
    async createStudent(studentData) {
        return await this.submitTransaction(
            'createStudent',
            JSON.stringify(studentData)
        );
    }

    /**
     * Get student by ID
     * 
     * @param {string} studentId - Student ID
     * @returns {Promise<Object>} Student data
     */
    async getStudent(studentId) {
        return await this.evaluateTransaction('getStudent', studentId);
    }

    /**
     * Update student record
     * 
     * @param {string} studentId - Student ID
     * @param {Object} updateData - Data to update
     * @returns {Promise<Object>} Updated student
     */
    async updateStudent(studentId, updateData) {
        return await this.submitTransaction(
            'updateStudent',
            studentId,
            JSON.stringify(updateData)
        );
    }

    /**
     * Get student history
     * 
     * @param {string} studentId - Student ID
     * @returns {Promise<Array>} Historical records
     */
    async getStudentHistory(studentId) {
        return await this.evaluateTransaction('getStudentHistory', studentId);
    }

    /**
     * Get all students from all universities
     * 
     * @returns {Promise<Array>} Array of all students
     */
    async getAllStudents() {
        return await this.evaluateTransaction('getAllStudents');
    }

    /**
     * Get students by university
     * 
     * @param {string} universityId - University ID
     * @returns {Promise<Array>} Array of students
     */
    async getStudentsByUniversity(universityId) {
        return await this.evaluateTransaction('getStudentsByUniversity', universityId);
    }

    // ========== TRANSFER OPERATIONS ==========

    /**
     * Request student transfer
     * 
     * @param {Object} transferData - Transfer request data
     * @returns {Promise<Object>} Transfer request
     */
    async requestTransfer(transferData) {
        return await this.submitTransaction(
            'requestTransfer',
            JSON.stringify(transferData)
        );
    }

    /**
     * Approve transfer request
     * 
     * @param {string} transferId - Transfer ID
     * @returns {Promise<Object>} Updated transfer
     */
    async approveTransfer(transferId) {
        return await this.submitTransaction('approveTransfer', transferId);
    }

    // ========== IDENTITY MANAGEMENT ==========

    /**
     * Register a new user with the CA
     * 
     * @param {string} username - Username
     * @param {string} orgMSP - Organization MSP ID
     * @param {string} role - User role
     * @returns {Promise<string>} User secret
     */
    async registerUser(username, orgMSP, role = 'client') {
        try {
            // Load connection profile
            const ccpPath = path.resolve(__dirname, config.fabric.connectionProfile);
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

            // Get CA info
            const caInfo = ccp.certificateAuthorities[`ca.${orgMSP.toLowerCase()}`];
            const caTLSCACerts = caInfo.tlsCACerts.pem;
            const ca = new FabricCAServices(
                caInfo.url,
                { trustedRoots: caTLSCACerts, verify: false },
                caInfo.caName
            );

            // Get wallet
            const walletPath = path.resolve(__dirname, config.fabric.walletPath);
            const wallet = await Wallets.newFileSystemWallet(walletPath);

            // Check if user already exists
            const userIdentity = await wallet.get(username);
            if (userIdentity) {
                throw new Error(`User ${username} already exists in wallet`);
            }

            // Get admin identity
            const adminIdentity = await wallet.get('admin');
            if (!adminIdentity) {
                throw new Error('Admin identity not found in wallet');
            }

            // Build a user object
            const provider = wallet.getProviderRegistry().getProvider(adminIdentity.type);
            const adminUser = await provider.getUserContext(adminIdentity, 'admin');

            // Register the user
            const secret = await ca.register({
                affiliation: '',
                enrollmentID: username,
                role: role
            }, adminUser);

            // Enroll the user
            const enrollment = await ca.enroll({
                enrollmentID: username,
                enrollmentSecret: secret
            });

            // Create identity
            const x509Identity = {
                credentials: {
                    certificate: enrollment.certificate,
                    privateKey: enrollment.key.toBytes()
                },
                mspId: orgMSP,
                type: 'X.509'
            };

            // Import to wallet
            await wallet.put(username, x509Identity);
            
            console.log(`Successfully registered and enrolled user ${username}`);
            return secret;
        } catch (error) {
            console.error(`Failed to register user ${username}: ${error.message}`);
            throw error;
        }
    }

    /**
     * Check if network connection is active
     * 
     * @returns {boolean} Connection status
     */
    isConnected() {
        return this.gateway !== null && this.contract !== null;
    }

    /**
     * Get network information
     * 
     * @returns {Object} Network info
     */
    getNetworkInfo() {
        if (!this.isConnected()) {
            return null;
        }

        return {
            channelName: config.fabric.channelName,
            chaincodeName: config.fabric.chaincodeName,
            connected: true
        };
    }
}

// Export singleton instance
module.exports = new FabricNetworkService();
