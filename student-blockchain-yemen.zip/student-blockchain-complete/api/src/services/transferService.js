'use strict';

const fabricNetwork = require('./fabricNetwork');

/**
 * TransferService - Business logic for student transfer operations
 * 
 * This service handles:
 * - Transfer request creation
 * - Transfer approval workflow
 * - Transfer status tracking
 */
class TransferService {
    
    /**
     * Request a student transfer
     * 
     * @param {Object} transferData - Transfer request data
     * @param {string} requestingUniversity - University requesting the transfer
     * @returns {Promise<Object>} Transfer request
     */
    async requestTransfer(transferData, requestingUniversity) {
        try {
            // Validate transfer data
            this._validateTransferRequest(transferData);

            // Ensure requesting university is the destination
            if (transferData.toUniversity !== requestingUniversity) {
                throw new Error('Only destination university can request transfer');
            }

            // Submit to blockchain
            const result = await fabricNetwork.requestTransfer(transferData);

            return {
                success: true,
                message: 'Transfer request created successfully',
                data: result
            };
        } catch (error) {
            console.error('Error requesting transfer:', error);
            throw {
                success: false,
                message: error.message || 'Failed to request transfer',
                error: error
            };
        }
    }

    /**
     * Approve a transfer request
     * 
     * @param {string} transferId - Transfer request ID
     * @param {string} approvingEntity - Entity approving (university or ministry)
     * @returns {Promise<Object>} Updated transfer
     */
    async approveTransfer(transferId, approvingEntity) {
        try {
            if (!transferId) {
                throw new Error('Transfer ID is required');
            }

            // Submit approval to blockchain
            const result = await fabricNetwork.approveTransfer(transferId);

            return {
                success: true,
                message: result.status === 'approved' 
                    ? 'Transfer completed successfully'
                    : 'Transfer approval recorded',
                data: result
            };
        } catch (error) {
            console.error('Error approving transfer:', error);
            throw {
                success: false,
                message: error.message || 'Failed to approve transfer',
                error: error
            };
        }
    }

    /**
     * Get transfer details
     * 
     * @param {string} transferId - Transfer ID
     * @returns {Promise<Object>} Transfer details
     */
    async getTransfer(transferId) {
        try {
            if (!transferId) {
                throw new Error('Transfer ID is required');
            }

            // In a complete implementation, this would query the transfer
            // For PoC, we'll return a placeholder
            return {
                success: true,
                data: {
                    transferId: transferId,
                    message: 'Transfer query not fully implemented in PoC'
                }
            };
        } catch (error) {
            console.error('Error getting transfer:', error);
            throw {
                success: false,
                message: error.message || 'Failed to get transfer',
                error: error
            };
        }
    }

    /**
     * Get pending transfers for a university
     * 
     * @param {string} universityId - University ID
     * @returns {Promise<Object>} Pending transfers
     */
    async getPendingTransfers(universityId) {
        try {
            if (!universityId) {
                throw new Error('University ID is required');
            }

            // This would query pending transfers
            // For PoC, returning placeholder
            return {
                success: true,
                data: {
                    universityId: universityId,
                    pendingTransfers: [],
                    message: 'Pending transfers query not fully implemented in PoC'
                }
            };
        } catch (error) {
            console.error('Error getting pending transfers:', error);
            throw {
                success: false,
                message: error.message || 'Failed to get pending transfers',
                error: error
            };
        }
    }

    /**
     * Reject a transfer request
     * 
     * @param {string} transferId - Transfer ID
     * @param {string} rejectingEntity - Entity rejecting
     * @param {string} reason - Rejection reason
     * @returns {Promise<Object>} Updated transfer
     */
    async rejectTransfer(transferId, rejectingEntity, reason) {
        try {
            if (!transferId) {
                throw new Error('Transfer ID is required');
            }

            if (!reason) {
                throw new Error('Rejection reason is required');
            }

            // In a complete implementation, this would update the transfer status
            return {
                success: true,
                message: 'Transfer rejected',
                data: {
                    transferId: transferId,
                    status: 'rejected',
                    rejectedBy: rejectingEntity,
                    reason: reason,
                    rejectedAt: new Date().toISOString()
                }
            };
        } catch (error) {
            console.error('Error rejecting transfer:', error);
            throw {
                success: false,
                message: error.message || 'Failed to reject transfer',
                error: error
            };
        }
    }

    // ========== VALIDATION METHODS ==========

    /**
     * Validate transfer request data
     * 
     * @param {Object} data - Transfer data to validate
     * @throws {Error} Validation error
     */
    _validateTransferRequest(data) {
        const requiredFields = [
            'studentId',
            'fromUniversity',
            'toUniversity',
            'reason'
        ];

        // Check required fields
        for (const field of requiredFields) {
            if (!data[field]) {
                throw new Error(`Missing required field: ${field}`);
            }
        }

        // Validate universities are different
        if (data.fromUniversity === data.toUniversity) {
            throw new Error('Source and destination universities must be different');
        }

        // Validate reason length
        if (data.reason.length < 10) {
            throw new Error('Transfer reason must be at least 10 characters');
        }
    }

    /**
     * Check if user can approve transfer
     * 
     * @param {string} transferId - Transfer ID
     * @param {string} userId - User ID
     * @param {string} role - User role
     * @returns {boolean} Can approve
     */
    _canApproveTransfer(transferId, userId, role) {
        // Logic to check approval permissions
        // This would check:
        // - User's role (registrar, admin, ministry)
        // - User's university vs transfer universities
        // - Current approval status
        
        return role === 'admin' || role === 'ministry' || role === 'registrar';
    }
}

module.exports = new TransferService();
