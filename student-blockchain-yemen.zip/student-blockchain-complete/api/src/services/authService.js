'use strict';

const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const config = require('../../config/config');
const fs = require('fs');
const path = require('path');

/**
 * AuthService - Handles authentication and authorization
 * 
 * This service provides:
 * - User login/logout
 * - JWT token generation and validation
 * - Password hashing and verification
 * - Role-based access control
 */
class AuthService {
    constructor() {
        this.usersFilePath = path.resolve(__dirname, '../../data/users.json');
        this.ensureUsersFile();
    }

    /**
     * Ensure users file exists
     */
    ensureUsersFile() {
        const dataDir = path.dirname(this.usersFilePath);
        
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }

        if (!fs.existsSync(this.usersFilePath)) {
            const initialUsers = {
                users: [
                    {
                        id: '1',
                        username: 'admin',
                        password: bcrypt.hashSync('admin123', config.security.bcryptRounds),
                        role: 'admin',
                        universityId: 'MINISTRY',
                        fullName: 'مشرف وزارة التعليم العالي',
                        email: 'admin@mohe.gov.ye',
                        active: true,
                        createdAt: new Date().toISOString()
                    },
                    {
                        id: '2',
                        username: 'sanaa_admin',
                        password: bcrypt.hashSync('sanaa123', config.security.bcryptRounds),
                        role: 'university_admin',
                        universityId: 'UNI001',
                        fullName: 'مدير جامعة صنعاء',
                        email: 'admin@su.edu.ye',
                        active: true,
                        createdAt: new Date().toISOString()
                    },
                    {
                        id: '3',
                        username: 'sanaa_registrar',
                        password: bcrypt.hashSync('registrar123', config.security.bcryptRounds),
                        role: 'registrar',
                        universityId: 'UNI001',
                        fullName: 'موظف قبول - جامعة صنعاء',
                        email: 'registrar@su.edu.ye',
                        active: true,
                        createdAt: new Date().toISOString()
                    },
                    {
                        id: '4',
                        username: 'aden_admin',
                        password: bcrypt.hashSync('aden123', config.security.bcryptRounds),
                        role: 'university_admin',
                        universityId: 'UNI002',
                        fullName: 'مدير جامعة عدن',
                        email: 'admin@aden-univ.edu.ye',
                        active: true,
                        createdAt: new Date().toISOString()
                    },
                    {
                        id: '5',
                        username: 'taiz_admin',
                        password: bcrypt.hashSync('taiz123', config.security.bcryptRounds),
                        role: 'university_admin',
                        universityId: 'UNI003',
                        fullName: 'مدير جامعة تعز',
                        email: 'admin@taiz-univ.edu.ye',
                        active: true,
                        createdAt: new Date().toISOString()
                    },
                    {
                        id: '6',
                        username: 'hodeidah_admin',
                        password: bcrypt.hashSync('hodeidah123', config.security.bcryptRounds),
                        role: 'university_admin',
                        universityId: 'UNI004',
                        fullName: 'مدير جامعة الحديدة',
                        email: 'admin@hoduniv.edu.ye',
                        active: true,
                        createdAt: new Date().toISOString()
                    },
                    {
                        id: '7',
                        username: 'ibb_admin',
                        password: bcrypt.hashSync('ibb123', config.security.bcryptRounds),
                        role: 'university_admin',
                        universityId: 'UNI005',
                        fullName: 'مدير جامعة إب',
                        email: 'admin@ibb-univ.edu.ye',
                        active: true,
                        createdAt: new Date().toISOString()
                    },
                    {
                        id: '8',
                        username: 'hadhramout_admin',
                        password: bcrypt.hashSync('hadhramout123', config.security.bcryptRounds),
                        role: 'university_admin',
                        universityId: 'UNI006',
                        fullName: 'مدير جامعة حضرموت',
                        email: 'admin@hu.edu.ye',
                        active: true,
                        createdAt: new Date().toISOString()
                    },
                    {
                        id: '9',
                        username: 'dhamar_admin',
                        password: bcrypt.hashSync('dhamar123', config.security.bcryptRounds),
                        role: 'university_admin',
                        universityId: 'UNI007',
                        fullName: 'مدير جامعة ذمار',
                        email: 'admin@tu.edu.ye',
                        active: true,
                        createdAt: new Date().toISOString()
                    },
                    {
                        id: '10',
                        username: 'ust_admin',
                        password: bcrypt.hashSync('ust123', config.security.bcryptRounds),
                        role: 'university_admin',
                        universityId: 'UNI008',
                        fullName: 'مدير جامعة العلوم والتكنولوجيا',
                        email: 'admin@ust.edu.ye',
                        active: true,
                        createdAt: new Date().toISOString()
                    }
                ]
            };
            
            fs.writeFileSync(this.usersFilePath, JSON.stringify(initialUsers, null, 2));
        }
    }

    /**
     * Read users from file
     */
    _readUsers() {
        const data = fs.readFileSync(this.usersFilePath, 'utf8');
        return JSON.parse(data);
    }

    /**
     * Write users to file
     */
    _writeUsers(data) {
        fs.writeFileSync(this.usersFilePath, JSON.stringify(data, null, 2));
    }

    /**
     * Login user
     * 
     * @param {string} username - Username
     * @param {string} password - Password
     * @returns {Promise<Object>} Login result with tokens
     */
    async login(username, password) {
        try {
            if (!username || !password) {
                throw new Error('Username and password are required');
            }

            // Get users
            const data = this._readUsers();
            const user = data.users.find(u => u.username === username);

            if (!user) {
                throw new Error('Invalid username or password');
            }

            // Check if user is active
            if (!user.active) {
                throw new Error('User account is disabled');
            }

            // Verify password
            const isValidPassword = await bcrypt.compare(password, user.password);
            
            if (!isValidPassword) {
                throw new Error('Invalid username or password');
            }

            // Generate tokens
            const accessToken = this._generateAccessToken(user);
            const refreshToken = this._generateRefreshToken(user);

            // Remove password from response
            const { password: _, ...userWithoutPassword } = user;

            return {
                success: true,
                message: 'Login successful',
                data: {
                    user: userWithoutPassword,
                    accessToken: accessToken,
                    refreshToken: refreshToken
                }
            };
        } catch (error) {
            console.error('Error during login:', error);
            throw {
                success: false,
                message: error.message || 'Login failed',
                error: error
            };
        }
    }

    /**
     * Register new user
     * 
     * @param {Object} userData - User data
     * @returns {Promise<Object>} Created user
     */
    async register(userData) {
        try {
            // Validate user data
            this._validateUserData(userData);

            // Get users
            const data = this._readUsers();

            // Check if username exists
            if (data.users.find(u => u.username === userData.username)) {
                throw new Error('Username already exists');
            }

            // Check if email exists
            if (data.users.find(u => u.email === userData.email)) {
                throw new Error('Email already exists');
            }

            // Hash password
            const hashedPassword = await bcrypt.hash(
                userData.password,
                config.security.bcryptRounds
            );

            // Create new user
            const newUser = {
                id: (data.users.length + 1).toString(),
                username: userData.username,
                password: hashedPassword,
                role: userData.role || 'viewer',
                universityId: userData.universityId,
                fullName: userData.fullName,
                email: userData.email,
                active: true,
                createdAt: new Date().toISOString()
            };

            // Add to users
            data.users.push(newUser);
            this._writeUsers(data);

            // Remove password from response
            const { password: _, ...userWithoutPassword } = newUser;

            return {
                success: true,
                message: 'User registered successfully',
                data: userWithoutPassword
            };
        } catch (error) {
            console.error('Error during registration:', error);
            throw {
                success: false,
                message: error.message || 'Registration failed',
                error: error
            };
        }
    }

    /**
     * Refresh access token
     * 
     * @param {string} refreshToken - Refresh token
     * @returns {Promise<Object>} New access token
     */
    async refreshToken(refreshToken) {
        try {
            if (!refreshToken) {
                throw new Error('Refresh token is required');
            }

            // Verify refresh token
            const decoded = jwt.verify(refreshToken, config.jwt.refreshSecret);

            // Get user
            const data = this._readUsers();
            const user = data.users.find(u => u.id === decoded.userId);

            if (!user || !user.active) {
                throw new Error('User not found or inactive');
            }

            // Generate new access token
            const accessToken = this._generateAccessToken(user);

            return {
                success: true,
                data: {
                    accessToken: accessToken
                }
            };
        } catch (error) {
            console.error('Error refreshing token:', error);
            throw {
                success: false,
                message: error.message || 'Token refresh failed',
                error: error
            };
        }
    }

    /**
     * Verify access token
     * 
     * @param {string} token - Access token
     * @returns {Object} Decoded token
     */
    verifyAccessToken(token) {
        try {
            return jwt.verify(token, config.jwt.secret);
        } catch (error) {
            throw new Error('Invalid or expired token');
        }
    }

    /**
     * Get user by ID
     * 
     * @param {string} userId - User ID
     * @returns {Object} User data
     */
    getUserById(userId) {
        const data = this._readUsers();
        const user = data.users.find(u => u.id === userId);
        
        if (!user) {
            throw new Error('User not found');
        }

        const { password: _, ...userWithoutPassword } = user;
        return userWithoutPassword;
    }

    /**
     * Update user
     * 
     * @param {string} userId - User ID
     * @param {Object} updateData - Data to update
     * @returns {Object} Updated user
     */
    updateUser(userId, updateData) {
        const data = this._readUsers();
        const userIndex = data.users.findIndex(u => u.id === userId);
        
        if (userIndex === -1) {
            throw new Error('User not found');
        }

        // Prevent updating protected fields
        delete updateData.id;
        delete updateData.password;
        delete updateData.createdAt;

        // Update user
        data.users[userIndex] = {
            ...data.users[userIndex],
            ...updateData,
            updatedAt: new Date().toISOString()
        };

        this._writeUsers(data);

        const { password: _, ...userWithoutPassword } = data.users[userIndex];
        return userWithoutPassword;
    }

    // ========== HELPER METHODS ==========

    /**
     * Generate access token
     */
    _generateAccessToken(user) {
        return jwt.sign(
            {
                userId: user.id,
                username: user.username,
                role: user.role,
                universityId: user.universityId
            },
            config.jwt.secret,
            { expiresIn: config.jwt.expiresIn }
        );
    }

    /**
     * Generate refresh token
     */
    _generateRefreshToken(user) {
        return jwt.sign(
            {
                userId: user.id
            },
            config.jwt.refreshSecret,
            { expiresIn: config.jwt.refreshExpiresIn }
        );
    }

    /**
     * Validate user data
     */
    _validateUserData(userData) {
        const requiredFields = ['username', 'password', 'email', 'fullName', 'universityId'];
        
        for (const field of requiredFields) {
            if (!userData[field]) {
                throw new Error(`Missing required field: ${field}`);
            }
        }

        // Validate email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(userData.email)) {
            throw new Error('Invalid email format');
        }

        // Validate password strength
        if (userData.password.length < 6) {
            throw new Error('Password must be at least 6 characters');
        }
    }

    /**
     * Check if user has required role
     */
    hasRole(user, requiredRoles) {
        if (!Array.isArray(requiredRoles)) {
            requiredRoles = [requiredRoles];
        }
        
        return requiredRoles.includes(user.role);
    }

    /**
     * Check if user belongs to university
     */
    belongsToUniversity(user, universityId) {
        return user.universityId === universityId || user.role === 'admin';
    }
}

module.exports = new AuthService();
