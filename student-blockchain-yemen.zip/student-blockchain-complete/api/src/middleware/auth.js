'use strict';

const authService = require('../services/authService');

/**
 * Authentication Middleware
 * 
 * Verifies JWT tokens and attaches user info to request
 */
const authenticate = async (req, res, next) => {
    try {
        // Get token from header
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                success: false,
                message: 'No token provided'
            });
        }

        // Extract token
        const token = authHeader.substring(7);

        // Verify token
        const decoded = authService.verifyAccessToken(token);

        // Get user
        const user = authService.getUserById(decoded.userId);

        // Attach user to request
        req.user = user;
        
        next();
    } catch (error) {
        return res.status(401).json({
            success: false,
            message: 'Invalid or expired token'
        });
    }
};

/**
 * Authorization Middleware
 * 
 * Checks if user has required role(s)
 * 
 * @param {...string} roles - Required roles
 */
const authorize = (...roles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Not authenticated'
            });
        }

        if (!roles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                message: 'Insufficient permissions'
            });
        }

        next();
    };
};

/**
 * University Authorization Middleware
 * 
 * Checks if user belongs to the specified university
 */
const authorizeUniversity = (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({
            success: false,
            message: 'Not authenticated'
        });
    }

    // Admin and ministry can access all universities
    if (req.user.role === 'admin' || req.user.universityId === 'MINISTRY') {
        return next();
    }

    // Get university ID from params or body
    const universityId = req.params.universityId || req.body.universityId;

    if (universityId && req.user.universityId !== universityId) {
        return res.status(403).json({
            success: false,
            message: 'You can only access your own university data'
        });
    }

    next();
};

/**
 * Optional Authentication Middleware
 * 
 * Attaches user if token is present, but doesn't fail if not
 */
const optionalAuth = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        
        if (authHeader && authHeader.startsWith('Bearer ')) {
            const token = authHeader.substring(7);
            const decoded = authService.verifyAccessToken(token);
            const user = authService.getUserById(decoded.userId);
            req.user = user;
        }
    } catch (error) {
        // Ignore error for optional auth
    }
    
    next();
};

module.exports = {
    authenticate,
    authorize,
    authorizeUniversity,
    optionalAuth
};
