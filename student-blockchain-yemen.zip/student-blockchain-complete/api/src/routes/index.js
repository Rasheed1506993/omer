'use strict';

const express = require('express');
const authController = require('../controllers/authController');
const studentController = require('../controllers/studentController');
const transferController = require('../controllers/transferController');
const { authenticate, authorize, authorizeUniversity } = require('../middleware/auth');

const router = express.Router();

// ========== HEALTH CHECK ==========
router.get('/health', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'API is running',
        timestamp: new Date().toISOString()
    });
});

// ========== AUTHENTICATION ROUTES ==========
router.post('/auth/login', authController.login.bind(authController));
router.post('/auth/register', authController.register.bind(authController));
router.post('/auth/refresh', authController.refreshToken.bind(authController));
router.post('/auth/logout', authController.logout.bind(authController));

// Protected auth routes
router.get(
    '/auth/profile',
    authenticate,
    authController.getProfile.bind(authController)
);

router.put(
    '/auth/profile',
    authenticate,
    authController.updateProfile.bind(authController)
);

// ========== STUDENT ROUTES ==========

// Search students (must be before :id route)
router.get(
    '/students/search',
    authenticate,
    studentController.searchStudents.bind(studentController)
);

// Get all students
router.get(
    '/students',
    authenticate,
    studentController.getAllStudents.bind(studentController)
);

// Create student (University Admin or Registrar only)
router.post(
    '/students',
    authenticate,
    authorize('admin', 'university_admin', 'registrar'),
    studentController.createStudent.bind(studentController)
);

// Get student by ID
router.get(
    '/students/:id',
    authenticate,
    studentController.getStudent.bind(studentController)
);

// Update student
router.put(
    '/students/:id',
    authenticate,
    authorize('admin', 'university_admin', 'registrar'),
    studentController.updateStudent.bind(studentController)
);

// Get student history
router.get(
    '/students/:id/history',
    authenticate,
    authorize('admin', 'university_admin', 'registrar'),
    studentController.getStudentHistory.bind(studentController)
);

// Get students by university
router.get(
    '/universities/:universityId/students',
    authenticate,
    authorizeUniversity,
    studentController.getStudentsByUniversity.bind(studentController)
);

// ========== TRANSFER ROUTES ==========

// Request transfer
router.post(
    '/transfers',
    authenticate,
    authorize('admin', 'university_admin', 'registrar'),
    transferController.requestTransfer.bind(transferController)
);

// Approve transfer
router.put(
    '/transfers/:id/approve',
    authenticate,
    authorize('admin', 'university_admin', 'registrar'),
    transferController.approveTransfer.bind(transferController)
);

// Reject transfer
router.put(
    '/transfers/:id/reject',
    authenticate,
    authorize('admin', 'university_admin', 'registrar'),
    transferController.rejectTransfer.bind(transferController)
);

// Get transfer details
router.get(
    '/transfers/:id',
    authenticate,
    transferController.getTransfer.bind(transferController)
);

// Get pending transfers
router.get(
    '/transfers/pending',
    authenticate,
    transferController.getPendingTransfers.bind(transferController)
);

// ========== ERROR HANDLER ==========
router.use((err, req, res, next) => {
    console.error('Route error:', err);
    res.status(err.status || 500).json({
        success: false,
        message: err.message || 'Internal server error'
    });
});

module.exports = router;
