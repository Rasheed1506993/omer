require('dotenv').config();

module.exports = {
    // Server Configuration
    port: process.env.PORT || 3000,
    env: process.env.NODE_ENV || 'development',
    
    // JWT Configuration
    jwt: {
        secret: process.env.JWT_SECRET || 'your-secret-key-change-in-production',
        expiresIn: process.env.JWT_EXPIRES_IN || '24h',
        refreshSecret: process.env.JWT_REFRESH_SECRET || 'your-refresh-secret',
        refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
    },
    
    // Hyperledger Fabric Configuration
    fabric: {
        channelName: process.env.CHANNEL_NAME || 'educationchannel',
        chaincodeName: process.env.CHAINCODE_NAME || 'student-records',
        
        // Connection Profile Path
        connectionProfile: process.env.CONNECTION_PROFILE || '../network/connection-profile.json',
        
        // Wallet Configuration
        walletPath: process.env.WALLET_PATH || '../wallet',
        
        // User Configuration
        userId: process.env.USER_ID || 'admin',
        mspId: process.env.MSP_ID || 'Org1MSP'
    },
    
    // Database Configuration (for user management, not blockchain data)
    database: {
        type: process.env.DB_TYPE || 'json', // 'json', 'mongodb', 'postgresql'
        path: process.env.DB_PATH || './data/users.json',
        
        // MongoDB (if used)
        mongodb: {
            uri: process.env.MONGODB_URI || 'mongodb://localhost:27017/student-verification',
            options: {
                useNewUrlParser: true,
                useUnifiedTopology: true
            }
        }
    },
    
    // Security Configuration
    security: {
        bcryptRounds: parseInt(process.env.BCRYPT_ROUNDS) || 10,
        maxLoginAttempts: parseInt(process.env.MAX_LOGIN_ATTEMPTS) || 5,
        lockoutDuration: parseInt(process.env.LOCKOUT_DURATION) || 15 * 60 * 1000, // 15 minutes
    },
    
    // Rate Limiting
    rateLimit: {
        windowMs: 15 * 60 * 1000, // 15 minutes
        max: 100, // limit each IP to 100 requests per windowMs
        message: 'Too many requests from this IP, please try again later'
    },
    
    // CORS Configuration
    cors: {
        origin: process.env.CORS_ORIGIN || '*',
        credentials: true
    },
    
    // Logging Configuration
    logging: {
        level: process.env.LOG_LEVEL || 'info',
        format: process.env.LOG_FORMAT || 'combined'
    },
    
    // Pagination
    pagination: {
        defaultLimit: 20,
        maxLimit: 100
    },
    
    // File Upload
    upload: {
        maxFileSize: 5 * 1024 * 1024, // 5MB
        allowedTypes: ['image/jpeg', 'image/png', 'application/pdf']
    }
};
