# 🚀 دليل البدء السريع لـ Windows

## الخطوة 1: التحضير (5 دقائق)

### تثبيت البرامج المطلوبة:

```powershell
# افتح PowerShell كمسؤول وقم بتشغيل:

# Docker Desktop
winget install Docker.DockerDesktop

# Node.js
winget install OpenJS.NodeJS.LTS

# Git
winget install Git.Git

# أعد تشغيل الكمبيوتر
Restart-Computer
```

---

## الخطوة 2: فك الضغط والإعداد (5 دقائق)

```powershell
# 1. فك ضغط الملف
Expand-Archive -Path student-blockchain-complete.zip -DestinationPath C:\blockchain

# 2. انتقل إلى المجلد
cd C:\blockchain\student-blockchain-complete
```

---

## الخطوة 3: تشغيل بسيط (بدون VM للاختبار)

### أ. تشغيل API:

```powershell
# Terminal 1
cd C:\blockchain\student-blockchain-complete\api
npm install
copy .env.example .env
npm start
```

### ب. تشغيل Frontend:

```powershell
# Terminal 2 (جديد)
cd C:\blockchain\student-blockchain-complete\frontend  
npm install
npm start
```

سيفتح المتصفح تلقائياً على http://localhost:3001

---

## الخطوة 4: تسجيل الدخول

استخدم:
- **Username:** `admin`
- **Password:** `admin123`

---

## الخطوة 5: تجربة النظام

1. من القائمة الجانبية، اختر "الطلاب"
2. اضغط "إضافة طالب جديد"
3. املأ البيانات
4. احفظ
5. جرّب البحث والعرض

---

## الخطوة 6: للنشر على 3 أجهزة

راجع ملف `COMPLETE_DEPLOYMENT_GUIDE.md` للتفاصيل الكاملة

---

## استكشاف الأخطاء

### مشكلة: npm install يفشل
```powershell
npm cache clean --force
npm install
```

### مشكلة: Port مستخدم
```powershell
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### مشكلة: لا يفتح المتصفح
افتح يدوياً: http://localhost:3001

---

**نصيحة:** للتجربة السريعة، استخدم هذا الدليل. للنشر الكامل على VMs، استخدم `COMPLETE_DEPLOYMENT_GUIDE.md`
