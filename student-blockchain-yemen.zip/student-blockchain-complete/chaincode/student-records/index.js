'use strict';

const StudentContract = require('./lib/studentContract');

module.exports.StudentContract = StudentContract;
module.exports.contracts = [StudentContract];
