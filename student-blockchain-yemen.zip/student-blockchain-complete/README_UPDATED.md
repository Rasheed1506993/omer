# نظام التحقق من بيانات الطلاب باستخدام تقنية البلوك تشين
# Student Verification Blockchain System

## نظرة عامة | Overview

نظام متكامل للتحقق من بيانات الطلاب عبر الجامعات باستخدام تقنية Hyperledger Fabric. يهدف النظام إلى:
- توفير مصدر موحد وموثوق للبيانات الأكاديمية
- منع التزوير من خلال سجلات غير قابلة للتعديل
- تسهيل عملية نقل الطلاب بين الجامعات
- توفير شفافية كاملة في التدقيق

---

## المميزات الرئيسية | Key Features

### 1. نظام متعدد الأدوار
- **الوزارة (Ministry)**: إدارة شاملة لجميع الجامعات والطلاب
- **الجامعات (Universities)**: إدارة طلاب الجامعة فقط

### 2. واجهة مستخدم متقدمة
- شريط جانبي قابل للطي (Collapsible Sidebar)
- تصميم متجاوب للأجهزة المختلفة
- دعم كامل للغة العربية (RTL)

### 3. إدارة الطلاب
- إضافة طلاب جدد
- البحث والتحقق من الطلاب
- عرض السجل الأكاديمي الكامل
- تتبع التعديلات على البلوك تشين

### 4. نظام النقل المتعدد المراحل
- طلب نقل من الجامعة المستقبلة
- موافقة الجامعة المصدر
- موافقة الوزارة النهائية
- تنفيذ تلقائي بعد اكتمال الموافقات

### 5. التدقيق والمراقبة
- سجل كامل للمعاملات
- مراقبة حالة شبكة البلوك تشين
- تتبع جميع التغييرات

---

## هيكل المشروع | Project Structure

```
student-blockchain-complete/
├── api/                    # Backend API (Node.js/Express)
│   ├── src/
│   │   ├── controllers/    # Request handlers
│   │   ├── services/       # Business logic
│   │   ├── middleware/     # Auth & validation
│   │   └── routes/         # API routes
│   └── config/
│
├── frontend/               # React Frontend
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── pages/          # Page components
│   │   ├── context/        # React context (Auth)
│   │   └── services/       # API services
│   └── public/
│
├── chaincode/              # Smart Contracts
│   └── student-records/
│       └── lib/
│
├── network/                # Fabric Network Config
│   ├── docker/
│   ├── configtx/
│   └── crypto-config/
│
└── docs/                   # Documentation
```

---

## الحسابات التجريبية | Demo Accounts

| الدور | اسم المستخدم | كلمة المرور | المؤسسة |
|-------|-------------|-------------|---------|
| مدير الوزارة | admin | admin123 | MINISTRY |
| جامعة الملك سعود | ksu_admin | ksu123 | UNI001 |
| جامعة الملك عبدالعزيز | kau_admin | kau123 | UNI002 |
| جامعة أم القرى | uqu_admin | uqu123 | UNI003 |
| جامعة الإمام | imamu_admin | imamu123 | UNI004 |

---

## التشغيل | Getting Started

### المتطلبات
- Node.js 18+
- npm أو yarn
- Docker & Docker Compose (للشبكة)

### 1. تشغيل الـ Backend

```bash
cd api
npm install
npm start
```

الـ API سيعمل على: `http://localhost:3000`

### 2. تشغيل الـ Frontend

```bash
cd frontend
npm install
npm start
```

الواجهة ستعمل على: `http://localhost:3001`

### 3. الوصول للنظام

افتح المتصفح على: `http://localhost:3001`

استخدم أحد الحسابات التجريبية للدخول.

---

## الصفحات الرئيسية | Main Pages

### للوزارة (Ministry)
1. **لوحة التحكم** - إحصائيات شاملة
2. **إدارة الجامعات** - جميع الجامعات المشاركة
3. **جميع الطلاب** - طلاب كل الجامعات
4. **طلبات النقل** - الموافقة على طلبات النقل
5. **حالة الشبكة** - مراقبة البلوك تشين
6. **سجل التدقيق** - جميع المعاملات

### للجامعات (Universities)
1. **لوحة التحكم** - إحصائيات الجامعة
2. **طلاب الجامعة** - إدارة الطلاب
3. **إضافة طالب** - تسجيل طالب جديد
4. **طلبات النقل** - إنشاء والموافقة على النقل
5. **البحث** - التحقق من الطلاب
6. **سجل التدقيق** - معاملات الجامعة

---

## تدفق عملية النقل | Transfer Flow

```
1. الجامعة المستقبلة ← تقديم طلب النقل
                ↓
2. الجامعة المصدر ← مراجعة وموافقة
                ↓
3. الوزارة ← الموافقة النهائية
                ↓
4. تنفيذ تلقائي ← تحديث سجل الطالب
```

---

## API Endpoints

### Authentication
- `POST /api/auth/login` - تسجيل الدخول
- `GET /api/auth/profile` - الملف الشخصي

### Students
- `GET /api/students` - جميع الطلاب
- `POST /api/students` - إضافة طالب
- `GET /api/students/:id` - بيانات طالب
- `PUT /api/students/:id` - تحديث طالب
- `GET /api/students/search` - بحث

### Transfers
- `GET /api/transfers/pending` - الطلبات المعلقة
- `POST /api/transfers` - طلب نقل جديد
- `PUT /api/transfers/:id/approve` - موافقة
- `PUT /api/transfers/:id/reject` - رفض

---

## الأمان | Security

- JWT Authentication
- Role-Based Access Control (RBAC)
- Blockchain-based audit trail
- Encrypted sensitive data

---

## التقنيات المستخدمة | Technologies

### Backend
- Node.js + Express
- Hyperledger Fabric SDK
- JWT for authentication

### Frontend
- React 18
- Material-UI (MUI)
- React Router
- Axios

### Blockchain
- Hyperledger Fabric 2.x
- CouchDB (State Database)
- Raft Consensus

---

## للمطورين | For Developers

### إضافة جامعة جديدة
1. أضف المستخدم في `api/src/services/authService.js`
2. أضف بيانات الجامعة في الصفحات المعنية

### تخصيص الواجهة
- الألوان في `frontend/src/theme.js`
- التخطيط في `frontend/src/components/MainLayout.js`

---

## المراجع | References

- [Hyperledger Fabric Documentation](https://hyperledger-fabric.readthedocs.io/)
- [React Documentation](https://react.dev/)
- [Material-UI](https://mui.com/)

---

## الترخيص | License

MIT License

---

**مشروع تخرج - نظام التحقق من بيانات الطلاب باستخدام تقنية البلوك تشين**

© 2024 جميع الحقوق محفوظة
