import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Chip,
  Button,
  Card,
  CardContent,
  Divider,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Avatar
} from '@mui/material';
import {
  ArrowBack,
  Edit,
  SwapHoriz,
  History,
  School,
  Person,
  Email,
  Phone,
  CalendarToday,
  FiberManualRecord
} from '@mui/icons-material';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useAuth } from '../context/AuthContext';

export default function StudentView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [student, setStudent] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStudent();
    loadHistory();
  }, [id]);

  const loadStudent = async () => {
    try {
      const response = await axios.get(`/api/students/${id}`);
      setStudent(response.data.data);
    } catch (error) {
      toast.error('فشل تحميل بيانات الطالب');
      navigate('/students');
    }
  };

  const loadHistory = async () => {
    try {
      const response = await axios.get(`/api/students/${id}/history`);
      setHistory(response.data.data || []);
    } catch (error) {
      console.error('Error loading history:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress size={60} />
      </Box>
    );
  }

  if (!student) {
    return null;
  }

  const InfoItem = ({ icon, label, value }) => (
    <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2, mb: 2 }}>
      <Box sx={{ color: 'primary.main', mt: 0.5 }}>{icon}</Box>
      <Box sx={{ flex: 1 }}>
        <Typography variant="subtitle2" color="text.secondary">
          {label}
        </Typography>
        <Typography variant="body1">{value || '-'}</Typography>
      </Box>
    </Box>
  );

  // Custom Timeline Item Component
  const TimelineEntry = ({ entry, isLast }) => (
    <Box sx={{ display: 'flex', gap: 2, mb: isLast ? 0 : 2 }}>
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Avatar sx={{ width: 32, height: 32, bgcolor: 'primary.main' }}>
          <FiberManualRecord sx={{ fontSize: 12 }} />
        </Avatar>
        {!isLast && (
          <Box sx={{ width: 2, flex: 1, bgcolor: 'grey.300', my: 0.5 }} />
        )}
      </Box>
      <Box sx={{ flex: 1, pb: isLast ? 0 : 2 }}>
        <Typography variant="caption" color="text.secondary">
          {new Date(entry.timestamp).toLocaleString('ar-SA')}
        </Typography>
        <Typography variant="body2">{entry.action}</Typography>
        <Typography variant="caption" color="text.secondary">
          بواسطة: {entry.user}
        </Typography>
      </Box>
    </Box>
  );

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <Button startIcon={<ArrowBack />} onClick={() => navigate('/students')} sx={{ mb: 2 }}>
          العودة
        </Button>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Box>
            <Typography variant="h4" gutterBottom>
              بيانات الطالب
            </Typography>
            <Typography variant="body2" color="text.secondary">
              رقم الطالب: {student.studentId}
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 2 }}>
            {['admin', 'university_admin'].includes(user?.role) && (
              <>
                <Button
                  variant="outlined"
                  startIcon={<Edit />}
                  onClick={() => navigate(`/students/${id}/edit`)}
                >
                  تعديل
                </Button>
                <Button
                  variant="contained"
                  startIcon={<SwapHoriz />}
                  onClick={() => navigate('/transfers/create', { state: { studentId: id } })}
                >
                  طلب نقل
                </Button>
              </>
            )}
          </Box>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {/* Personal Information */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Person /> المعلومات الشخصية
            </Typography>
            <Divider sx={{ mb: 3 }} />

            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <InfoItem
                  icon={<Person />}
                  label="الاسم الكامل (عربي)"
                  value={student.fullName}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <InfoItem
                  icon={<Person />}
                  label="الاسم الكامل (إنجليزي)"
                  value={student.fullNameEn}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <InfoItem
                  icon={<CalendarToday />}
                  label="تاريخ الميلاد"
                  value={
                    student.dateOfBirth
                      ? new Date(student.dateOfBirth).toLocaleDateString('ar-SA')
                      : '-'
                  }
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <InfoItem
                  icon={<Email />}
                  label="البريد الإلكتروني"
                  value={student.email}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <InfoItem icon={<Phone />} label="رقم الهاتف" value={student.phone} />
              </Grid>
            </Grid>
          </Paper>

          {/* Academic Information */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <School /> المعلومات الأكاديمية
            </Typography>
            <Divider sx={{ mb: 3 }} />

            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <InfoItem label="الجامعة الحالية" value={student.currentUniversity} />
              </Grid>
              <Grid item xs={12} md={6}>
                <InfoItem label="الكلية" value={student.college} />
              </Grid>
              <Grid item xs={12} md={6}>
                <InfoItem label="التخصص" value={student.major} />
              </Grid>
              <Grid item xs={12} md={6}>
                <InfoItem
                  label="تاريخ الالتحاق"
                  value={
                    student.enrollmentDate
                      ? new Date(student.enrollmentDate).toLocaleDateString('ar-SA')
                      : '-'
                  }
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <InfoItem label="المعدل التراكمي" value={student.gpa} />
              </Grid>
              <Grid item xs={12} md={6}>
                <Box>
                  <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                    الحالة
                  </Typography>
                  <Chip
                    label={student.status === 'active' ? 'نشط' : 'غير نشط'}
                    color={student.status === 'active' ? 'success' : 'default'}
                  />
                </Box>
              </Grid>
            </Grid>
          </Paper>

          {/* Transfer History */}
          {student.transferHistory && student.transferHistory.length > 0 && (
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <SwapHoriz /> سجل النقل
              </Typography>
              <Divider sx={{ mb: 3 }} />

              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>التاريخ</TableCell>
                      <TableCell>من</TableCell>
                      <TableCell>إلى</TableCell>
                      <TableCell>السبب</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {student.transferHistory.map((transfer, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          {new Date(transfer.date).toLocaleDateString('ar-SA')}
                        </TableCell>
                        <TableCell>{transfer.from}</TableCell>
                        <TableCell>{transfer.to}</TableCell>
                        <TableCell>{transfer.reason}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
          )}
        </Grid>

        {/* Sidebar */}
        <Grid item xs={12} md={4}>
          {/* Status Card */}
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                ملخص
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Box>
                  <Typography variant="subtitle2" color="text.secondary">
                    رقم الطالب
                  </Typography>
                  <Typography variant="h6">{student.studentId}</Typography>
                </Box>
                <Box>
                  <Typography variant="subtitle2" color="text.secondary">
                    الجامعة
                  </Typography>
                  <Typography variant="body1">{student.currentUniversity}</Typography>
                </Box>
                <Box>
                  <Typography variant="subtitle2" color="text.secondary">
                    المعدل
                  </Typography>
                  <Typography variant="h5" color="primary">
                    {student.gpa || '-'}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="subtitle2" color="text.secondary">
                    الحالة
                  </Typography>
                  <Chip
                    label={student.status === 'active' ? 'نشط' : 'غير نشط'}
                    color={student.status === 'active' ? 'success' : 'default'}
                    size="small"
                  />
                </Box>
              </Box>
            </CardContent>
          </Card>

          {/* Change History */}
          <Card>
            <CardContent>
              <Typography
                variant="h6"
                gutterBottom
                sx={{ display: 'flex', alignItems: 'center', gap: 1 }}
              >
                <History /> سجل التغييرات
              </Typography>
              <Divider sx={{ mb: 2 }} />

              {history.length > 0 ? (
                <Box>
                  {history.slice(0, 5).map((entry, index) => (
                    <TimelineEntry 
                      key={index} 
                      entry={entry} 
                      isLast={index === Math.min(4, history.length - 1)} 
                    />
                  ))}
                </Box>
              ) : (
                <Typography variant="body2" color="text.secondary">
                  لا توجد سجلات تغيير
                </Typography>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
