import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  CircularProgress,
  Card,
  CardContent,
  Grid,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Avatar,
  Divider,
  Badge
} from '@mui/material';
import {
  CheckCircle,
  Cancel,
  Visibility,
  Schedule,
  SwapHoriz,
  Edit,
  Person,
  School,
  AdminPanelSettings,
  ThumbUp,
  ThumbDown
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { toast } from 'react-toastify';

export default function ApprovalRequests() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);
  const [approvals, setApprovals] = useState([]);
  const [selectedApproval, setSelectedApproval] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [actionType, setActionType] = useState(null);
  const [comments, setComments] = useState('');
  const [processing, setProcessing] = useState(false);

  const isMinistry = user?.universityId === 'MINISTRY';

  useEffect(() => {
    loadApprovals();
  }, []);

  const loadApprovals = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/transfers/pending');
      const transfers = response.data.data || [];
      
      // Transform transfers into approval items
      const approvalItems = transfers.map(t => ({
        ...t,
        type: 'transfer',
        requestDate: t.createdAt || new Date().toISOString(),
        approvalSteps: [
          { 
            label: 'الجامعة المصدر', 
            status: t.status === 'pending' ? 'pending' : 'approved',
            approvedBy: t.status !== 'pending' ? 'مدير القبول' : null,
            approvedAt: t.status !== 'pending' ? t.updatedAt : null
          },
          { 
            label: 'الوزارة', 
            status: t.status === 'approved_by_source' ? 'pending' : t.status === 'completed' ? 'approved' : 'waiting',
            approvedBy: t.status === 'completed' ? 'مشرف الوزارة' : null,
            approvedAt: t.status === 'completed' ? t.updatedAt : null
          },
          { 
            label: 'الجامعة المستقبلة', 
            status: t.status === 'completed' ? 'approved' : 'waiting',
            approvedBy: null,
            approvedAt: null
          }
        ]
      }));
      
      setApprovals(approvalItems);
    } catch (error) {
      console.error('Error loading approvals:', error);
      // Set demo data with Yemeni universities
      setApprovals([
        {
          transferId: 'TRF001',
          type: 'transfer',
          studentId: 'STU001',
          studentName: 'عبدالله محمد الصنعاني',
          fromUniversity: 'UNI001',
          fromUniversityName: 'جامعة صنعاء',
          toUniversity: 'UNI002',
          toUniversityName: 'جامعة عدن',
          reason: 'الانتقال للإقامة في عدن',
          status: 'pending',
          requestDate: new Date().toISOString(),
          approvalSteps: [
            { label: 'الجامعة المصدر', status: 'pending', approvedBy: null, approvedAt: null },
            { label: 'الوزارة', status: 'waiting', approvedBy: null, approvedAt: null },
            { label: 'الجامعة المستقبلة', status: 'waiting', approvedBy: null, approvedAt: null }
          ]
        },
        {
          transferId: 'TRF002',
          type: 'transfer',
          studentId: 'STU002',
          studentName: 'فاطمة علي المقطري',
          fromUniversity: 'UNI002',
          fromUniversityName: 'جامعة عدن',
          toUniversity: 'UNI001',
          toUniversityName: 'جامعة صنعاء',
          reason: 'تغيير التخصص',
          status: 'approved_by_source',
          requestDate: new Date(Date.now() - 86400000).toISOString(),
          approvalSteps: [
            { label: 'الجامعة المصدر', status: 'approved', approvedBy: 'محمد باوزير', approvedAt: new Date(Date.now() - 43200000).toISOString() },
            { label: 'الوزارة', status: 'pending', approvedBy: null, approvedAt: null },
            { label: 'الجامعة المستقبلة', status: 'waiting', approvedBy: null, approvedAt: null }
          ]
        },
        {
          transferId: 'TRF003',
          type: 'transfer',
          studentId: 'STU003',
          studentName: 'أحمد سالم التعزي',
          fromUniversity: 'UNI003',
          fromUniversityName: 'جامعة تعز',
          toUniversity: 'UNI005',
          toUniversityName: 'جامعة إب',
          reason: 'القرب من السكن',
          status: 'pending',
          requestDate: new Date(Date.now() - 172800000).toISOString(),
          approvalSteps: [
            { label: 'الجامعة المصدر', status: 'pending', approvedBy: null, approvedAt: null },
            { label: 'الوزارة', status: 'waiting', approvedBy: null, approvedAt: null },
            { label: 'الجامعة المستقبلة', status: 'waiting', approvedBy: null, approvedAt: null }
          ]
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (approval, action) => {
    setSelectedApproval(approval);
    setActionType(action);
    setComments('');
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setSelectedApproval(null);
    setActionType(null);
    setComments('');
  };

  const handleSubmitAction = async () => {
    if (!selectedApproval) return;
    
    setProcessing(true);
    try {
      const endpoint = actionType === 'approve' 
        ? `/api/transfers/${selectedApproval.transferId}/approve`
        : `/api/transfers/${selectedApproval.transferId}/reject`;
      
      await axios.put(endpoint, {
        approved: actionType === 'approve',
        comments: comments
      });
      
      toast.success(actionType === 'approve' ? 'تمت الموافقة بنجاح' : 'تم الرفض');
      handleCloseDialog();
      loadApprovals();
    } catch (error) {
      toast.error(error.response?.data?.message || 'حدث خطأ');
    } finally {
      setProcessing(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'warning';
      case 'approved': return 'success';
      case 'rejected': return 'error';
      case 'waiting': return 'default';
      default: return 'default';
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'pending': return 'بانتظار الموافقة';
      case 'approved': return 'تمت الموافقة';
      case 'approved_by_source': return 'بانتظار الوزارة';
      case 'rejected': return 'مرفوض';
      case 'waiting': return 'في الانتظار';
      case 'completed': return 'مكتمل';
      default: return status;
    }
  };

  const canApprove = (approval) => {
    if (isMinistry) {
      return approval.status === 'approved_by_source';
    } else {
      return approval.status === 'pending' && 
             (approval.fromUniversity === user?.universityId || approval.toUniversity === user?.universityId);
    }
  };

  const pendingCount = approvals.filter(a => canApprove(a)).length;
  const allCount = approvals.length;
  const completedCount = approvals.filter(a => a.status === 'completed').length;

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
          طلبات الموافقة
        </Typography>
        <Typography variant="body1" color="text.secondary">
          إدارة طلبات النقل والتعديلات التي تحتاج موافقتك
        </Typography>
      </Box>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={4}>
          <Card sx={{ 
            bgcolor: 'warning.light',
            color: 'warning.dark'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {pendingCount}
                  </Typography>
                  <Typography variant="body2">
                    تحتاج موافقتك
                  </Typography>
                </Box>
                <Schedule sx={{ fontSize: 50, opacity: 0.5 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {allCount}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    إجمالي الطلبات
                  </Typography>
                </Box>
                <SwapHoriz sx={{ fontSize: 50, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ 
            bgcolor: 'success.light',
            color: 'success.dark'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {completedCount}
                  </Typography>
                  <Typography variant="body2">
                    مكتملة
                  </Typography>
                </Box>
                <CheckCircle sx={{ fontSize: 50, opacity: 0.5 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Tabs */}
      <Paper sx={{ mb: 3 }}>
        <Tabs 
          value={tabValue} 
          onChange={(e, v) => setTabValue(v)}
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab 
            label={
              <Badge badgeContent={pendingCount} color="error">
                <Box sx={{ pr: 2 }}>تحتاج موافقتي</Box>
              </Badge>
            } 
          />
          <Tab label="جميع الطلبات" />
          <Tab label="المكتملة" />
        </Tabs>
      </Paper>

      {/* Approvals List */}
      <Paper sx={{ p: 3 }}>
        {approvals.length === 0 ? (
          <Alert severity="info">
            لا توجد طلبات موافقة حالياً
          </Alert>
        ) : (
          <Grid container spacing={3}>
            {approvals
              .filter(a => {
                if (tabValue === 0) return canApprove(a);
                if (tabValue === 2) return a.status === 'completed';
                return true;
              })
              .map((approval) => (
                <Grid item xs={12} key={approval.transferId}>
                  <Card variant="outlined">
                    <CardContent>
                      <Grid container spacing={3}>
                        {/* Request Info */}
                        <Grid item xs={12} md={6}>
                          <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2 }}>
                            <Avatar sx={{ bgcolor: 'primary.main', width: 50, height: 50 }}>
                              <SwapHoriz />
                            </Avatar>
                            <Box sx={{ flex: 1 }}>
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                  طلب نقل #{approval.transferId}
                                </Typography>
                                <Chip 
                                  label={getStatusLabel(approval.status)}
                                  color={getStatusColor(approval.status)}
                                  size="small"
                                />
                              </Box>
                              
                              <Box sx={{ mb: 2 }}>
                                <Typography variant="body2" color="text.secondary">
                                  الطالب: <strong>{approval.studentName || approval.studentId}</strong>
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                  من: <Chip label={approval.fromUniversityName || approval.fromUniversity} size="small" sx={{ mx: 0.5 }} />
                                  إلى: <Chip label={approval.toUniversityName || approval.toUniversity} size="small" color="primary" sx={{ mx: 0.5 }} />
                                </Typography>
                                {approval.reason && (
                                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                                    السبب: {approval.reason}
                                  </Typography>
                                )}
                              </Box>

                              {canApprove(approval) && (
                                <Box sx={{ display: 'flex', gap: 1 }}>
                                  <Button
                                    variant="contained"
                                    color="success"
                                    startIcon={<ThumbUp />}
                                    onClick={() => handleOpenDialog(approval, 'approve')}
                                  >
                                    موافقة
                                  </Button>
                                  <Button
                                    variant="outlined"
                                    color="error"
                                    startIcon={<ThumbDown />}
                                    onClick={() => handleOpenDialog(approval, 'reject')}
                                  >
                                    رفض
                                  </Button>
                                </Box>
                              )}
                            </Box>
                          </Box>
                        </Grid>

                        {/* Approval Steps */}
                        <Grid item xs={12} md={6}>
                          <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                            مراحل الموافقة
                          </Typography>
                          <Stepper orientation="vertical" activeStep={-1}>
                            {approval.approvalSteps?.map((step, index) => (
                              <Step key={index} completed={step.status === 'approved'} active={step.status === 'pending'}>
                                <StepLabel
                                  error={step.status === 'rejected'}
                                  optional={
                                    step.approvedBy && (
                                      <Typography variant="caption">
                                        {step.approvedBy} - {new Date(step.approvedAt).toLocaleDateString('ar-SA')}
                                      </Typography>
                                    )
                                  }
                                  StepIconProps={{
                                    sx: {
                                      color: step.status === 'approved' ? 'success.main' : 
                                             step.status === 'pending' ? 'warning.main' : 
                                             step.status === 'rejected' ? 'error.main' : 'grey.400'
                                    }
                                  }}
                                >
                                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                    {step.label}
                                    {step.status === 'pending' && (
                                      <Chip label="بانتظار" size="small" color="warning" />
                                    )}
                                    {step.status === 'approved' && (
                                      <CheckCircle color="success" fontSize="small" />
                                    )}
                                  </Box>
                                </StepLabel>
                              </Step>
                            ))}
                          </Stepper>
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
          </Grid>
        )}
      </Paper>

      {/* Action Dialog */}
      <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {actionType === 'approve' ? 'تأكيد الموافقة' : 'تأكيد الرفض'}
        </DialogTitle>
        <DialogContent>
          {selectedApproval && (
            <Box>
              <Alert severity={actionType === 'approve' ? 'info' : 'warning'} sx={{ mb: 3 }}>
                {actionType === 'approve' 
                  ? 'أنت على وشك الموافقة على هذا الطلب. سيتم تسجيل موافقتك على البلوك تشين.'
                  : 'أنت على وشك رفض هذا الطلب. يرجى إدخال سبب الرفض.'}
              </Alert>
              
              <Typography variant="body2" sx={{ mb: 2 }}>
                <strong>رقم الطلب:</strong> {selectedApproval.transferId}<br />
                <strong>الطالب:</strong> {selectedApproval.studentName || selectedApproval.studentId}<br />
                <strong>النقل:</strong> من {selectedApproval.fromUniversity} إلى {selectedApproval.toUniversity}
              </Typography>

              <TextField
                fullWidth
                multiline
                rows={3}
                label={actionType === 'approve' ? 'ملاحظات (اختياري)' : 'سبب الرفض (مطلوب)'}
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                required={actionType === 'reject'}
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>إلغاء</Button>
          <Button
            variant="contained"
            color={actionType === 'approve' ? 'success' : 'error'}
            onClick={handleSubmitAction}
            disabled={processing || (actionType === 'reject' && !comments.trim())}
          >
            {processing ? <CircularProgress size={24} /> : actionType === 'approve' ? 'موافقة' : 'رفض'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
