import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  TextField,
  Button,
  Typography,
  Box,
  Chip,
  IconButton,
  InputAdornment,
  CircularProgress,
  Alert
} from '@mui/material';
import {
  Add,
  Search,
  Visibility,
  People,
  School
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

export default function StudentList() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [students, setStudents] = useState([]);
  const [filteredStudents, setFilteredStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    loadStudents();
  }, [user]);

  useEffect(() => {
    filterStudents();
  }, [searchTerm, students]);

  const loadStudents = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.get('/api/students');
      const allStudents = response.data.data?.students || [];
      
      // Filter students based on user role
      let studentsToShow = allStudents;
      if (user?.universityId !== 'MINISTRY') {
        // Universities see only their students
        studentsToShow = allStudents.filter(
          s => s.currentUniversity === user?.universityId
        );
      }
      
      setStudents(studentsToShow);
      setFilteredStudents(studentsToShow);
    } catch (error) {
      console.error('Error loading students:', error);
      setError(error.response?.data?.message || 'فشل في تحميل بيانات الطلاب');
      setStudents([]);
      setFilteredStudents([]);
    } finally {
      setLoading(false);
    }
  };

  const filterStudents = () => {
    if (!searchTerm.trim()) {
      setFilteredStudents(students);
      return;
    }

    const term = searchTerm.toLowerCase();
    const filtered = students.filter(student =>
      student.studentId?.toLowerCase().includes(term) ||
      student.fullName?.toLowerCase().includes(term) ||
      student.nationalId?.toLowerCase().includes(term) ||
      student.currentUniversity?.toLowerCase().includes(term) ||
      student.major?.toLowerCase().includes(term)
    );
    setFilteredStudents(filtered);
    setPage(0);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
          <Box textAlign="center">
            <CircularProgress size={60} />
            <Typography variant="body1" sx={{ mt: 2 }}>
              جاري تحميل بيانات الطلاب...
            </Typography>
          </Box>
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {/* Header */}
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
            قائمة الطلاب
          </Typography>
          <Typography variant="body1" color="text.secondary">
            {user?.universityId === 'MINISTRY' 
              ? 'جميع طلاب الجامعات في النظام'
              : `طلاب ${user?.universityId}`
            }
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => navigate('/students/create')}
          size="large"
        >
          إضافة طالب
        </Button>
      </Box>

      {/* Error Alert */}
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {/* Search Bar */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <TextField
          fullWidth
          placeholder="ابحث برقم الطالب، الاسم، رقم الهوية، الجامعة، أو التخصص..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Search />
              </InputAdornment>
            ),
          }}
        />
      </Paper>

      {/* Empty State */}
      {!error && filteredStudents.length === 0 && (
        <Paper sx={{ p: 8, textAlign: 'center' }}>
          {searchTerm ? (
            <>
              <Search sx={{ fontSize: 80, color: 'text.secondary', mb: 2 }} />
              <Typography variant="h5" gutterBottom>
                لا توجد نتائج
              </Typography>
              <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
                لم نجد أي طلاب يطابقون بحثك: "{searchTerm}"
              </Typography>
              <Button variant="outlined" onClick={() => setSearchTerm('')}>
                مسح البحث
              </Button>
            </>
          ) : (
            <>
              <People sx={{ fontSize: 80, color: 'text.secondary', mb: 2 }} />
              <Typography variant="h5" gutterBottom>
                لا يوجد طلاب مسجلين
              </Typography>
              <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
                ابدأ بإضافة أول طالب في النظام
              </Typography>
              <Button
                variant="contained"
                startIcon={<Add />}
                onClick={() => navigate('/students/create')}
                size="large"
              >
                إضافة طالب جديد
              </Button>
            </>
          )}
        </Paper>
      )}

      {/* Students Table */}
      {!error && filteredStudents.length > 0 && (
        <Paper>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>رقم الطالب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الاسم الكامل</TableCell>
                  {user?.universityId === 'MINISTRY' && (
                    <TableCell sx={{ fontWeight: 700 }}>الجامعة</TableCell>
                  )}
                  <TableCell sx={{ fontWeight: 700 }}>التخصص</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>المعدل</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الحالة</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الإجراءات</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredStudents
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((student) => (
                    <TableRow key={student.studentId} hover>
                      <TableCell>{student.studentId}</TableCell>
                      <TableCell>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {student.fullName}
                        </Typography>
                      </TableCell>
                      {user?.universityId === 'MINISTRY' && (
                        <TableCell>
                          <Chip
                            icon={<School />}
                            label={student.currentUniversity}
                            size="small"
                            color="primary"
                            variant="outlined"
                          />
                        </TableCell>
                      )}
                      <TableCell>{student.major || '-'}</TableCell>
                      <TableCell>
                        {student.gpa ? (
                          <Chip
                            label={student.gpa}
                            size="small"
                            color={
                              student.gpa >= 4.5 ? 'success' :
                              student.gpa >= 3.5 ? 'primary' :
                              student.gpa >= 2.5 ? 'warning' : 'error'
                            }
                          />
                        ) : '-'}
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={
                            student.status === 'active' ? 'نشط' :
                            student.status === 'suspended' ? 'موقوف' :
                            student.status === 'graduated' ? 'متخرج' : student.status
                          }
                          size="small"
                          color={
                            student.status === 'active' ? 'success' :
                            student.status === 'suspended' ? 'error' :
                            student.status === 'graduated' ? 'info' : 'default'
                          }
                        />
                      </TableCell>
                      <TableCell>
                        <IconButton
                          size="small"
                          color="primary"
                          onClick={() => navigate(`/students/${student.studentId}`)}
                        >
                          <Visibility />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            component="div"
            count={filteredStudents.length}
            page={page}
            onPageChange={handleChangePage}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            labelRowsPerPage="عدد الصفوف:"
            labelDisplayedRows={({ from, to, count }) => `${from}-${to} من ${count}`}
          />
        </Paper>
      )}
    </Container>
  );
}
