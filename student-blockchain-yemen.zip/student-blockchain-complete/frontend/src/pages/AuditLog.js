import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Button,
  TextField,
  MenuItem,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  CircularProgress,
  InputAdornment,
  Pagination,
  Card,
  CardContent,
  Tooltip
} from '@mui/material';
import {
  History,
  Search,
  Visibility,
  FilterList,
  Download,
  Person,
  School,
  SwapHoriz,
  Edit,
  Add,
  CheckCircle,
  Cancel,
  ContentCopy
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';

export default function AuditLog() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [logs, setLogs] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filters, setFilters] = useState({
    type: 'all',
    university: 'all',
    dateFrom: '',
    dateTo: '',
    search: ''
  });
  const [selectedLog, setSelectedLog] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const isMinistry = user?.universityId === 'MINISTRY';

  useEffect(() => {
    loadAuditLogs();
  }, [page, filters]);

  const loadAuditLogs = async () => {
    try {
      setLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Mock audit log data with Yemeni universities
      const mockLogs = [
        {
          id: 'TX001',
          txHash: '0x7f9e8d7c6b5a4e3d2c1b0a9f8e7d6c5b4a3f2e1d',
          type: 'student_create',
          action: 'إنشاء سجل طالب',
          userId: 'USR001',
          userName: 'أحمد محمد الحميري',
          userRole: 'registrar',
          university: 'UNI001',
          universityName: 'جامعة صنعاء',
          targetId: 'STU001',
          targetName: 'عبدالله أحمد الصنعاني',
          timestamp: new Date().toISOString(),
          blockNumber: 12458,
          status: 'success',
          details: {
            studentId: 'STU001',
            fullName: 'عبدالله أحمد الصنعاني',
            nationalId: '0100234567',
            major: 'هندسة الحاسوب'
          }
        },
        {
          id: 'TX002',
          txHash: '0x8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b',
          type: 'student_update',
          action: 'تحديث بيانات طالب',
          userId: 'USR001',
          userName: 'أحمد محمد الحميري',
          userRole: 'registrar',
          university: 'UNI001',
          universityName: 'جامعة صنعاء',
          targetId: 'STU002',
          targetName: 'فاطمة علي المقطري',
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          blockNumber: 12457,
          status: 'success',
          details: {
            field: 'gpa',
            oldValue: '3.8',
            newValue: '4.0'
          }
        },
        {
          id: 'TX003',
          txHash: '0x1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c',
          type: 'transfer_request',
          action: 'طلب نقل طالب',
          userId: 'USR002',
          userName: 'محمد عبدالكريم باوزير',
          userRole: 'university_admin',
          university: 'UNI002',
          universityName: 'جامعة عدن',
          targetId: 'STU003',
          targetName: 'خالد سالم العدني',
          timestamp: new Date(Date.now() - 7200000).toISOString(),
          blockNumber: 12456,
          status: 'success',
          details: {
            fromUniversity: 'UNI002',
            toUniversity: 'UNI001',
            reason: 'الانتقال للدراسة في صنعاء'
          }
        },
        {
          id: 'TX004',
          txHash: '0x2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d',
          type: 'transfer_approve',
          action: 'موافقة على نقل',
          userId: 'USR003',
          userName: 'مشرف الوزارة',
          userRole: 'admin',
          university: 'MINISTRY',
          universityName: 'وزارة التعليم العالي',
          targetId: 'TRF001',
          targetName: 'طلب نقل #TRF001',
          timestamp: new Date(Date.now() - 10800000).toISOString(),
          blockNumber: 12455,
          status: 'success',
          details: {
            approvedBy: 'ministry',
            comments: 'تمت الموافقة بعد مراجعة الملف'
          }
        },
        {
          id: 'TX005',
          txHash: '0x3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e',
          type: 'transfer_reject',
          action: 'رفض نقل',
          userId: 'USR004',
          userName: 'عبدالرحمن الشرجبي',
          userRole: 'registrar',
          university: 'UNI003',
          universityName: 'جامعة تعز',
          targetId: 'TRF002',
          targetName: 'طلب نقل #TRF002',
          timestamp: new Date(Date.now() - 14400000).toISOString(),
          blockNumber: 12454,
          status: 'success',
          details: {
            rejectedBy: 'source_university',
            reason: 'الطالب لديه مواد غير مكتملة'
          }
        }
      ];
      
      setLogs(mockLogs);
      setTotalPages(5);
    } catch (error) {
      console.error('Error loading audit logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (log) => {
    setSelectedLog(log);
    setDialogOpen(true);
  };

  const handleCopyHash = (hash) => {
    navigator.clipboard.writeText(hash);
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'student_create': return <Add color="success" />;
      case 'student_update': return <Edit color="info" />;
      case 'transfer_request': return <SwapHoriz color="warning" />;
      case 'transfer_approve': return <CheckCircle color="success" />;
      case 'transfer_reject': return <Cancel color="error" />;
      default: return <History />;
    }
  };

  const getTypeLabel = (type) => {
    switch (type) {
      case 'student_create': return 'إنشاء طالب';
      case 'student_update': return 'تحديث بيانات';
      case 'transfer_request': return 'طلب نقل';
      case 'transfer_approve': return 'موافقة نقل';
      case 'transfer_reject': return 'رفض نقل';
      default: return type;
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'student_create': return 'success';
      case 'student_update': return 'info';
      case 'transfer_request': return 'warning';
      case 'transfer_approve': return 'success';
      case 'transfer_reject': return 'error';
      default: return 'default';
    }
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
            سجل التدقيق
          </Typography>
          <Typography variant="body1" color="text.secondary">
            سجل كامل لجميع المعاملات المسجلة على البلوك تشين
          </Typography>
        </Box>
        <Button
          variant="outlined"
          startIcon={<Download />}
        >
          تصدير السجل
        </Button>
      </Box>

      {/* Stats */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Add sx={{ fontSize: 40, color: 'success.main', opacity: 0.7 }} />
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 700 }}>
                    1,245
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    إنشاء سجلات
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Edit sx={{ fontSize: 40, color: 'info.main', opacity: 0.7 }} />
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 700 }}>
                    856
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    تحديثات
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <SwapHoriz sx={{ fontSize: 40, color: 'warning.main', opacity: 0.7 }} />
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 700 }}>
                    234
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    طلبات نقل
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <CheckCircle sx={{ fontSize: 40, color: 'success.main', opacity: 0.7 }} />
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 700 }}>
                    198
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    موافقات
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Filters */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={3}>
            <TextField
              fullWidth
              size="small"
              label="بحث"
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search />
                  </InputAdornment>
                ),
              }}
              placeholder="اسم، معرف، أو hash..."
            />
          </Grid>
          <Grid item xs={12} md={2}>
            <TextField
              fullWidth
              size="small"
              select
              label="نوع العملية"
              value={filters.type}
              onChange={(e) => setFilters({ ...filters, type: e.target.value })}
            >
              <MenuItem value="all">الكل</MenuItem>
              <MenuItem value="student_create">إنشاء طالب</MenuItem>
              <MenuItem value="student_update">تحديث بيانات</MenuItem>
              <MenuItem value="transfer_request">طلب نقل</MenuItem>
              <MenuItem value="transfer_approve">موافقة</MenuItem>
              <MenuItem value="transfer_reject">رفض</MenuItem>
            </TextField>
          </Grid>
          {isMinistry && (
            <Grid item xs={12} md={2}>
              <TextField
                fullWidth
                size="small"
                select
                label="الجامعة"
                value={filters.university}
                onChange={(e) => setFilters({ ...filters, university: e.target.value })}
              >
                <MenuItem value="all">الكل</MenuItem>
                <MenuItem value="UNI001">جامعة صنعاء</MenuItem>
                <MenuItem value="UNI002">جامعة عدن</MenuItem>
                <MenuItem value="UNI003">جامعة تعز</MenuItem>
                <MenuItem value="UNI004">جامعة الحديدة</MenuItem>
                <MenuItem value="UNI005">جامعة إب</MenuItem>
                <MenuItem value="UNI006">جامعة حضرموت</MenuItem>
                <MenuItem value="UNI007">جامعة ذمار</MenuItem>
                <MenuItem value="UNI008">جامعة العلوم والتكنولوجيا</MenuItem>
                <MenuItem value="MINISTRY">الوزارة</MenuItem>
              </TextField>
            </Grid>
          )}
          <Grid item xs={12} md={2}>
            <TextField
              fullWidth
              size="small"
              type="date"
              label="من تاريخ"
              value={filters.dateFrom}
              onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value })}
              InputLabelProps={{ shrink: true }}
            />
          </Grid>
          <Grid item xs={12} md={2}>
            <TextField
              fullWidth
              size="small"
              type="date"
              label="إلى تاريخ"
              value={filters.dateTo}
              onChange={(e) => setFilters({ ...filters, dateTo: e.target.value })}
              InputLabelProps={{ shrink: true }}
            />
          </Grid>
          <Grid item xs={12} md={1}>
            <Button
              fullWidth
              variant="contained"
              startIcon={<FilterList />}
              onClick={loadAuditLogs}
            >
              تصفية
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* Logs Table */}
      <Paper sx={{ p: 3 }}>
        {loading ? (
          <Box display="flex" justifyContent="center" py={4}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 700 }}>النوع</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>الإجراء</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>المستخدم</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>الجامعة</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>الهدف</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>الكتلة</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>التاريخ</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>إجراءات</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {logs.map((log) => (
                    <TableRow key={log.id} hover>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          {getTypeIcon(log.type)}
                          <Chip 
                            label={getTypeLabel(log.type)}
                            size="small"
                            color={getTypeColor(log.type)}
                          />
                        </Box>
                      </TableCell>
                      <TableCell>{log.action}</TableCell>
                      <TableCell>
                        <Box>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {log.userName}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {log.userRole === 'admin' ? 'مدير' : 
                             log.userRole === 'university_admin' ? 'مدير جامعة' : 'موظف'}
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Chip 
                          label={log.universityName}
                          size="small"
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell>
                        <Box>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {log.targetName}
                          </Typography>
                          <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'monospace' }}>
                            {log.targetId}
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Chip 
                          label={`#${log.blockNumber}`}
                          size="small"
                          sx={{ fontFamily: 'monospace' }}
                        />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {new Date(log.timestamp).toLocaleDateString('ar-SA')}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {new Date(log.timestamp).toLocaleTimeString('ar-SA')}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Tooltip title="عرض التفاصيل">
                          <IconButton 
                            size="small"
                            onClick={() => handleViewDetails(log)}
                          >
                            <Visibility />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="نسخ Hash">
                          <IconButton 
                            size="small"
                            onClick={() => handleCopyHash(log.txHash)}
                          >
                            <ContentCopy />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>

            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
              <Pagination 
                count={totalPages} 
                page={page} 
                onChange={(e, v) => setPage(v)}
                color="primary"
              />
            </Box>
          </>
        )}
      </Paper>

      {/* Details Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="md" fullWidth>
        {selectedLog && (
          <>
            <DialogTitle>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                {getTypeIcon(selectedLog.type)}
                <Box>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    تفاصيل المعاملة
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {selectedLog.action}
                  </Typography>
                </Box>
              </Box>
            </DialogTitle>
            <DialogContent dividers>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', wordBreak: 'break-all' }}>
                      <strong>Transaction Hash:</strong> {selectedLog.txHash}
                    </Typography>
                  </Alert>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    معلومات المعاملة
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2" color="text.secondary">رقم الكتلة</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>#{selectedLog.blockNumber}</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2" color="text.secondary">التاريخ</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {new Date(selectedLog.timestamp).toLocaleString('ar-SA')}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2" color="text.secondary">الحالة</Typography>
                      <Chip label="ناجح" color="success" size="small" />
                    </Box>
                  </Box>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    المستخدم المنفذ
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2" color="text.secondary">الاسم</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedLog.userName}</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2" color="text.secondary">الدور</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedLog.userRole}</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2" color="text.secondary">الجامعة</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedLog.universityName}</Typography>
                    </Box>
                  </Box>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    تفاصيل العملية
                  </Typography>
                  <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50' }}>
                    <pre style={{ margin: 0, fontFamily: 'monospace', fontSize: '0.85rem', overflow: 'auto' }}>
                      {JSON.stringify(selectedLog.details, null, 2)}
                    </pre>
                  </Paper>
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setDialogOpen(false)}>إغلاق</Button>
              <Button 
                variant="outlined"
                startIcon={<ContentCopy />}
                onClick={() => handleCopyHash(selectedLog.txHash)}
              >
                نسخ Hash
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
}
