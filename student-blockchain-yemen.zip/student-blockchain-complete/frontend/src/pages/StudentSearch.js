import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  TextField,
  Button,
  Typography,
  Grid,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  InputAdornment,
  Alert,
  CircularProgress,
  Divider,
  MenuItem,
  Tabs,
  Tab
} from '@mui/material';
import {
  Search,
  Person,
  School,
  Visibility,
  VerifiedUser,
  History,
  Badge,
  QrCode2
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

export default function StudentSearch() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [searchType, setSearchType] = useState('id');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searched, setSearched] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);

  const isMinistry = user?.universityId === 'MINISTRY';

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    setSearched(true);
    
    try {
      // In real implementation, this would call the API
      const response = await axios.get(`/api/students/search?${searchType}=${searchQuery}`);
      setSearchResults(response.data.data?.students || []);
    } catch (error) {
      console.error('Search error:', error);
      // For demo, show mock data with Yemeni universities
      setSearchResults([
        {
          studentId: 'STU001',
          fullName: 'عبدالله أحمد الصنعاني',
          nationalId: '0100234567',
          currentUniversity: 'UNI001',
          universityName: 'جامعة صنعاء',
          faculty: 'كلية الهندسة',
          major: 'هندسة الحاسوب',
          gpa: 4.2,
          status: 'active',
          enrollmentDate: '2021-09-01',
          academicLevel: '6'
        },
        {
          studentId: 'STU002',
          fullName: 'فاطمة علي المقطري',
          nationalId: '0200345678',
          currentUniversity: 'UNI002',
          universityName: 'جامعة عدن',
          faculty: 'كلية الطب',
          major: 'الطب والجراحة',
          gpa: 4.5,
          status: 'active',
          enrollmentDate: '2020-09-01',
          academicLevel: '8'
        },
        {
          studentId: 'STU003',
          fullName: 'محمد سالم التعزي',
          nationalId: '0300456789',
          currentUniversity: 'UNI003',
          universityName: 'جامعة تعز',
          faculty: 'كلية التربية',
          major: 'الرياضيات',
          gpa: 3.8,
          status: 'active',
          enrollmentDate: '2022-09-01',
          academicLevel: '4'
        }
      ].filter(s => {
        if (searchType === 'id') return s.studentId.includes(searchQuery) || s.nationalId.includes(searchQuery);
        if (searchType === 'name') return s.fullName.includes(searchQuery);
        return true;
      }));
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyStudent = (student) => {
    setSelectedStudent(student);
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
          البحث عن طالب والتحقق
        </Typography>
        <Typography variant="body1" color="text.secondary">
          ابحث عن طالب في النظام للتحقق من بياناته الأكاديمية عبر البلوك تشين
        </Typography>
      </Box>

      {/* Search Section */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" sx={{ fontWeight: 600, mb: 3, display: 'flex', alignItems: 'center', gap: 1 }}>
          <Search /> بحث متقدم
        </Typography>

        <Grid container spacing={2} alignItems="flex-end">
          <Grid item xs={12} md={3}>
            <TextField
              fullWidth
              select
              label="نوع البحث"
              value={searchType}
              onChange={(e) => setSearchType(e.target.value)}
            >
              <MenuItem value="id">رقم الطالب / الهوية</MenuItem>
              <MenuItem value="name">الاسم</MenuItem>
              <MenuItem value="university">الجامعة</MenuItem>
            </TextField>
          </Grid>
          <Grid item xs={12} md={7}>
            <TextField
              fullWidth
              label="كلمة البحث"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search />
                  </InputAdornment>
                ),
              }}
              placeholder={
                searchType === 'id' ? 'أدخل رقم الطالب أو رقم الهوية...' :
                searchType === 'name' ? 'أدخل اسم الطالب...' :
                'أدخل اسم الجامعة...'
              }
            />
          </Grid>
          <Grid item xs={12} md={2}>
            <Button
              fullWidth
              variant="contained"
              size="large"
              onClick={handleSearch}
              disabled={loading || !searchQuery.trim()}
              sx={{ height: 56 }}
            >
              {loading ? <CircularProgress size={24} /> : 'بحث'}
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* Search Results */}
      {searched && (
        <Grid container spacing={3}>
          <Grid item xs={12} md={selectedStudent ? 7 : 12}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                نتائج البحث ({searchResults.length})
              </Typography>

              {searchResults.length === 0 ? (
                <Alert severity="info">
                  لم يتم العثور على نتائج. تأكد من صحة البيانات المدخلة.
                </Alert>
              ) : (
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell sx={{ fontWeight: 700 }}>رقم الطالب</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>الاسم</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>الجامعة</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>التخصص</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>الحالة</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>إجراءات</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {searchResults.map((student) => (
                        <TableRow 
                          key={student.studentId} 
                          hover
                          selected={selectedStudent?.studentId === student.studentId}
                          sx={{ cursor: 'pointer' }}
                          onClick={() => handleVerifyStudent(student)}
                        >
                          <TableCell>{student.studentId}</TableCell>
                          <TableCell>{student.fullName}</TableCell>
                          <TableCell>
                            <Chip 
                              label={student.universityName || student.currentUniversity} 
                              size="small" 
                              variant="outlined"
                            />
                          </TableCell>
                          <TableCell>{student.major}</TableCell>
                          <TableCell>
                            <Chip
                              label={student.status === 'active' ? 'نشط' : 'غير نشط'}
                              color={student.status === 'active' ? 'success' : 'default'}
                              size="small"
                            />
                          </TableCell>
                          <TableCell>
                            <IconButton
                              size="small"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/students/${student.studentId}`);
                              }}
                              color="primary"
                            >
                              <Visibility />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </Paper>
          </Grid>

          {/* Verification Panel */}
          {selectedStudent && (
            <Grid item xs={12} md={5}>
              <Paper sx={{ p: 3, position: 'sticky', top: 80 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
                  <VerifiedUser color="success" />
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    التحقق من البيانات
                  </Typography>
                </Box>

                <Alert severity="success" sx={{ mb: 3 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                    ✓ تم التحقق من البيانات عبر البلوك تشين
                  </Typography>
                  <Typography variant="caption">
                    البيانات مسجلة وموثقة ولا يمكن التلاعب بها
                  </Typography>
                </Alert>

                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                      <Box sx={{
                        width: 60,
                        height: 60,
                        borderRadius: '50%',
                        bgcolor: 'primary.main',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'white',
                        fontSize: '1.5rem',
                        fontWeight: 700
                      }}>
                        {selectedStudent.fullName?.charAt(0)}
                      </Box>
                      <Box>
                        <Typography variant="h6" sx={{ fontWeight: 600 }}>
                          {selectedStudent.fullName}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {selectedStudent.studentId}
                        </Typography>
                      </Box>
                    </Box>
                    <Divider sx={{ my: 2 }} />
                    
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Typography variant="caption" color="text.secondary">الجامعة</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {selectedStudent.universityName || selectedStudent.currentUniversity}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" color="text.secondary">الكلية</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {selectedStudent.faculty}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" color="text.secondary">التخصص</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {selectedStudent.major}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" color="text.secondary">المعدل التراكمي</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {selectedStudent.gpa || 'غير متوفر'}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" color="text.secondary">المستوى</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {selectedStudent.academicLevel}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" color="text.secondary">تاريخ الالتحاق</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {selectedStudent.enrollmentDate}
                        </Typography>
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>

                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Button
                    fullWidth
                    variant="contained"
                    startIcon={<Visibility />}
                    onClick={() => navigate(`/students/${selectedStudent.studentId}`)}
                  >
                    عرض كامل
                  </Button>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<History />}
                    onClick={() => navigate(`/students/${selectedStudent.studentId}?tab=history`)}
                  >
                    السجل
                  </Button>
                </Box>

                <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.100', borderRadius: 2 }}>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                    معرف البلوك تشين
                  </Typography>
                  <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }}>
                    0x{Math.random().toString(16).slice(2, 18)}...
                  </Typography>
                </Box>
              </Paper>
            </Grid>
          )}
        </Grid>
      )}

      {/* Info Cards */}
      {!searched && (
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                  <Badge sx={{ p: 1.5, bgcolor: 'primary.light', borderRadius: 2, color: 'primary.main' }} />
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>البحث برقم الهوية</Typography>
                </Box>
                <Typography variant="body2" color="text.secondary">
                  ابحث عن طالب باستخدام رقم الهوية الوطنية أو رقم الطالب الجامعي للتحقق من صحة بياناته.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                  <VerifiedUser sx={{ p: 1.5, bgcolor: 'success.light', borderRadius: 2, color: 'success.main' }} />
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>التحقق الفوري</Typography>
                </Box>
                <Typography variant="body2" color="text.secondary">
                  يتم التحقق من البيانات فوراً عبر شبكة البلوك تشين لضمان صحة ومصداقية المعلومات.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                  <History sx={{ p: 1.5, bgcolor: 'warning.light', borderRadius: 2, color: 'warning.main' }} />
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>سجل كامل</Typography>
                </Box>
                <Typography variant="body2" color="text.secondary">
                  اطلع على السجل الكامل للطالب متضمناً جميع التعديلات والنقل بين الجامعات.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}
    </Box>
  );
}
