import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  CircularProgress,
  Avatar,
  LinearProgress,
  Tooltip,
  MenuItem
} from '@mui/material';
import {
  Business,
  Add,
  Edit,
  Visibility,
  People,
  CheckCircle,
  Warning,
  Storage,
  TrendingUp,
  School,
  LocationOn,
  Phone,
  Email,
  Person
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { toast } from 'react-toastify';

export default function UniversityManagement() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [universities, setUniversities] = useState([]);
  const [selectedUniversity, setSelectedUniversity] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState('view');

  // Redirect if not ministry
  const isMinistry = user?.universityId === 'MINISTRY';

  useEffect(() => {
    if (!isMinistry) {
      navigate('/dashboard');
      return;
    }
    loadUniversities();
  }, [isMinistry]);

  const loadUniversities = async () => {
    try {
      setLoading(true);
      // Real Yemeni Universities Data
      setUniversities([
        {
          id: 'UNI001',
          name: 'جامعة صنعاء',
          nameEn: 'Sana\'a University',
          city: 'صنعاء',
          region: 'أمانة العاصمة',
          studentCount: 85000,
          activeStudents: 78500,
          pendingTransfers: 15,
          nodeStatus: 'active',
          lastSync: new Date().toISOString(),
          contactPerson: 'أ.د. القاسم محمد عباس',
          contactEmail: 'admin@su.edu.ye',
          contactPhone: '+967-1-331185',
          joinDate: '2024-01-15',
          certificateValid: true,
          founded: '1970',
          website: 'www.su.edu.ye',
          colleges: ['الطب', 'الهندسة', 'العلوم', 'التربية', 'الحقوق', 'التجارة', 'الآداب', 'الزراعة', 'الحاسوب']
        },
        {
          id: 'UNI002',
          name: 'جامعة عدن',
          nameEn: 'University of Aden',
          city: 'عدن',
          region: 'محافظة عدن',
          studentCount: 45000,
          activeStudents: 41200,
          pendingTransfers: 8,
          nodeStatus: 'active',
          lastSync: new Date().toISOString(),
          contactPerson: 'أ.د. الخضر ناصر لصور',
          contactEmail: 'admin@aden-univ.edu.ye',
          contactPhone: '+967-2-232471',
          joinDate: '2024-01-15',
          certificateValid: true,
          founded: '1975',
          website: 'www.aden-univ.edu.ye',
          colleges: ['الطب', 'الهندسة', 'العلوم', 'التربية', 'الحقوق', 'الاقتصاد', 'النفط والمعادن']
        },
        {
          id: 'UNI003',
          name: 'جامعة تعز',
          nameEn: 'Taiz University',
          city: 'تعز',
          region: 'محافظة تعز',
          studentCount: 52000,
          activeStudents: 48000,
          pendingTransfers: 12,
          nodeStatus: 'active',
          lastSync: new Date().toISOString(),
          contactPerson: 'أ.د. عبدالباسط الهدار',
          contactEmail: 'admin@taiz-univ.edu.ye',
          contactPhone: '+967-4-225907',
          joinDate: '2024-02-01',
          certificateValid: true,
          founded: '1995',
          website: 'www.taiz-univ.edu.ye',
          colleges: ['الطب', 'الهندسة', 'العلوم', 'التربية', 'الآداب', 'الشريعة والقانون', 'العلوم الإدارية']
        },
        {
          id: 'UNI004',
          name: 'جامعة الحديدة',
          nameEn: 'Hodeidah University',
          city: 'الحديدة',
          region: 'محافظة الحديدة',
          studentCount: 28000,
          activeStudents: 25500,
          pendingTransfers: 5,
          nodeStatus: 'active',
          lastSync: new Date(Date.now() - 120000).toISOString(),
          contactPerson: 'أ.د. حسن أحمد شرف الدين',
          contactEmail: 'admin@hoduniv.edu.ye',
          contactPhone: '+967-3-211468',
          joinDate: '2024-02-15',
          certificateValid: true,
          founded: '1996',
          website: 'www.hoduniv.edu.ye',
          colleges: ['التربية', 'العلوم', 'الآداب', 'العلوم الإدارية', 'العلوم البحرية']
        },
        {
          id: 'UNI005',
          name: 'جامعة إب',
          nameEn: 'Ibb University',
          city: 'إب',
          region: 'محافظة إب',
          studentCount: 35000,
          activeStudents: 32000,
          pendingTransfers: 7,
          nodeStatus: 'active',
          lastSync: new Date().toISOString(),
          contactPerson: 'أ.د. عبدالوهاب عبده أنعم',
          contactEmail: 'admin@ibb-univ.edu.ye',
          contactPhone: '+967-4-402667',
          joinDate: '2024-02-01',
          certificateValid: true,
          founded: '1996',
          website: 'www.ibb-univ.edu.ye',
          colleges: ['الطب', 'الهندسة', 'العلوم', 'التربية', 'الآداب', 'الزراعة']
        },
        {
          id: 'UNI006',
          name: 'جامعة حضرموت',
          nameEn: 'Hadhramout University',
          city: 'المكلا',
          region: 'محافظة حضرموت',
          studentCount: 22000,
          activeStudents: 20100,
          pendingTransfers: 4,
          nodeStatus: 'syncing',
          lastSync: new Date(Date.now() - 300000).toISOString(),
          contactPerson: 'أ.د. محمد سعيد خنبش',
          contactEmail: 'admin@hu.edu.ye',
          contactPhone: '+967-5-354456',
          joinDate: '2024-03-01',
          certificateValid: true,
          founded: '1996',
          website: 'www.hu.edu.ye',
          colleges: ['الهندسة والبترول', 'العلوم', 'التربية', 'الآداب', 'العلوم الإدارية', 'البنات']
        },
        {
          id: 'UNI007',
          name: 'جامعة ذمار',
          nameEn: 'Thamar University',
          city: 'ذمار',
          region: 'محافظة ذمار',
          studentCount: 18000,
          activeStudents: 16500,
          pendingTransfers: 3,
          nodeStatus: 'active',
          lastSync: new Date().toISOString(),
          contactPerson: 'أ.د. محمد ناصر الأهدل',
          contactEmail: 'admin@tu.edu.ye',
          contactPhone: '+967-6-508401',
          joinDate: '2024-03-01',
          certificateValid: true,
          founded: '1996',
          website: 'www.tu.edu.ye',
          colleges: ['الطب', 'التربية', 'العلوم', 'الآداب', 'الزراعة والبيطرة']
        },
        {
          id: 'UNI008',
          name: 'جامعة العلوم والتكنولوجيا',
          nameEn: 'University of Science and Technology',
          city: 'صنعاء',
          region: 'أمانة العاصمة',
          studentCount: 15000,
          activeStudents: 14200,
          pendingTransfers: 6,
          nodeStatus: 'active',
          lastSync: new Date().toISOString(),
          contactPerson: 'أ.د. حميد عقلان',
          contactEmail: 'admin@ust.edu.ye',
          contactPhone: '+967-1-310000',
          joinDate: '2024-01-20',
          certificateValid: true,
          founded: '1994',
          website: 'www.ust.edu.ye',
          type: 'خاصة',
          colleges: ['الطب', 'طب الأسنان', 'الهندسة', 'الحاسوب', 'العلوم الإدارية', 'الإعلام']
        }
      ]);
    } catch (error) {
      console.error('Error loading universities:', error);
      toast.error('فشل في تحميل بيانات الجامعات');
    } finally {
      setLoading(false);
    }
  };

  const handleViewUniversity = (university) => {
    setSelectedUniversity(university);
    setDialogMode('view');
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setSelectedUniversity(null);
  };

  const getNodeStatusColor = (status) => {
    switch (status) {
      case 'active': return 'success';
      case 'syncing': return 'warning';
      case 'offline': return 'error';
      default: return 'default';
    }
  };

  const getNodeStatusLabel = (status) => {
    switch (status) {
      case 'active': return 'نشط';
      case 'syncing': return 'جاري المزامنة';
      case 'offline': return 'غير متصل';
      default: return status;
    }
  };

  const totalStudents = universities.reduce((sum, u) => sum + u.studentCount, 0);
  const totalActive = universities.reduce((sum, u) => sum + u.activeStudents, 0);
  const totalPending = universities.reduce((sum, u) => sum + u.pendingTransfers, 0);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
            إدارة الجامعات
          </Typography>
          <Typography variant="body1" color="text.secondary">
            إدارة الجامعات المشاركة في شبكة البلوك تشين
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<Add />}
          sx={{ mt: 1 }}
        >
          إضافة جامعة
        </Button>
      </Box>

      {/* Stats */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={3}>
          <Card sx={{ background: 'linear-gradient(135deg, #1565c0 0%, #0d47a1 100%)', color: 'white' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {universities.length}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    جامعات مشاركة
                  </Typography>
                </Box>
                <Business sx={{ fontSize: 50, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {totalStudents.toLocaleString()}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    إجمالي الطلاب
                  </Typography>
                </Box>
                <People sx={{ fontSize: 50, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card sx={{ background: 'linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%)', color: 'white' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {universities.filter(u => u.nodeStatus === 'active').length}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    عقد نشطة
                  </Typography>
                </Box>
                <CheckCircle sx={{ fontSize: 50, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {totalPending}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    طلبات نقل معلقة
                  </Typography>
                </Box>
                <Warning sx={{ fontSize: 50, opacity: 0.3, color: 'warning.main' }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Universities Grid */}
      <Grid container spacing={3}>
        {universities.map((university) => (
          <Grid item xs={12} md={6} key={university.id}>
            <Card 
              sx={{ 
                height: '100%',
                cursor: 'pointer',
                transition: 'all 0.3s',
                '&:hover': {
                  transform: 'translateY(-4px)',
                  boxShadow: 4
                }
              }}
              onClick={() => handleViewUniversity(university)}
            >
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2, mb: 3 }}>
                  <Avatar 
                    sx={{ 
                      width: 60, 
                      height: 60, 
                      bgcolor: 'primary.main',
                      fontSize: '1.5rem'
                    }}
                  >
                    <School />
                  </Avatar>
                  <Box sx={{ flex: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                      <Typography variant="h6" sx={{ fontWeight: 700 }}>
                        {university.name}
                      </Typography>
                      <Chip 
                        label={getNodeStatusLabel(university.nodeStatus)}
                        color={getNodeStatusColor(university.nodeStatus)}
                        size="small"
                      />
                    </Box>
                    <Typography variant="body2" color="text.secondary">
                      {university.nameEn}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 0.5 }}>
                      <LocationOn fontSize="small" color="action" />
                      <Typography variant="caption" color="text.secondary">
                        {university.city} - {university.region}
                      </Typography>
                    </Box>
                  </Box>
                </Box>

                <Grid container spacing={2} sx={{ mb: 2 }}>
                  <Grid item xs={4}>
                    <Box sx={{ textAlign: 'center', p: 1.5, bgcolor: 'grey.50', borderRadius: 2 }}>
                      <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.main' }}>
                        {university.studentCount.toLocaleString()}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        طالب
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={4}>
                    <Box sx={{ textAlign: 'center', p: 1.5, bgcolor: 'success.50', borderRadius: 2 }}>
                      <Typography variant="h5" sx={{ fontWeight: 700, color: 'success.main' }}>
                        {university.activeStudents.toLocaleString()}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        نشط
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={4}>
                    <Box sx={{ textAlign: 'center', p: 1.5, bgcolor: 'warning.50', borderRadius: 2 }}>
                      <Typography variant="h5" sx={{ fontWeight: 700, color: 'warning.main' }}>
                        {university.pendingTransfers}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        نقل معلق
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>

                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box>
                    <Typography variant="caption" color="text.secondary">
                      آخر مزامنة: {new Date(university.lastSync).toLocaleTimeString('ar-SA')}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    <Tooltip title="عرض التفاصيل">
                      <IconButton size="small" color="primary">
                        <Visibility />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="عرض الطلاب">
                      <IconButton 
                        size="small"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate('/students', { state: { filterUniversity: university.id } });
                        }}
                      >
                        <People />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* University Detail Dialog */}
      <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        {selectedUniversity && (
          <>
            <DialogTitle>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Avatar sx={{ bgcolor: 'primary.main' }}>
                  <School />
                </Avatar>
                <Box>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    {selectedUniversity.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {selectedUniversity.nameEn}
                  </Typography>
                </Box>
              </Box>
            </DialogTitle>
            <DialogContent dividers>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    معلومات الجامعة
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Business fontSize="small" color="action" />
                      <Typography variant="body2">
                        معرف الجامعة: <strong>{selectedUniversity.id}</strong>
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <LocationOn fontSize="small" color="action" />
                      <Typography variant="body2">
                        {selectedUniversity.city} - {selectedUniversity.region}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Person fontSize="small" color="action" />
                      <Typography variant="body2">
                        المسؤول: {selectedUniversity.contactPerson}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Email fontSize="small" color="action" />
                      <Typography variant="body2">
                        {selectedUniversity.contactEmail}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Phone fontSize="small" color="action" />
                      <Typography variant="body2">
                        {selectedUniversity.contactPhone}
                      </Typography>
                    </Box>
                  </Box>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    حالة العقدة
                  </Typography>
                  <Alert 
                    severity={selectedUniversity.nodeStatus === 'active' ? 'success' : 'warning'}
                    sx={{ mb: 2 }}
                  >
                    <Typography variant="body2">
                      حالة العقدة: <strong>{getNodeStatusLabel(selectedUniversity.nodeStatus)}</strong>
                    </Typography>
                  </Alert>
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="caption" color="text.secondary">
                      تاريخ الانضمام للشبكة
                    </Typography>
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      {new Date(selectedUniversity.joinDate).toLocaleDateString('ar-SA')}
                    </Typography>
                  </Box>
                  <Box>
                    <Typography variant="caption" color="text.secondary">
                      آخر مزامنة
                    </Typography>
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      {new Date(selectedUniversity.lastSync).toLocaleString('ar-SA')}
                    </Typography>
                  </Box>
                  <Box sx={{ mt: 2 }}>
                    <Chip 
                      icon={<CheckCircle />}
                      label="الشهادة الرقمية صالحة"
                      color="success"
                      variant="outlined"
                    />
                  </Box>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    إحصائيات
                  </Typography>
                  <Grid container spacing={2}>
                    <Grid item xs={4}>
                      <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'primary.50' }}>
                        <Typography variant="h4" sx={{ fontWeight: 700, color: 'primary.main' }}>
                          {selectedUniversity.studentCount.toLocaleString()}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          إجمالي الطلاب
                        </Typography>
                      </Paper>
                    </Grid>
                    <Grid item xs={4}>
                      <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'success.50' }}>
                        <Typography variant="h4" sx={{ fontWeight: 700, color: 'success.main' }}>
                          {selectedUniversity.activeStudents.toLocaleString()}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          طلاب نشطين
                        </Typography>
                      </Paper>
                    </Grid>
                    <Grid item xs={4}>
                      <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'warning.50' }}>
                        <Typography variant="h4" sx={{ fontWeight: 700, color: 'warning.main' }}>
                          {selectedUniversity.pendingTransfers}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          طلبات نقل معلقة
                        </Typography>
                      </Paper>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseDialog}>إغلاق</Button>
              <Button 
                variant="contained"
                onClick={() => {
                  handleCloseDialog();
                  navigate('/students', { state: { filterUniversity: selectedUniversity.id } });
                }}
              >
                عرض الطلاب
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
}
