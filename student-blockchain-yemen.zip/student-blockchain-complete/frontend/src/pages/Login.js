import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  TextField,
  Button,
  Typography,
  Box,
  Alert,
  InputAdornment,
  IconButton,
  Divider,
  Stack,
  Grid,
  Card,
  CardContent,
  Chip,
  Fade
} from '@mui/material';
import {
  School,
  Person,
  Lock,
  Visibility,
  VisibilityOff,
  AdminPanelSettings,
  Security,
  VerifiedUser,
  Storage,
  SwapHoriz
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = await login(credentials.username, credentials.password);
    
    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.message);
    }
    setLoading(false);
  };

  const quickLogin = async (username, password) => {
    setError('');
    setLoading(true);
    
    const result = await login(username, password);
    
    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.message);
    }
    setLoading(false);
  };

  const features = [
    { icon: <Security />, title: 'أمان عالي', desc: 'تشفير متقدم للبيانات' },
    { icon: <Storage />, title: 'بلوك تشين', desc: 'سجلات غير قابلة للتعديل' },
    { icon: <SwapHoriz />, title: 'نقل الطلاب', desc: 'إجراءات موافقة متعددة' },
    { icon: <VerifiedUser />, title: 'تحقق موثوق', desc: 'مصداقية البيانات الأكاديمية' },
  ];

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        background: 'linear-gradient(135deg, #0d47a1 0%, #1565c0 50%, #1976d2 100%)',
        position: 'relative',
        overflow: 'hidden',
        '&::before': {
          content: '""',
          position: 'absolute',
          top: '-50%',
          right: '-20%',
          width: '80%',
          height: '150%',
          background: 'radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 60%)',
          transform: 'rotate(-15deg)',
        },
        '&::after': {
          content: '""',
          position: 'absolute',
          bottom: '-30%',
          left: '-10%',
          width: '60%',
          height: '100%',
          background: 'radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 50%)',
        }
      }}
    >
      <Container maxWidth="lg" sx={{ display: 'flex', alignItems: 'center', py: 4 }}>
        <Grid container spacing={4} alignItems="center">
          {/* Left Side - Info */}
          <Grid item xs={12} md={6}>
            <Fade in timeout={800}>
              <Box sx={{ color: 'white', pr: { md: 4 } }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                  <Box
                    sx={{
                      width: 70,
                      height: 70,
                      borderRadius: '20px',
                      background: 'rgba(255,255,255,0.15)',
                      backdropFilter: 'blur(10px)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <School sx={{ fontSize: 40 }} />
                  </Box>
                  <Box>
                    <Typography variant="h4" sx={{ fontWeight: 800, mb: 0.5 }}>
                      نظام التحقق من بيانات الطلاب
                    </Typography>
                    <Typography variant="subtitle1" sx={{ opacity: 0.9 }}>
                      Student Verification Blockchain System
                    </Typography>
                  </Box>
                </Box>

                <Typography variant="h6" sx={{ mb: 4, opacity: 0.9, lineHeight: 1.8 }}>
                  منصة موحدة وآمنة للتحقق من بيانات الطلاب عبر جميع الجامعات، 
                  باستخدام تقنية البلوك تشين لضمان مصداقية وسلامة السجلات الأكاديمية.
                </Typography>

                <Grid container spacing={2}>
                  {features.map((feature, index) => (
                    <Grid item xs={6} key={index}>
                      <Box sx={{ 
                        display: 'flex', 
                        alignItems: 'flex-start', 
                        gap: 1.5,
                        p: 2,
                        borderRadius: 2,
                        background: 'rgba(255,255,255,0.08)',
                        backdropFilter: 'blur(10px)',
                        transition: 'all 0.3s',
                        '&:hover': {
                          background: 'rgba(255,255,255,0.12)',
                          transform: 'translateY(-2px)'
                        }
                      }}>
                        <Box sx={{ 
                          p: 1, 
                          borderRadius: 1.5, 
                          background: 'rgba(255,255,255,0.2)' 
                        }}>
                          {feature.icon}
                        </Box>
                        <Box>
                          <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                            {feature.title}
                          </Typography>
                          <Typography variant="caption" sx={{ opacity: 0.8 }}>
                            {feature.desc}
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
              </Box>
            </Fade>
          </Grid>

          {/* Right Side - Login Form */}
          <Grid item xs={12} md={6}>
            <Fade in timeout={1000}>
              <Paper 
                elevation={24}
                sx={{ 
                  p: { xs: 3, sm: 4 },
                  borderRadius: 4,
                  position: 'relative',
                  overflow: 'hidden',
                  maxWidth: 480,
                  mx: 'auto',
                  '&::before': {
                    content: '""',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    height: '5px',
                    background: 'linear-gradient(90deg, #1565c0 0%, #42a5f5 100%)',
                  }
                }}
              >
                <Box sx={{ textAlign: 'center', mb: 4 }}>
                  <Typography variant="h5" sx={{ fontWeight: 700, mb: 1, color: '#1565c0' }}>
                    تسجيل الدخول
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    أدخل بيانات الاعتماد للوصول إلى النظام
                  </Typography>
                </Box>

                {error && (
                  <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }}>
                    {error}
                  </Alert>
                )}

                <Box component="form" onSubmit={handleSubmit}>
                  <TextField
                    margin="normal"
                    required
                    fullWidth
                    label="اسم المستخدم"
                    autoFocus
                    value={credentials.username}
                    onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Person color="action" />
                        </InputAdornment>
                      ),
                    }}
                    sx={{ mb: 2 }}
                  />
                  
                  <TextField
                    margin="normal"
                    required
                    fullWidth
                    label="كلمة المرور"
                    type={showPassword ? 'text' : 'password'}
                    value={credentials.password}
                    onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Lock color="action" />
                        </InputAdornment>
                      ),
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton
                            onClick={() => setShowPassword(!showPassword)}
                            edge="end"
                          >
                            {showPassword ? <VisibilityOff /> : <Visibility />}
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                    sx={{ mb: 3 }}
                  />

                  <Button
                    type="submit"
                    fullWidth
                    variant="contained"
                    size="large"
                    disabled={loading}
                    sx={{
                      py: 1.5,
                      fontSize: '1rem',
                      fontWeight: 600,
                      background: 'linear-gradient(135deg, #1565c0 0%, #1976d2 100%)',
                      boxShadow: '0 4px 16px rgba(21, 101, 192, 0.4)',
                      '&:hover': {
                        background: 'linear-gradient(135deg, #0d47a1 0%, #1565c0 100%)',
                        boxShadow: '0 6px 20px rgba(21, 101, 192, 0.6)',
                      },
                    }}
                  >
                    {loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
                  </Button>
                </Box>

                <Divider sx={{ my: 3 }}>
                  <Chip label="حسابات تجريبية" size="small" />
                </Divider>

                {/* Quick Login Buttons */}
                <Stack spacing={1.5}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<AdminPanelSettings />}
                    onClick={() => quickLogin('admin', 'admin123')}
                    sx={{
                      py: 1.2,
                      borderColor: '#1565c0',
                      color: '#1565c0',
                      borderWidth: 2,
                      '&:hover': {
                        borderWidth: 2,
                        borderColor: '#0d47a1',
                        bgcolor: 'rgba(21, 101, 192, 0.04)',
                      },
                    }}
                  >
                    <Box sx={{ textAlign: 'right', flex: 1 }}>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        دخول كوزارة التعليم العالي اليمنية
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        إدارة جميع الجامعات والطلاب
                      </Typography>
                    </Box>
                  </Button>

                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<School />}
                    onClick={() => quickLogin('sanaa_admin', 'sanaa123')}
                    sx={{
                      py: 1.2,
                      borderColor: '#2e7d32',
                      color: '#2e7d32',
                      borderWidth: 2,
                      '&:hover': {
                        borderWidth: 2,
                        borderColor: '#1b5e20',
                        bgcolor: 'rgba(46, 125, 50, 0.04)',
                      },
                    }}
                  >
                    <Box sx={{ textAlign: 'right', flex: 1 }}>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        دخول كجامعة صنعاء
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        أكبر جامعة حكومية في اليمن
                      </Typography>
                    </Box>
                  </Button>

                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<School />}
                    onClick={() => quickLogin('aden_admin', 'aden123')}
                    sx={{
                      py: 1.2,
                      borderColor: '#ed6c02',
                      color: '#ed6c02',
                      borderWidth: 2,
                      '&:hover': {
                        borderWidth: 2,
                        borderColor: '#e65100',
                        bgcolor: 'rgba(237, 108, 2, 0.04)',
                      },
                    }}
                  >
                    <Box sx={{ textAlign: 'right', flex: 1 }}>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        دخول كجامعة عدن
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        جامعة الجنوب الرائدة
                      </Typography>
                    </Box>
                  </Button>

                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<School />}
                    onClick={() => quickLogin('taiz_admin', 'taiz123')}
                    sx={{
                      py: 1.2,
                      borderColor: '#9c27b0',
                      color: '#9c27b0',
                      borderWidth: 2,
                      '&:hover': {
                        borderWidth: 2,
                        borderColor: '#7b1fa2',
                        bgcolor: 'rgba(156, 39, 176, 0.04)',
                      },
                    }}
                  >
                    <Box sx={{ textAlign: 'right', flex: 1 }}>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        دخول كجامعة تعز
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        جامعة مدينة تعز
                      </Typography>
                    </Box>
                  </Button>
                </Stack>

                <Typography 
                  variant="caption" 
                  color="text.secondary" 
                  sx={{ display: 'block', textAlign: 'center', mt: 3 }}
                >
                  مشروع تخرج - نظام التحقق من بيانات الطلاب باستخدام البلوك تشين
                  <br />
                  الجمهورية اليمنية - وزارة التعليم العالي والبحث العلمي
                  <br />
                  © 2024 جميع الحقوق محفوظة
                </Typography>
              </Paper>
            </Fade>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
}
