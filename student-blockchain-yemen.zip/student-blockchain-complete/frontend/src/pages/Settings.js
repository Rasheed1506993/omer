import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  TextField,
  Button,
  Switch,
  FormControlLabel,
  Divider,
  Alert,
  Card,
  CardContent,
  Avatar,
  Chip,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemSecondaryAction
} from '@mui/material';
import {
  Person,
  Lock,
  Notifications,
  Language,
  Security,
  Save,
  Edit,
  Email,
  Phone,
  Business,
  Key,
  Shield
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

export default function Settings() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [editMode, setEditMode] = useState(false);
  
  const [profile, setProfile] = useState({
    fullName: user?.fullName || '',
    email: user?.email || '',
    phone: '0512345678',
    department: 'قسم القبول والتسجيل'
  });

  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    transferRequests: true,
    approvalReminders: true,
    systemAlerts: true
  });

  const [security, setSecurity] = useState({
    twoFactor: false,
    sessionTimeout: 30
  });

  const isMinistry = user?.universityId === 'MINISTRY';

  const handleSaveProfile = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('تم حفظ التغييرات بنجاح');
      setEditMode(false);
    } catch (error) {
      toast.error('فشل في حفظ التغييرات');
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = () => {
    toast.info('سيتم إرسال رابط تغيير كلمة المرور إلى بريدك الإلكتروني');
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
          الإعدادات
        </Typography>
        <Typography variant="body1" color="text.secondary">
          إدارة حسابك وتفضيلاتك
        </Typography>
      </Box>

      <Grid container spacing={3}>
        {/* Profile Section */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h6" sx={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: 1 }}>
                <Person /> الملف الشخصي
              </Typography>
              <Button
                variant={editMode ? "contained" : "outlined"}
                startIcon={editMode ? <Save /> : <Edit />}
                onClick={editMode ? handleSaveProfile : () => setEditMode(true)}
                disabled={loading}
              >
                {editMode ? (loading ? 'جاري الحفظ...' : 'حفظ') : 'تعديل'}
              </Button>
            </Box>

            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="الاسم الكامل"
                  value={profile.fullName}
                  onChange={(e) => setProfile({ ...profile, fullName: e.target.value })}
                  disabled={!editMode}
                  InputProps={{
                    startAdornment: <Person color="action" sx={{ mr: 1 }} />
                  }}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="البريد الإلكتروني"
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  disabled={!editMode}
                  InputProps={{
                    startAdornment: <Email color="action" sx={{ mr: 1 }} />
                  }}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="رقم الهاتف"
                  value={profile.phone}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  disabled={!editMode}
                  InputProps={{
                    startAdornment: <Phone color="action" sx={{ mr: 1 }} />
                  }}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="القسم"
                  value={profile.department}
                  onChange={(e) => setProfile({ ...profile, department: e.target.value })}
                  disabled={!editMode}
                  InputProps={{
                    startAdornment: <Business color="action" sx={{ mr: 1 }} />
                  }}
                />
              </Grid>
            </Grid>
          </Paper>

          {/* Security Section */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" sx={{ fontWeight: 600, mb: 3, display: 'flex', alignItems: 'center', gap: 1 }}>
              <Security /> الأمان
            </Typography>

            <List>
              <ListItem>
                <ListItemIcon>
                  <Lock />
                </ListItemIcon>
                <ListItemText 
                  primary="كلمة المرور"
                  secondary="آخر تغيير: منذ 30 يوم"
                />
                <ListItemSecondaryAction>
                  <Button variant="outlined" size="small" onClick={handleChangePassword}>
                    تغيير
                  </Button>
                </ListItemSecondaryAction>
              </ListItem>
              <Divider />
              <ListItem>
                <ListItemIcon>
                  <Shield />
                </ListItemIcon>
                <ListItemText 
                  primary="المصادقة الثنائية"
                  secondary="أضف طبقة حماية إضافية لحسابك"
                />
                <ListItemSecondaryAction>
                  <Switch
                    checked={security.twoFactor}
                    onChange={(e) => setSecurity({ ...security, twoFactor: e.target.checked })}
                  />
                </ListItemSecondaryAction>
              </ListItem>
              <Divider />
              <ListItem>
                <ListItemIcon>
                  <Key />
                </ListItemIcon>
                <ListItemText 
                  primary="مهلة الجلسة"
                  secondary={`تسجيل الخروج تلقائياً بعد ${security.sessionTimeout} دقيقة من عدم النشاط`}
                />
                <ListItemSecondaryAction>
                  <TextField
                    type="number"
                    size="small"
                    value={security.sessionTimeout}
                    onChange={(e) => setSecurity({ ...security, sessionTimeout: parseInt(e.target.value) })}
                    sx={{ width: 80 }}
                    inputProps={{ min: 5, max: 120 }}
                  />
                </ListItemSecondaryAction>
              </ListItem>
            </List>
          </Paper>

          {/* Notifications Section */}
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" sx={{ fontWeight: 600, mb: 3, display: 'flex', alignItems: 'center', gap: 1 }}>
              <Notifications /> الإشعارات
            </Typography>

            <List>
              <ListItem>
                <ListItemText 
                  primary="إشعارات البريد الإلكتروني"
                  secondary="استلام إشعارات عبر البريد الإلكتروني"
                />
                <ListItemSecondaryAction>
                  <Switch
                    checked={notifications.emailNotifications}
                    onChange={(e) => setNotifications({ ...notifications, emailNotifications: e.target.checked })}
                  />
                </ListItemSecondaryAction>
              </ListItem>
              <Divider />
              <ListItem>
                <ListItemText 
                  primary="طلبات النقل"
                  secondary="إشعار عند وجود طلب نقل جديد"
                />
                <ListItemSecondaryAction>
                  <Switch
                    checked={notifications.transferRequests}
                    onChange={(e) => setNotifications({ ...notifications, transferRequests: e.target.checked })}
                  />
                </ListItemSecondaryAction>
              </ListItem>
              <Divider />
              <ListItem>
                <ListItemText 
                  primary="تذكيرات الموافقات"
                  secondary="تذكير بالطلبات المعلقة"
                />
                <ListItemSecondaryAction>
                  <Switch
                    checked={notifications.approvalReminders}
                    onChange={(e) => setNotifications({ ...notifications, approvalReminders: e.target.checked })}
                  />
                </ListItemSecondaryAction>
              </ListItem>
              <Divider />
              <ListItem>
                <ListItemText 
                  primary="تنبيهات النظام"
                  secondary="إشعارات الصيانة والتحديثات"
                />
                <ListItemSecondaryAction>
                  <Switch
                    checked={notifications.systemAlerts}
                    onChange={(e) => setNotifications({ ...notifications, systemAlerts: e.target.checked })}
                  />
                </ListItemSecondaryAction>
              </ListItem>
            </List>
          </Paper>
        </Grid>

        {/* Sidebar */}
        <Grid item xs={12} md={4}>
          {/* Account Card */}
          <Card sx={{ mb: 3 }}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Avatar 
                sx={{ 
                  width: 80, 
                  height: 80, 
                  mx: 'auto', 
                  mb: 2,
                  bgcolor: isMinistry ? 'primary.main' : 'success.main',
                  fontSize: '2rem'
                }}
              >
                {user?.fullName?.charAt(0)}
              </Avatar>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                {user?.fullName}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                {user?.email || user?.username}
              </Typography>
              <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1, flexWrap: 'wrap' }}>
                <Chip 
                  label={isMinistry ? 'وزارة التعليم' : user?.universityId}
                  color={isMinistry ? 'primary' : 'success'}
                  size="small"
                />
                <Chip 
                  label={
                    user?.role === 'admin' ? 'مدير النظام' :
                    user?.role === 'university_admin' ? 'مدير جامعة' :
                    user?.role === 'registrar' ? 'موظف قبول' : 'عارض'
                  }
                  variant="outlined"
                  size="small"
                />
              </Box>
            </CardContent>
          </Card>

          {/* Quick Info */}
          <Paper sx={{ p: 3 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2 }}>
              معلومات الحساب
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  اسم المستخدم
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {user?.username}
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  المؤسسة
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {isMinistry ? 'وزارة التعليم العالي' : user?.universityId}
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  الصلاحيات
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {user?.role === 'admin' ? 'صلاحيات كاملة' :
                   user?.role === 'university_admin' ? 'إدارة الجامعة' :
                   user?.role === 'registrar' ? 'القبول والتسجيل' : 'عرض فقط'}
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  آخر تسجيل دخول
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {new Date().toLocaleString('ar-SA')}
                </Typography>
              </Box>
            </Box>
          </Paper>

          {/* Blockchain Info */}
          <Paper sx={{ p: 3, mt: 3 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2 }}>
              الشهادة الرقمية
            </Typography>
            <Alert severity="success" sx={{ mb: 2 }}>
              الشهادة صالحة ونشطة
            </Alert>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              <Typography variant="caption" color="text.secondary">
                معرف المؤسسة على الشبكة
              </Typography>
              <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }}>
                {isMinistry ? 'ministry.edu.sa' : `${user?.universityId?.toLowerCase()}.edu.sa`}
              </Typography>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
