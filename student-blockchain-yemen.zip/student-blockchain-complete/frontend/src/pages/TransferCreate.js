import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  TextField,
  Button,
  Typography,
  Box,
  Grid,
  Alert,
  Autocomplete,
  Card,
  CardContent,
  Divider,
  Chip,
  MenuItem,
  CircularProgress
} from '@mui/material';
import {
  SwapHoriz,
  Search,
  Send,
  ArrowBack,
  Person,
  School,
  Warning
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { toast } from 'react-toastify';

export default function TransferCreate() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);

  const [formData, setFormData] = useState({
    fromUniversity: '',
    toUniversity: user?.universityId !== 'MINISTRY' ? user?.universityId : '',
    reason: '',
    documents: ''
  });

  const universities = [
    { id: 'UNIV1', name: 'جامعة الملك سعود' },
    { id: 'UNIV2', name: 'جامعة الملك عبدالعزيز' },
    { id: 'UNIV3', name: 'جامعة أم القرى' },
    { id: 'UNIV4', name: 'جامعة الإمام' }
  ];

  useEffect(() => {
    loadAllStudents();
  }, []);

  const loadAllStudents = async () => {
    try {
      setSearchLoading(true);
      const response = await axios.get('/api/students');
      setStudents(response.data.data?.students || []);
    } catch (error) {
      console.error('Error loading students:', error);
    } finally {
      setSearchLoading(false);
    }
  };

  const handleStudentSelect = (event, value) => {
    setSelectedStudent(value);
    if (value) {
      setFormData(prev => ({
        ...prev,
        fromUniversity: value.currentUniversity
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!selectedStudent) {
      toast.error('يرجى اختيار الطالب');
      return;
    }

    if (!formData.toUniversity || formData.toUniversity === formData.fromUniversity) {
      toast.error('يرجى اختيار جامعة مختلفة للنقل إليها');
      return;
    }

    if (!formData.reason.trim()) {
      toast.error('يرجى إدخال سبب النقل');
      return;
    }

    setLoading(true);
    try {
      await axios.post('/api/transfers', {
        studentId: selectedStudent.studentId,
        fromUniversity: formData.fromUniversity,
        toUniversity: formData.toUniversity,
        reason: formData.reason,
        documents: formData.documents
      });
      
      toast.success('تم إنشاء طلب النقل بنجاح');
      navigate('/transfers');
    } catch (error) {
      toast.error(error.response?.data?.message || 'فشل في إنشاء طلب النقل');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Button
          startIcon={<ArrowBack />}
          onClick={() => navigate('/transfers')}
          sx={{ mb: 2 }}
        >
          العودة
        </Button>
        <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
          طلب نقل طالب
        </Typography>
        <Typography variant="body1" color="text.secondary">
          إنشاء طلب نقل طالب من جامعة إلى أخرى
        </Typography>
      </Box>

      <Grid container spacing={3}>
        {/* Student Search Section */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
              <Search /> البحث عن الطالب
            </Typography>

            <Autocomplete
              fullWidth
              options={students}
              loading={searchLoading}
              value={selectedStudent}
              onChange={handleStudentSelect}
              getOptionLabel={(option) => `${option.studentId} - ${option.fullName} (${option.currentUniversity})`}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="ابحث عن الطالب"
                  placeholder="اكتب رقم أو اسم الطالب..."
                  InputProps={{
                    ...params.InputProps,
                    endAdornment: (
                      <>
                        {searchLoading ? <CircularProgress color="inherit" size={20} /> : null}
                        {params.InputProps.endAdornment}
                      </>
                    ),
                  }}
                />
              )}
              renderOption={(props, option) => (
                <Box component="li" {...props}>
                  <Box>
                    <Typography variant="body1" sx={{ fontWeight: 600 }}>
                      {option.fullName}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {option.studentId} • {option.currentUniversity} • {option.major}
                    </Typography>
                  </Box>
                </Box>
              )}
              noOptionsText="لا توجد نتائج"
            />

            {selectedStudent && (
              <Card sx={{ mt: 3, bgcolor: 'grey.50' }}>
                <CardContent>
                  <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Person /> معلومات الطالب المحدد
                  </Typography>
                  <Divider sx={{ my: 2 }} />
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">رقم الطالب:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedStudent.studentId}</Typography>
                    </Grid>

                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">الاسم الكامل:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedStudent.fullName}</Typography>
                    </Grid>

                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">الجامعة الحالية:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Chip label={selectedStudent.currentUniversity} color="primary" size="small" />
                    </Grid>

                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">التخصص:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedStudent.major}</Typography>
                    </Grid>

                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">المعدل التراكمي:</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{selectedStudent.gpa || 'غير محدد'}</Typography>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            )}
          </Paper>
        </Grid>

        {/* Transfer Details Section */}
        {selectedStudent && (
          <Grid item xs={12}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
                <SwapHoriz /> تفاصيل النقل
              </Typography>

              <Box component="form" onSubmit={handleSubmit}>
                <Grid container spacing={3}>
                  <Grid item xs={12} md={6}>
                    <TextField
                      fullWidth
                      disabled
                      label="من الجامعة"
                      value={universities.find(u => u.id === formData.fromUniversity)?.name || formData.fromUniversity}
                      InputProps={{
                        startAdornment: <School sx={{ mr: 1, color: 'warning.main' }} />
                      }}
                    />
                  </Grid>

                  <Grid item xs={12} md={6}>
                    <TextField
                      fullWidth
                      required
                      select
                      label="إلى الجامعة"
                      value={formData.toUniversity}
                      onChange={(e) => setFormData({ ...formData, toUniversity: e.target.value })}
                      InputProps={{
                        startAdornment: <School sx={{ mr: 1, color: 'success.main' }} />
                      }}
                    >
                      {universities
                        .filter(u => u.id !== formData.fromUniversity)
                        .map((uni) => (
                          <MenuItem key={uni.id} value={uni.id}>
                            {uni.name}
                          </MenuItem>
                        ))}
                    </TextField>
                  </Grid>

                  <Grid item xs={12}>
                    <Alert severity="info" icon={<Warning />}>
                      <Typography variant="body2">
                        <strong>إجراءات الموافقة:</strong>
                        <br />
                        1. يجب موافقة الجامعة الأصلية ({formData.fromUniversity})
                        <br />
                        2. ثم موافقة الوزارة للنقل النهائي
                      </Typography>
                    </Alert>
                  </Grid>

                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      required
                      multiline
                      rows={4}
                      label="سبب النقل"
                      name="reason"
                      value={formData.reason}
                      onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                      placeholder="أذكر الأسباب التي تستدعي نقل الطالب..."
                      helperText="يرجى ذكر الأسباب بوضوح"
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      multiline
                      rows={2}
                      label="المستندات المرفقة (اختياري)"
                      name="documents"
                      value={formData.documents}
                      onChange={(e) => setFormData({ ...formData, documents: e.target.value })}
                      placeholder="قائمة بالمستندات المرفقة..."
                      helperText="مثال: خطاب ولي الأمر، تقرير طبي، وثيقة تحويل"
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
                      <Button
                        variant="outlined"
                        size="large"
                        onClick={() => navigate('/transfers')}
                      >
                        إلغاء
                      </Button>
                      <Button
                        type="submit"
                        variant="contained"
                        size="large"
                        startIcon={<Send />}
                        disabled={loading}
                      >
                        {loading ? 'جاري الإرسال...' : 'إرسال الطلب'}
                      </Button>
                    </Box>
                  </Grid>
                </Grid>
              </Box>
            </Paper>
          </Grid>
        )}
      </Grid>
    </Container>
  );
}
