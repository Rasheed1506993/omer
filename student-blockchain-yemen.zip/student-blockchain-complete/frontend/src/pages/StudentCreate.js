import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Container,
  Paper,
  TextField,
  Button,
  Typography,
  Box,
  Grid,
  MenuItem,
  Alert,
  Stepper,
  Step,
  StepLabel,
  Divider
} from '@mui/material';
import { Person, School, Save, ArrowBack } from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { toast } from 'react-toastify';

const steps = ['البيانات الشخصية', 'البيانات الأكاديمية', 'المراجعة والحفظ'];

export default function StudentCreate() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    // Personal Information
    studentId: '',
    fullName: '',
    nationalId: '',
    dateOfBirth: '',
    gender: 'male',
    nationality: 'سعودي',
    email: '',
    phoneNumber: '',
    
    // Academic Information
    currentUniversity: location.state?.universityId || user?.universityId || '',
    faculty: '',
    major: '',
    enrollmentDate: new Date().toISOString().split('T')[0],
    expectedGraduation: '',
    academicLevel: '1',
    gpa: '',
    status: 'active'
  });

  const [errors, setErrors] = useState({});

  const universities = [
    { id: 'UNIV1', name: 'جامعة الملك سعود' },
    { id: 'UNIV2', name: 'جامعة الملك عبدالعزيز' },
    { id: 'UNIV3', name: 'جامعة أم القرى' },
    { id: 'UNIV4', name: 'جامعة الإمام' }
  ];

  const faculties = [
    'كلية الهندسة',
    'كلية علوم الحاسب',
    'كلية الطب',
    'كلية الصيدلة',
    'كلية العلوم',
    'كلية الآداب',
    'كلية إدارة الأعمال',
    'كلية الحقوق'
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateStep = (step) => {
    const newErrors = {};

    if (step === 0) {
      // Personal Information Validation
      if (!formData.studentId.trim()) newErrors.studentId = 'رقم الطالب مطلوب';
      if (!formData.fullName.trim()) newErrors.fullName = 'الاسم الكامل مطلوب';
      if (!formData.nationalId.trim()) newErrors.nationalId = 'رقم الهوية مطلوب';
      else if (!/^\d{10}$/.test(formData.nationalId)) newErrors.nationalId = 'رقم الهوية يجب أن يكون 10 أرقام';
      if (!formData.dateOfBirth) newErrors.dateOfBirth = 'تاريخ الميلاد مطلوب';
      if (!formData.email.trim()) newErrors.email = 'البريد الإلكتروني مطلوب';
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'البريد الإلكتروني غير صحيح';
      if (!formData.phoneNumber.trim()) newErrors.phoneNumber = 'رقم الهاتف مطلوب';
      else if (!/^05\d{8}$/.test(formData.phoneNumber)) newErrors.phoneNumber = 'رقم الهاتف يجب أن يبدأ بـ 05 ويحتوي على 10 أرقام';
    } else if (step === 1) {
      // Academic Information Validation
      if (!formData.currentUniversity) newErrors.currentUniversity = 'الجامعة مطلوبة';
      if (!formData.faculty.trim()) newErrors.faculty = 'الكلية مطلوبة';
      if (!formData.major.trim()) newErrors.major = 'التخصص مطلوب';
      if (!formData.enrollmentDate) newErrors.enrollmentDate = 'تاريخ الالتحاق مطلوب';
      if (formData.gpa && (isNaN(formData.gpa) || formData.gpa < 0 || formData.gpa > 5)) {
        newErrors.gpa = 'المعدل التراكمي يجب أن يكون بين 0 و 5';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    setActiveStep(prev => prev - 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateStep(1)) return;

    setLoading(true);
    try {
      await axios.post('/api/students', formData);
      toast.success('تمت إضافة الطالب بنجاح');
      navigate('/students');
    } catch (error) {
      toast.error(error.response?.data?.message || 'فشل في إضافة الطالب');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Button
          startIcon={<ArrowBack />}
          onClick={() => navigate('/students')}
          sx={{ mb: 2 }}
        >
          العودة
        </Button>
        <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
          إضافة طالب جديد
        </Typography>
        <Typography variant="body1" color="text.secondary">
          املأ جميع البيانات المطلوبة لتسجيل طالب جديد في النظام
        </Typography>
      </Box>

      <Paper sx={{ p: 4 }}>
        <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        <Box component="form" onSubmit={handleSubmit}>
          {activeStep === 0 && (
            <Box>
              <Typography variant="h6" gutterBottom sx={{ mb: 3, display: 'flex', alignItems: 'center', gap: 1 }}>
                <Person /> البيانات الشخصية
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    required
                    label="رقم الطالب"
                    name="studentId"
                    value={formData.studentId}
                    onChange={handleChange}
                    error={Boolean(errors.studentId)}
                    helperText={errors.studentId || 'مثال: 441234567'}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    required
                    label="رقم الهوية الوطنية"
                    name="nationalId"
                    value={formData.nationalId}
                    onChange={handleChange}
                    error={Boolean(errors.nationalId)}
                    helperText={errors.nationalId || '10 أرقام'}
                    inputProps={{ maxLength: 10 }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    required
                    label="الاسم الكامل"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    error={Boolean(errors.fullName)}
                    helperText={errors.fullName}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    required
                    select
                    label="الجنس"
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                  >
                    <MenuItem value="male">ذكر</MenuItem>
                    <MenuItem value="female">أنثى</MenuItem>
                  </TextField>
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    required
                    type="date"
                    label="تاريخ الميلاد"
                    name="dateOfBirth"
                    value={formData.dateOfBirth}
                    onChange={handleChange}
                    error={Boolean(errors.dateOfBirth)}
                    helperText={errors.dateOfBirth}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    required
                    label="الجنسية"
                    name="nationality"
                    value={formData.nationality}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    required
                    label="رقم الهاتف"
                    name="phoneNumber"
                    value={formData.phoneNumber}
                    onChange={handleChange}
                    error={Boolean(errors.phoneNumber)}
                    helperText={errors.phoneNumber || 'مثال: 0501234567'}
                    inputProps={{ maxLength: 10 }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    required
                    type="email"
                    label="البريد الإلكتروني"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    error={Boolean(errors.email)}
                    helperText={errors.email}
                  />
                </Grid>
              </Grid>
            </Box>
          )}

          {activeStep === 1 && (
            <Box>
              <Typography variant="h6" gutterBottom sx={{ mb: 3, display: 'flex', alignItems: 'center', gap: 1 }}>
                <School /> البيانات الأكاديمية
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    required
                    select
                    label="الجامعة"
                    name="currentUniversity"
                    value={formData.currentUniversity}
                    onChange={handleChange}
                    error={Boolean(errors.currentUniversity)}
                    helperText={errors.currentUniversity}
                    disabled={user?.universityId !== 'MINISTRY'}
                  >
                    {universities.map((uni) => (
                      <MenuItem key={uni.id} value={uni.id}>
                        {uni.name} ({uni.id})
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    required
                    select
                    label="الكلية"
                    name="faculty"
                    value={formData.faculty}
                    onChange={handleChange}
                    error={Boolean(errors.faculty)}
                    helperText={errors.faculty}
                  >
                    {faculties.map((faculty) => (
                      <MenuItem key={faculty} value={faculty}>
                        {faculty}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    required
                    label="التخصص"
                    name="major"
                    value={formData.major}
                    onChange={handleChange}
                    error={Boolean(errors.major)}
                    helperText={errors.major || 'مثال: هندسة برمجيات'}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    required
                    type="date"
                    label="تاريخ الالتحاق"
                    name="enrollmentDate"
                    value={formData.enrollmentDate}
                    onChange={handleChange}
                    error={Boolean(errors.enrollmentDate)}
                    helperText={errors.enrollmentDate}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    type="date"
                    label="تاريخ التخرج المتوقع"
                    name="expectedGraduation"
                    value={formData.expectedGraduation}
                    onChange={handleChange}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    required
                    select
                    label="المستوى الدراسي"
                    name="academicLevel"
                    value={formData.academicLevel}
                    onChange={handleChange}
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((level) => (
                      <MenuItem key={level} value={level.toString()}>
                        المستوى {level}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    type="number"
                    label="المعدل التراكمي (GPA)"
                    name="gpa"
                    value={formData.gpa}
                    onChange={handleChange}
                    error={Boolean(errors.gpa)}
                    helperText={errors.gpa || 'اختياري - من 0 إلى 5'}
                    inputProps={{ min: 0, max: 5, step: 0.01 }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    required
                    select
                    label="الحالة"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                  >
                    <MenuItem value="active">نشط</MenuItem>
                    <MenuItem value="suspended">موقوف</MenuItem>
                    <MenuItem value="graduated">متخرج</MenuItem>
                  </TextField>
                </Grid>
              </Grid>
            </Box>
          )}

          {activeStep === 2 && (
            <Box>
              <Alert severity="info" sx={{ mb: 3 }}>
                يرجى مراجعة البيانات قبل الحفظ. سيتم تسجيل هذا الطالب على البلوك تشين ولا يمكن حذفه.
              </Alert>
              
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600, mb: 2 }}>
                ملخص البيانات
              </Typography>

              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Divider textAlign="left"><Typography variant="subtitle2">البيانات الشخصية</Typography></Divider>
                </Grid>
                <Grid item xs={6}><Typography variant="body2" color="text.secondary">رقم الطالب:</Typography></Grid>
                <Grid item xs={6}><Typography variant="body2" sx={{ fontWeight: 600 }}>{formData.studentId}</Typography></Grid>
                
                <Grid item xs={6}><Typography variant="body2" color="text.secondary">الاسم الكامل:</Typography></Grid>
                <Grid item xs={6}><Typography variant="body2" sx={{ fontWeight: 600 }}>{formData.fullName}</Typography></Grid>
                
                <Grid item xs={6}><Typography variant="body2" color="text.secondary">رقم الهوية:</Typography></Grid>
                <Grid item xs={6}><Typography variant="body2" sx={{ fontWeight: 600 }}>{formData.nationalId}</Typography></Grid>
                
                <Grid item xs={6}><Typography variant="body2" color="text.secondary">البريد الإلكتروني:</Typography></Grid>
                <Grid item xs={6}><Typography variant="body2" sx={{ fontWeight: 600 }}>{formData.email}</Typography></Grid>

                <Grid item xs={12} sx={{ mt: 2 }}>
                  <Divider textAlign="left"><Typography variant="subtitle2">البيانات الأكاديمية</Typography></Divider>
                </Grid>
                
                <Grid item xs={6}><Typography variant="body2" color="text.secondary">الجامعة:</Typography></Grid>
                <Grid item xs={6}><Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {universities.find(u => u.id === formData.currentUniversity)?.name}
                </Typography></Grid>
                
                <Grid item xs={6}><Typography variant="body2" color="text.secondary">الكلية:</Typography></Grid>
                <Grid item xs={6}><Typography variant="body2" sx={{ fontWeight: 600 }}>{formData.faculty}</Typography></Grid>
                
                <Grid item xs={6}><Typography variant="body2" color="text.secondary">التخصص:</Typography></Grid>
                <Grid item xs={6}><Typography variant="body2" sx={{ fontWeight: 600 }}>{formData.major}</Typography></Grid>
                
                <Grid item xs={6}><Typography variant="body2" color="text.secondary">المعدل التراكمي:</Typography></Grid>
                <Grid item xs={6}><Typography variant="body2" sx={{ fontWeight: 600 }}>{formData.gpa || 'غير محدد'}</Typography></Grid>
              </Grid>
            </Box>
          )}

          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
            <Button
              disabled={activeStep === 0}
              onClick={handleBack}
              size="large"
            >
              السابق
            </Button>
            <Box sx={{ flex: '1 1 auto' }} />
            {activeStep === steps.length - 1 ? (
              <Button
                variant="contained"
                size="large"
                startIcon={<Save />}
                onClick={handleSubmit}
                disabled={loading}
              >
                {loading ? 'جاري الحفظ...' : 'حفظ البيانات'}
              </Button>
            ) : (
              <Button
                variant="contained"
                size="large"
                onClick={handleNext}
              >
                التالي
              </Button>
            )}
          </Box>
        </Box>
      </Paper>
    </Container>
  );
}
