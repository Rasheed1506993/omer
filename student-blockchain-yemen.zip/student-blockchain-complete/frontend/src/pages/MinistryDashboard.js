import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Grid,
  Paper,
  Typography,
  Box,
  Button,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Tabs,
  Tab,
  CircularProgress,
  Divider
} from '@mui/material';
import {
  School,
  People,
  SwapHoriz,
  CheckCircle,
  Add,
  Visibility,
  TrendingUp,
  Business
} from '@mui/icons-material';
import axios from 'axios';
import { toast } from 'react-toastify';

export default function MinistryDashboard() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);
  const [stats, setStats] = useState({
    totalUniversities: 4,
    totalStudents: 0,
    pendingTransfers: 0,
    completedTransfers: 0
  });
  const [universities, setUniversities] = useState([
    { id: 'UNIV1', name: 'جامعة الملك سعود', studentCount: 0, city: 'الرياض' },
    { id: 'UNIV2', name: 'جامعة الملك عبدالعزيز', studentCount: 0, city: 'جدة' },
    { id: 'UNIV3', name: 'جامعة أم القرى', studentCount: 0, city: 'مكة' },
    { id: 'UNIV4', name: 'جامعة الإمام', studentCount: 0, city: 'الرياض' }
  ]);
  const [allStudents, setAllStudents] = useState([]);
  const [pendingTransfers, setPendingTransfers] = useState([]);

  useEffect(() => {
    loadMinistryData();
  }, []);

  const loadMinistryData = async () => {
    try {
      setLoading(true);

      // Load all students from all universities
      let allStudentsData = [];
      let transfers = [];
      
      try {
        const studentsRes = await axios.get('/api/students');
        allStudentsData = studentsRes.data.data?.students || [];
      } catch (err) {
        console.error('Error loading students:', err);
        // Continue with empty array
      }
      
      setAllStudents(allStudentsData);

      // Count students per university
      const universitiesWithCounts = universities.map(uni => ({
        ...uni,
        studentCount: allStudentsData.filter(s => s.currentUniversity === uni.id).length
      }));
      setUniversities(universitiesWithCounts);

      // Load pending transfers that need ministry approval
      try {
        const transfersRes = await axios.get('/api/transfers/pending');
        transfers = transfersRes.data.data || [];
      } catch (err) {
        console.error('Error loading transfers:', err);
        // Continue with empty array
      }
      
      const ministryPending = transfers.filter(
        t => t.status === 'approved_by_source' || t.status === 'pending'
      );
      setPendingTransfers(ministryPending);

      setStats({
        totalUniversities: universities.length,
        totalStudents: allStudentsData.length,
        pendingTransfers: ministryPending.length,
        completedTransfers: transfers.filter(t => t.status === 'completed').length
      });

    } catch (error) {
      console.error('Error loading ministry data:', error);
      // Don't show error toast for initial load with empty DB
    } finally {
      setLoading(false);
    }
  };

  const handleApproveTransfer = async (transferId) => {
    try {
      await axios.put(`/api/transfers/${transferId}/approve`, {
        approved: true,
        comments: 'تمت الموافقة من الوزارة'
      });
      toast.success('تمت الموافقة على النقل');
      loadMinistryData();
    } catch (error) {
      toast.error(error.response?.data?.message || 'فشلت الموافقة');
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
          لوحة تحكم الوزارة
        </Typography>
        <Typography variant="body1" color="text.secondary">
          إدارة شاملة لجميع الجامعات والطلاب ونقل الطلاب بين الجامعات
        </Typography>
      </Box>

      {/* Statistics Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {stats.totalUniversities}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    إجمالي الجامعات
                  </Typography>
                </Box>
                <School sx={{ fontSize: 60, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
            color: 'white',
            cursor: 'pointer',
            '&:hover': { transform: 'translateY(-4px)', transition: 'all 0.3s' }
          }}
          onClick={() => setTabValue(1)}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {stats.totalStudents}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    إجمالي الطلاب
                  </Typography>
                </Box>
                <People sx={{ fontSize: 60, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
            color: 'white',
            cursor: 'pointer',
            '&:hover': { transform: 'translateY(-4px)', transition: 'all 0.3s' }
          }}
          onClick={() => setTabValue(2)}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {stats.pendingTransfers}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    طلبات معلقة
                  </Typography>
                </Box>
                <SwapHoriz sx={{ fontSize: 60, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
            color: 'white'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {stats.completedTransfers}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    نقل مكتمل
                  </Typography>
                </Box>
                <CheckCircle sx={{ fontSize: 60, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Tabs for different views */}
      <Paper sx={{ mb: 3 }}>
        <Tabs 
          value={tabValue} 
          onChange={(e, newValue) => setTabValue(newValue)}
          variant="fullWidth"
          sx={{
            '& .MuiTab-root': {
              fontWeight: 600,
              fontSize: '1rem',
              py: 2
            }
          }}
        >
          <Tab icon={<Business />} label="الجامعات" iconPosition="start" />
          <Tab icon={<People />} label="جميع الطلاب" iconPosition="start" />
          <Tab icon={<SwapHoriz />} label="طلبات النقل" iconPosition="start" />
        </Tabs>
      </Paper>

      {/* Tab Content */}
      {tabValue === 0 && (
        <Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h5" sx={{ fontWeight: 600 }}>
              الجامعات المسجلة في النظام
            </Typography>
          </Box>

          <Grid container spacing={3}>
            {universities.map((uni) => (
              <Grid item xs={12} md={6} key={uni.id}>
                <Card sx={{ 
                  '&:hover': { 
                    boxShadow: 6,
                    transform: 'translateY(-4px)',
                    transition: 'all 0.3s'
                  }
                }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', mb: 2 }}>
                      <Box sx={{ display: 'flex', gap: 2 }}>
                        <Box sx={{
                          width: 60,
                          height: 60,
                          borderRadius: 2,
                          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}>
                          <School sx={{ fontSize: 32, color: 'white' }} />
                        </Box>
                        <Box>
                          <Typography variant="h6" sx={{ fontWeight: 700 }}>
                            {uni.name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {uni.city} • {uni.id}
                          </Typography>
                        </Box>
                      </Box>
                      <Chip 
                        label={`${uni.studentCount} طالب`}
                        color="primary"
                        sx={{ fontWeight: 600 }}
                      />
                    </Box>
                    <Divider sx={{ my: 2 }} />
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Button 
                        variant="contained" 
                        size="small"
                        startIcon={<Visibility />}
                        onClick={() => navigate(`/universities/${uni.id}`)}
                        sx={{ flex: 1 }}
                      >
                        عرض التفاصيل
                      </Button>
                      <Button 
                        variant="outlined" 
                        size="small"
                        startIcon={<Add />}
                        onClick={() => navigate('/students/create', { state: { universityId: uni.id } })}
                        sx={{ flex: 1 }}
                      >
                        إضافة طالب
                      </Button>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>
      )}

      {tabValue === 1 && (
        <Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h5" sx={{ fontWeight: 600 }}>
              جميع الطلاب في النظام
            </Typography>
            <Button
              variant="contained"
              startIcon={<Add />}
              onClick={() => navigate('/students/create')}
            >
              إضافة طالب جديد
            </Button>
          </Box>

          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>رقم الطالب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الاسم</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الجامعة</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>التخصص</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>المعدل</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الحالة</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الإجراءات</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {allStudents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center" sx={{ py: 8 }}>
                      <People sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                      <Typography variant="h6" color="text.secondary">
                        لا يوجد طلاب مسجلين
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  allStudents.slice(0, 10).map((student) => (
                    <TableRow key={student.studentId} hover>
                      <TableCell>{student.studentId}</TableCell>
                      <TableCell>{student.fullName}</TableCell>
                      <TableCell>
                        <Chip 
                          label={student.currentUniversity} 
                          size="small" 
                          color="primary"
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell>{student.major}</TableCell>
                      <TableCell>{student.gpa || '-'}</TableCell>
                      <TableCell>
                        <Chip
                          label={student.status === 'active' ? 'نشط' : 'غير نشط'}
                          color={student.status === 'active' ? 'success' : 'default'}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        <IconButton
                          size="small"
                          onClick={() => navigate(`/students/${student.studentId}`)}
                          color="primary"
                        >
                          <Visibility />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
          {allStudents.length > 10 && (
            <Box sx={{ mt: 2, textAlign: 'center' }}>
              <Button onClick={() => navigate('/students')}>
                عرض جميع الطلاب ({allStudents.length})
              </Button>
            </Box>
          )}
        </Box>
      )}

      {tabValue === 2 && (
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 600, mb: 3 }}>
            طلبات النقل التي تحتاج موافقة الوزارة
          </Typography>

          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>رقم الطلب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الطالب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>من</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>إلى</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>السبب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الحالة</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الإجراءات</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {pendingTransfers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center" sx={{ py: 8 }}>
                      <CheckCircle sx={{ fontSize: 64, color: 'success.main', mb: 2 }} />
                      <Typography variant="h6" color="text.secondary">
                        لا توجد طلبات معلقة
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  pendingTransfers.map((transfer) => (
                    <TableRow key={transfer.transferId} hover>
                      <TableCell>{transfer.transferId}</TableCell>
                      <TableCell>{transfer.studentId}</TableCell>
                      <TableCell>
                        <Chip label={transfer.fromUniversity} size="small" color="warning" />
                      </TableCell>
                      <TableCell>
                        <Chip label={transfer.toUniversity} size="small" color="success" />
                      </TableCell>
                      <TableCell sx={{ maxWidth: 200 }}>
                        <Typography variant="body2" noWrap>
                          {transfer.reason}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={transfer.status === 'approved_by_source' ? 'جاهز للموافقة' : 'معلق'}
                          color={transfer.status === 'approved_by_source' ? 'warning' : 'default'}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 1 }}>
                          <Button
                            size="small"
                            variant="contained"
                            color="success"
                            startIcon={<CheckCircle />}
                            onClick={() => handleApproveTransfer(transfer.transferId)}
                          >
                            موافقة
                          </Button>
                          <IconButton
                            size="small"
                            onClick={() => navigate(`/transfers`)}
                            color="primary"
                          >
                            <Visibility />
                          </IconButton>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}
    </Box>
  );
}
