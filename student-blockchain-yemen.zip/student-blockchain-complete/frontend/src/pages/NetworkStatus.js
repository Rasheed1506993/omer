import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  Chip,
  Alert,
  CircularProgress,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Tooltip,
  Button
} from '@mui/material';
import {
  Storage,
  CheckCircle,
  Warning,
  Error as ErrorIcon,
  Speed,
  Memory,
  CloudQueue,
  Refresh,
  Timeline,
  AccountTree,
  Security,
  Dns
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';

export default function NetworkStatus() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [networkStats, setNetworkStats] = useState(null);
  const [nodes, setNodes] = useState([]);

  const isMinistry = user?.universityId === 'MINISTRY';

  useEffect(() => {
    if (!isMinistry) {
      navigate('/dashboard');
      return;
    }
    loadNetworkStatus();
    
    // Auto refresh every 30 seconds
    const interval = setInterval(loadNetworkStatus, 30000);
    return () => clearInterval(interval);
  }, [isMinistry]);

  const loadNetworkStatus = async () => {
    try {
      setLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setNetworkStats({
        totalNodes: 5,
        activeNodes: 4,
        totalBlocks: 12458,
        totalTransactions: 45892,
        avgBlockTime: 2.3,
        pendingTransactions: 12,
        networkHealth: 98,
        lastBlockTime: new Date().toISOString(),
        consensusAlgorithm: 'Raft',
        channelName: 'student-records'
      });

      setNodes([
        {
          id: 'peer0.ministry.mohe.gov.ye',
          name: 'عقدة وزارة التعليم العالي',
          type: 'orderer',
          status: 'active',
          blocks: 12458,
          cpu: 23,
          memory: 45,
          lastSeen: new Date().toISOString()
        },
        {
          id: 'peer0.su.edu.ye',
          name: 'عقدة جامعة صنعاء',
          type: 'peer',
          status: 'active',
          blocks: 12458,
          cpu: 18,
          memory: 38,
          lastSeen: new Date().toISOString()
        },
        {
          id: 'peer0.aden-univ.edu.ye',
          name: 'عقدة جامعة عدن',
          type: 'peer',
          status: 'active',
          blocks: 12458,
          cpu: 21,
          memory: 42,
          lastSeen: new Date().toISOString()
        },
        {
          id: 'peer0.taiz-univ.edu.ye',
          name: 'عقدة جامعة تعز',
          type: 'peer',
          status: 'active',
          blocks: 12456,
          cpu: 15,
          memory: 35,
          lastSeen: new Date(Date.now() - 120000).toISOString()
        },
        {
          id: 'peer0.hoduniv.edu.ye',
          name: 'عقدة جامعة الحديدة',
          type: 'peer',
          status: 'active',
          blocks: 12455,
          cpu: 19,
          memory: 40,
          lastSeen: new Date().toISOString()
        },
        {
          id: 'peer0.ibb-univ.edu.ye',
          name: 'عقدة جامعة إب',
          type: 'peer',
          status: 'active',
          blocks: 12454,
          cpu: 17,
          memory: 36,
          lastSeen: new Date().toISOString()
        },
        {
          id: 'peer0.hu.edu.ye',
          name: 'عقدة جامعة حضرموت',
          type: 'peer',
          status: 'syncing',
          blocks: 12450,
          cpu: 45,
          memory: 62,
          lastSeen: new Date(Date.now() - 300000).toISOString()
        },
        {
          id: 'peer0.ust.edu.ye',
          name: 'عقدة جامعة العلوم والتكنولوجيا',
          type: 'peer',
          status: 'active',
          blocks: 12458,
          cpu: 22,
          memory: 44,
          lastSeen: new Date().toISOString()
        }
      ]);
    } catch (error) {
      console.error('Error loading network status:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return <CheckCircle color="success" />;
      case 'syncing': return <Warning color="warning" />;
      case 'offline': return <ErrorIcon color="error" />;
      default: return <Warning />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'success';
      case 'syncing': return 'warning';
      case 'offline': return 'error';
      default: return 'default';
    }
  };

  if (loading && !networkStats) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
            حالة شبكة البلوك تشين
          </Typography>
          <Typography variant="body1" color="text.secondary">
            مراقبة صحة وأداء شبكة Hyperledger Fabric
          </Typography>
        </Box>
        <Button
          variant="outlined"
          startIcon={loading ? <CircularProgress size={20} /> : <Refresh />}
          onClick={loadNetworkStatus}
          disabled={loading}
        >
          تحديث
        </Button>
      </Box>

      {/* Network Health */}
      <Alert 
        severity={networkStats?.networkHealth >= 90 ? 'success' : networkStats?.networkHealth >= 70 ? 'warning' : 'error'}
        sx={{ mb: 4 }}
        icon={<Security />}
      >
        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
          صحة الشبكة: {networkStats?.networkHealth}%
        </Typography>
        <Typography variant="body2">
          جميع العقد تعمل بشكل طبيعي. آخر كتلة: {new Date(networkStats?.lastBlockTime).toLocaleString('ar-SA')}
        </Typography>
      </Alert>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box sx={{ p: 1.5, bgcolor: 'primary.light', borderRadius: 2 }}>
                  <Dns sx={{ color: 'primary.main' }} />
                </Box>
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 700 }}>
                    {networkStats?.activeNodes}/{networkStats?.totalNodes}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    عقد نشطة
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box sx={{ p: 1.5, bgcolor: 'success.light', borderRadius: 2 }}>
                  <Storage sx={{ color: 'success.main' }} />
                </Box>
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 700 }}>
                    {networkStats?.totalBlocks.toLocaleString()}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    إجمالي الكتل
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box sx={{ p: 1.5, bgcolor: 'info.light', borderRadius: 2 }}>
                  <Timeline sx={{ color: 'info.main' }} />
                </Box>
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 700 }}>
                    {networkStats?.totalTransactions.toLocaleString()}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    إجمالي المعاملات
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box sx={{ p: 1.5, bgcolor: 'warning.light', borderRadius: 2 }}>
                  <Speed sx={{ color: 'warning.main' }} />
                </Box>
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 700 }}>
                    {networkStats?.avgBlockTime}s
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    متوسط وقت الكتلة
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Network Info */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2 }}>
              معلومات الشبكة
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body2" color="text.secondary">اسم القناة</Typography>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>{networkStats?.channelName}</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body2" color="text.secondary">خوارزمية الإجماع</Typography>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>{networkStats?.consensusAlgorithm}</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Typography variant="body2" color="text.secondary">معاملات معلقة</Typography>
                <Chip label={networkStats?.pendingTransactions} size="small" color="warning" />
              </Box>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2 }}>
              توزيع العقد حسب الحالة
            </Typography>
            <Box sx={{ display: 'flex', gap: 4, alignItems: 'center', height: 'calc(100% - 40px)' }}>
              <Box sx={{ flex: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                  <CheckCircle color="success" fontSize="small" />
                  <Typography variant="body2">نشط</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, mr: 'auto' }}>
                    {nodes.filter(n => n.status === 'active').length}
                  </Typography>
                </Box>
                <LinearProgress 
                  variant="determinate" 
                  value={(nodes.filter(n => n.status === 'active').length / nodes.length) * 100}
                  color="success"
                  sx={{ height: 8, borderRadius: 4, mb: 2 }}
                />
                
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                  <Warning color="warning" fontSize="small" />
                  <Typography variant="body2">مزامنة</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, mr: 'auto' }}>
                    {nodes.filter(n => n.status === 'syncing').length}
                  </Typography>
                </Box>
                <LinearProgress 
                  variant="determinate" 
                  value={(nodes.filter(n => n.status === 'syncing').length / nodes.length) * 100}
                  color="warning"
                  sx={{ height: 8, borderRadius: 4, mb: 2 }}
                />
                
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                  <ErrorIcon color="error" fontSize="small" />
                  <Typography variant="body2">غير متصل</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 600, mr: 'auto' }}>
                    {nodes.filter(n => n.status === 'offline').length}
                  </Typography>
                </Box>
                <LinearProgress 
                  variant="determinate" 
                  value={(nodes.filter(n => n.status === 'offline').length / nodes.length) * 100}
                  color="error"
                  sx={{ height: 8, borderRadius: 4 }}
                />
              </Box>
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Nodes Table */}
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
          العقد المشاركة
        </Typography>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 700 }}>العقدة</TableCell>
                <TableCell sx={{ fontWeight: 700 }}>النوع</TableCell>
                <TableCell sx={{ fontWeight: 700 }}>الحالة</TableCell>
                <TableCell sx={{ fontWeight: 700 }}>الكتل</TableCell>
                <TableCell sx={{ fontWeight: 700 }}>CPU</TableCell>
                <TableCell sx={{ fontWeight: 700 }}>الذاكرة</TableCell>
                <TableCell sx={{ fontWeight: 700 }}>آخر اتصال</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {nodes.map((node) => (
                <TableRow key={node.id} hover>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                      {getStatusIcon(node.status)}
                      <Box>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {node.name}
                        </Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'monospace' }}>
                          {node.id}
                        </Typography>
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Chip 
                      label={node.type === 'orderer' ? 'Orderer' : 'Peer'}
                      size="small"
                      color={node.type === 'orderer' ? 'primary' : 'default'}
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>
                    <Chip 
                      label={node.status === 'active' ? 'نشط' : node.status === 'syncing' ? 'مزامنة' : 'غير متصل'}
                      size="small"
                      color={getStatusColor(node.status)}
                    />
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace' }}>
                      {node.blocks.toLocaleString()}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <LinearProgress 
                        variant="determinate" 
                        value={node.cpu}
                        sx={{ width: 60, height: 6, borderRadius: 3 }}
                        color={node.cpu > 80 ? 'error' : node.cpu > 60 ? 'warning' : 'primary'}
                      />
                      <Typography variant="caption">{node.cpu}%</Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <LinearProgress 
                        variant="determinate" 
                        value={node.memory}
                        sx={{ width: 60, height: 6, borderRadius: 3 }}
                        color={node.memory > 80 ? 'error' : node.memory > 60 ? 'warning' : 'success'}
                      />
                      <Typography variant="caption">{node.memory}%</Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">
                      {new Date(node.lastSeen).toLocaleTimeString('ar-SA')}
                    </Typography>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    </Box>
  );
}
