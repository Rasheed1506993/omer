import React from 'react';
import { useAuth } from '../context/AuthContext';
import MinistryDashboard from './MinistryDashboard';
import UniversityDashboard from './UniversityDashboard';

export default function Dashboard() {
  const { user } = useAuth();

  // Ministry sees all universities and all students
  if (user?.universityId === 'MINISTRY') {
    return <MinistryDashboard />;
  }

  // Universities see only their students
  return <UniversityDashboard />;
}
