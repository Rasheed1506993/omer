import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Typography,
  Box,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  CircularProgress,
  Alert,
  Tabs,
  Tab
} from '@mui/material';
import {
  Add,
  Visibility,
  CheckCircle,
  Cancel,
  SwapHoriz,
  School
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { toast } from 'react-toastify';

export default function TransferList() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [transfers, setTransfers] = useState([]);
  const [filteredTransfers, setFilteredTransfers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedTransfer, setSelectedTransfer] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [comments, setComments] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [tabValue, setTabValue] = useState(0);

  useEffect(() => {
    loadTransfers();
  }, [user]);

  useEffect(() => {
    filterTransfersByTab();
  }, [tabValue, transfers]);

  const loadTransfers = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.get('/api/transfers/pending');
      const allTransfers = response.data.data || [];
      
      // Filter based on user role
      let transfersToShow = allTransfers;
      if (user?.universityId !== 'MINISTRY') {
        // Universities see transfers involving them
        transfersToShow = allTransfers.filter(
          t => t.fromUniversity === user?.universityId || 
               t.toUniversity === user?.universityId
        );
      }
      
      setTransfers(transfersToShow);
      setFilteredTransfers(transfersToShow);
    } catch (error) {
      console.error('Error loading transfers:', error);
      setError(error.response?.data?.message || 'فشل في تحميل طلبات النقل');
      setTransfers([]);
      setFilteredTransfers([]);
    } finally {
      setLoading(false);
    }
  };

  const filterTransfersByTab = () => {
    if (tabValue === 0) {
      // All transfers
      setFilteredTransfers(transfers);
    } else if (tabValue === 1) {
      // Pending only
      setFilteredTransfers(transfers.filter(t => 
        t.status === 'pending' || t.status === 'approved_by_source'
      ));
    } else if (tabValue === 2) {
      // Completed only
      setFilteredTransfers(transfers.filter(t => t.status === 'completed'));
    }
  };

  const handleApprove = async () => {
    if (!selectedTransfer) return;

    setActionLoading(true);
    try {
      await axios.put(`/api/transfers/${selectedTransfer.transferId}/approve`, {
        approved: true,
        comments: comments || 'تمت الموافقة'
      });
      
      toast.success('تمت الموافقة على طلب النقل بنجاح');
      setDialogOpen(false);
      setComments('');
      loadTransfers();
    } catch (error) {
      toast.error(error.response?.data?.message || 'فشلت الموافقة');
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async () => {
    if (!selectedTransfer) return;

    setActionLoading(true);
    try {
      await axios.put(`/api/transfers/${selectedTransfer.transferId}/approve`, {
        approved: false,
        comments: comments || 'تم الرفض'
      });
      
      toast.success('تم رفض طلب النقل');
      setDialogOpen(false);
      setComments('');
      loadTransfers();
    } catch (error) {
      toast.error(error.response?.data?.message || 'فشل الرفض');
    } finally {
      setActionLoading(false);
    }
  };

  const canApprove = (transfer) => {
    if (user?.universityId === 'MINISTRY') {
      return transfer.status === 'approved_by_source';
    }
    
    if (user?.universityId === transfer.fromUniversity) {
      return transfer.status === 'pending';
    }
    
    return false;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'success';
      case 'approved_by_source':
        return 'warning';
      case 'pending':
        return 'info';
      case 'rejected':
        return 'error';
      default:
        return 'default';
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'completed':
        return 'مكتمل';
      case 'approved_by_source':
        return 'بانتظار الوزارة';
      case 'pending':
        return 'معلق';
      case 'rejected':
        return 'مرفوض';
      default:
        return status;
    }
  };

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
          <Box textAlign="center">
            <CircularProgress size={60} />
            <Typography variant="body1" sx={{ mt: 2 }}>
              جاري تحميل طلبات النقل...
            </Typography>
          </Box>
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {/* Header */}
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
            طلبات النقل
          </Typography>
          <Typography variant="body1" color="text.secondary">
            إدارة طلبات نقل الطلاب بين الجامعات
          </Typography>
        </Box>
        {user?.universityId !== 'MINISTRY' && (
          <Button
            variant="contained"
            startIcon={<Add />}
            onClick={() => navigate('/transfers/create')}
            size="large"
          >
            طلب نقل جديد
          </Button>
        )}
      </Box>

      {/* Error Alert */}
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {/* Tabs */}
      <Paper sx={{ mb: 3 }}>
        <Tabs 
          value={tabValue} 
          onChange={(e, newValue) => setTabValue(newValue)}
          variant="fullWidth"
        >
          <Tab label={`الكل (${transfers.length})`} />
          <Tab label={`المعلقة (${transfers.filter(t => t.status === 'pending' || t.status === 'approved_by_source').length})`} />
          <Tab label={`المكتملة (${transfers.filter(t => t.status === 'completed').length})`} />
        </Tabs>
      </Paper>

      {/* Empty State */}
      {!error && filteredTransfers.length === 0 && (
        <Paper sx={{ p: 8, textAlign: 'center' }}>
          <SwapHoriz sx={{ fontSize: 80, color: 'text.secondary', mb: 2 }} />
          <Typography variant="h5" gutterBottom>
            {tabValue === 0 ? 'لا توجد طلبات نقل' :
             tabValue === 1 ? 'لا توجد طلبات معلقة' :
             'لا توجد طلبات مكتملة'}
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
            {user?.universityId === 'MINISTRY' 
              ? 'سيظهر هنا جميع طلبات النقل بين الجامعات'
              : 'يمكنك إنشاء طلب نقل لطالب من جامعة أخرى'
            }
          </Typography>
          {user?.universityId !== 'MINISTRY' && tabValue === 0 && (
            <Button
              variant="contained"
              startIcon={<Add />}
              onClick={() => navigate('/transfers/create')}
              size="large"
            >
              إنشاء طلب نقل
            </Button>
          )}
        </Paper>
      )}

      {/* Transfers Table */}
      {!error && filteredTransfers.length > 0 && (
        <Paper>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>رقم الطلب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الطالب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>من</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>إلى</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>السبب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الحالة</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الإجراءات</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredTransfers.map((transfer) => (
                  <TableRow key={transfer.transferId} hover>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {transfer.transferId}
                      </Typography>
                    </TableCell>
                    <TableCell>{transfer.studentId}</TableCell>
                    <TableCell>
                      <Chip
                        icon={<School />}
                        label={transfer.fromUniversity}
                        size="small"
                        color="warning"
                        variant="outlined"
                      />
                    </TableCell>
                    <TableCell>
                      <Chip
                        icon={<School />}
                        label={transfer.toUniversity}
                        size="small"
                        color="success"
                        variant="outlined"
                      />
                    </TableCell>
                    <TableCell>
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          maxWidth: 200, 
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap'
                        }}
                      >
                        {transfer.reason}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={getStatusLabel(transfer.status)}
                        size="small"
                        color={getStatusColor(transfer.status)}
                      />
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        {canApprove(transfer) && (
                          <Button
                            size="small"
                            variant="contained"
                            color="success"
                            startIcon={<CheckCircle />}
                            onClick={() => {
                              setSelectedTransfer(transfer);
                              setDialogOpen(true);
                            }}
                          >
                            موافقة
                          </Button>
                        )}
                        <IconButton
                          size="small"
                          color="primary"
                          onClick={() => navigate(`/transfers`)}
                        >
                          <Visibility />
                        </IconButton>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {/* Approval Dialog */}
      <Dialog open={dialogOpen} onClose={() => !actionLoading && setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          الموافقة على طلب النقل
        </DialogTitle>
        <DialogContent>
          {selectedTransfer && (
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" color="text.secondary">
                رقم الطلب: <strong>{selectedTransfer.transferId}</strong>
              </Typography>
              <Typography variant="body2" color="text.secondary">
                الطالب: <strong>{selectedTransfer.studentId}</strong>
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                من {selectedTransfer.fromUniversity} إلى {selectedTransfer.toUniversity}
              </Typography>
            </Box>
          )}
          <TextField
            fullWidth
            multiline
            rows={3}
            label="ملاحظات (اختياري)"
            value={comments}
            onChange={(e) => setComments(e.target.value)}
            placeholder="أضف أي ملاحظات..."
          />
        </DialogContent>
        <DialogActions>
          <Button 
            onClick={() => setDialogOpen(false)} 
            disabled={actionLoading}
          >
            إلغاء
          </Button>
          <Button
            onClick={handleReject}
            color="error"
            startIcon={<Cancel />}
            disabled={actionLoading}
          >
            رفض
          </Button>
          <Button
            onClick={handleApprove}
            variant="contained"
            color="success"
            startIcon={<CheckCircle />}
            disabled={actionLoading}
          >
            {actionLoading ? 'جاري الموافقة...' : 'موافقة'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}
