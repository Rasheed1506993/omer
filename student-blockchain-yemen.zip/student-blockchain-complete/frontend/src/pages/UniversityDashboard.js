import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Grid,
  Paper,
  Typography,
  Box,
  Button,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  CircularProgress,
  Alert
} from '@mui/material';
import {
  People,
  SwapHoriz,
  TrendingUp,
  Add,
  Visibility,
  School
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { toast } from 'react-toastify';

export default function UniversityDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalStudents: 0,
    activeStudents: 0,
    incomingTransfers: 0,
    outgoingTransfers: 0
  });
  const [myStudents, setMyStudents] = useState([]);
  const [myTransfers, setMyTransfers] = useState([]);

  useEffect(() => {
    loadUniversityData();
  }, [user]);

  const loadUniversityData = async () => {
    try {
      setLoading(true);

      // Load all students from MY university only
      let allStudents = [];
      let allTransfers = [];
      
      try {
        const studentsRes = await axios.get('/api/students');
        allStudents = studentsRes.data.data?.students || [];
      } catch (err) {
        console.error('Error loading students:', err);
      }
      
      const universityStudents = allStudents.filter(
        s => s.currentUniversity === user?.universityId
      );
      setMyStudents(universityStudents);

      // Load transfers involving MY university
      try {
        const transfersRes = await axios.get('/api/transfers/pending');
        allTransfers = transfersRes.data.data || [];
      } catch (err) {
        console.error('Error loading transfers:', err);
      }
      
      const myTransfersList = allTransfers.filter(
        t => t.fromUniversity === user?.universityId || 
             t.toUniversity === user?.universityId
      );
      setMyTransfers(myTransfersList);

      setStats({
        totalStudents: universityStudents.length,
        activeStudents: universityStudents.filter(s => s.status === 'active').length,
        incomingTransfers: myTransfersList.filter(t => t.toUniversity === user?.universityId).length,
        outgoingTransfers: myTransfersList.filter(t => t.fromUniversity === user?.universityId).length
      });

    } catch (error) {
      console.error('Error loading university data:', error);
      // Don't show error toast for initial load with empty DB
    } finally {
      setLoading(false);
    }
  };

  const handleApproveTransfer = async (transferId) => {
    try {
      await axios.put(`/api/transfers/${transferId}/approve`, {
        approved: true,
        comments: `تمت الموافقة من ${user?.universityId}`
      });
      toast.success('تمت الموافقة على النقل');
      loadUniversityData();
    } catch (error) {
      toast.error(error.response?.data?.message || 'فشلت الموافقة');
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom sx={{ fontWeight: 700 }}>
          لوحة تحكم {user?.universityId}
        </Typography>
        <Typography variant="body1" color="text.secondary">
          إدارة طلاب الجامعة وطلبات النقل
        </Typography>
      </Box>

      {/* Statistics Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%)',
            color: 'white',
            cursor: 'pointer',
            '&:hover': { transform: 'translateY(-4px)', transition: 'all 0.3s' }
          }}
          onClick={() => navigate('/students')}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {stats.totalStudents}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    إجمالي الطلاب
                  </Typography>
                </Box>
                <People sx={{ fontSize: 60, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #43a047 0%, #2e7d32 100%)',
            color: 'white'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {stats.activeStudents}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    طلاب نشطين
                  </Typography>
                </Box>
                <TrendingUp sx={{ fontSize: 60, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #0288d1 0%, #01579b 100%)',
            color: 'white'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {stats.incomingTransfers}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    نقل وارد
                  </Typography>
                </Box>
                <SwapHoriz sx={{ fontSize: 60, opacity: 0.3 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ 
            background: 'linear-gradient(135deg, #f57c00 0%, #e65100 100%)',
            color: 'white'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h3" sx={{ fontWeight: 700 }}>
                    {stats.outgoingTransfers}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    نقل صادر
                  </Typography>
                </Box>
                <SwapHoriz sx={{ fontSize: 60, opacity: 0.3, transform: 'rotate(180deg)' }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Quick Actions */}
      <Typography variant="h5" gutterBottom sx={{ fontWeight: 600, mb: 2 }}>
        الإجراءات السريعة
      </Typography>
      <Grid container spacing={2} sx={{ mb: 4 }}>
        <Grid item xs={12} md={4}>
          <Button
            variant="contained"
            fullWidth
            size="large"
            startIcon={<Add />}
            onClick={() => navigate('/students/create')}
            sx={{ py: 2 }}
          >
            إضافة طالب جديد
          </Button>
        </Grid>
        <Grid item xs={12} md={4}>
          <Button
            variant="contained"
            fullWidth
            size="large"
            color="secondary"
            startIcon={<SwapHoriz />}
            onClick={() => navigate('/transfers/create')}
            sx={{ py: 2 }}
          >
            طلب نقل طالب
          </Button>
        </Grid>
        <Grid item xs={12} md={4}>
          <Button
            variant="outlined"
            fullWidth
            size="large"
            startIcon={<People />}
            onClick={() => navigate('/students')}
            sx={{ py: 2 }}
          >
            عرض جميع الطلاب
          </Button>
        </Grid>
      </Grid>

      {/* Recent Students */}
      {myStudents.length > 0 && (
        <Box sx={{ mb: 4 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h5" sx={{ fontWeight: 600 }}>
              طلاب الجامعة
            </Typography>
            <Button
              variant="text"
              onClick={() => navigate('/students')}
            >
              عرض الكل ({myStudents.length})
            </Button>
          </Box>

          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>رقم الطالب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الاسم</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>التخصص</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>المعدل</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الحالة</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الإجراءات</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {myStudents.slice(0, 5).map((student) => (
                  <TableRow key={student.studentId} hover>
                    <TableCell>{student.studentId}</TableCell>
                    <TableCell>{student.fullName}</TableCell>
                    <TableCell>{student.major}</TableCell>
                    <TableCell>{student.gpa || '-'}</TableCell>
                    <TableCell>
                      <Chip
                        label={student.status === 'active' ? 'نشط' : 'غير نشط'}
                        color={student.status === 'active' ? 'success' : 'default'}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>
                      <IconButton
                        size="small"
                        onClick={() => navigate(`/students/${student.studentId}`)}
                        color="primary"
                      >
                        <Visibility />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {/* Pending Transfers */}
      {myTransfers.length > 0 && (
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 600, mb: 2 }}>
            طلبات النقل
          </Typography>

          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>رقم الطلب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الطالب</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>من</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>إلى</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>النوع</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الحالة</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>الإجراءات</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {myTransfers.slice(0, 5).map((transfer) => {
                  const isOutgoing = transfer.fromUniversity === user?.universityId;
                  const needsMyApproval = isOutgoing && transfer.status === 'pending';

                  return (
                    <TableRow key={transfer.transferId} hover>
                      <TableCell>{transfer.transferId}</TableCell>
                      <TableCell>{transfer.studentId}</TableCell>
                      <TableCell>
                        <Chip 
                          label={transfer.fromUniversity} 
                          size="small" 
                          color={isOutgoing ? 'error' : 'default'}
                          variant={isOutgoing ? 'filled' : 'outlined'}
                        />
                      </TableCell>
                      <TableCell>
                        <Chip 
                          label={transfer.toUniversity} 
                          size="small" 
                          color={!isOutgoing ? 'success' : 'default'}
                          variant={!isOutgoing ? 'filled' : 'outlined'}
                        />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={isOutgoing ? 'صادر' : 'وارد'}
                          size="small"
                          color={isOutgoing ? 'warning' : 'info'}
                        />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={
                            transfer.status === 'pending' ? 'معلق' :
                            transfer.status === 'approved_by_source' ? 'بانتظار الوزارة' :
                            'مكتمل'
                          }
                          color={
                            transfer.status === 'completed' ? 'success' : 'warning'
                          }
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        {needsMyApproval ? (
                          <Button
                            size="small"
                            variant="contained"
                            color="success"
                            onClick={() => handleApproveTransfer(transfer.transferId)}
                          >
                            موافقة
                          </Button>
                        ) : (
                          <IconButton
                            size="small"
                            onClick={() => navigate('/transfers')}
                            color="primary"
                          >
                            <Visibility />
                          </IconButton>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {/* Empty States */}
      {myStudents.length === 0 && (
        <Paper sx={{ p: 6, textAlign: 'center', mb: 4 }}>
          <School sx={{ fontSize: 80, color: 'text.secondary', mb: 2 }} />
          <Typography variant="h5" gutterBottom>
            لا يوجد طلاب في الجامعة
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
            ابدأ بإضافة أول طالب
          </Typography>
          <Button
            variant="contained"
            size="large"
            startIcon={<Add />}
            onClick={() => navigate('/students/create')}
          >
            إضافة طالب جديد
          </Button>
        </Paper>
      )}
    </Box>
  );
}
