import React, { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  Box,
  Drawer,
  AppBar,
  Toolbar,
  List,
  Typography,
  Divider,
  IconButton,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Avatar,
  Menu,
  MenuItem,
  Badge,
  Chip,
  Container
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  People as PeopleIcon,
  SwapHoriz as SwapHorizIcon,
  Logout as LogoutIcon,
  Person as PersonIcon,
  Notifications as NotificationsIcon,
  School as SchoolIcon,
  AdminPanelSettings as AdminIcon,
  Business as BusinessIcon
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';

const drawerWidth = 280;

export default function EnhancedLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleNavigation = (path) => {
    navigate(path);
    if (mobileOpen) {
      setMobileOpen(false);
    }
  };

  // Determine organization type and get appropriate color
  const getOrgConfig = () => {
    if (user?.universityId === 'MINISTRY') {
      return {
        name: 'وزارة التعليم',
        nameEn: 'Ministry of Education',
        color: '#1976d2',
        icon: <AdminIcon sx={{ fontSize: 40 }} />,
        type: 'ministry'
      };
    } else {
      return {
        name: user?.universityId || 'الجامعة',
        nameEn: 'University',
        color: '#2e7d32',
        icon: <SchoolIcon sx={{ fontSize: 40 }} />,
        type: 'university'
      };
    }
  };

  const orgConfig = getOrgConfig();

  const menuItems = [
    { 
      text: 'لوحة التحكم', 
      icon: <DashboardIcon />, 
      path: '/dashboard',
      roles: ['admin', 'university_admin', 'registrar', 'viewer']
    },
    { 
      text: 'إدارة الطلاب', 
      icon: <PeopleIcon />, 
      path: '/students',
      roles: ['admin', 'university_admin', 'registrar', 'viewer']
    },
    { 
      text: 'طلبات النقل', 
      icon: <SwapHorizIcon />, 
      path: '/transfers',
      roles: ['admin', 'university_admin', 'registrar', 'viewer']
    },
  ];

  const drawer = (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Organization Header */}
      <Box sx={{ 
        p: 3, 
        bgcolor: orgConfig.color,
        background: `linear-gradient(135deg, ${orgConfig.color} 0%, ${orgConfig.color}dd 100%)`,
        color: 'white',
        textAlign: 'center'
      }}>
        <Box sx={{ mb: 2 }}>
          {orgConfig.icon}
        </Box>
        <Typography variant="h6" sx={{ fontWeight: 700, mb: 0.5 }}>
          نظام التحقق من الطلاب
        </Typography>
        <Typography variant="body2" sx={{ opacity: 0.9, fontSize: '0.85rem' }}>
          {orgConfig.name}
        </Typography>
        <Chip 
          label={orgConfig.type === 'ministry' ? 'الوزارة' : 'جامعة'}
          size="small"
          sx={{ 
            mt: 1.5,
            bgcolor: 'rgba(255,255,255,0.2)',
            color: 'white',
            fontWeight: 600
          }}
        />
      </Box>

      <Divider />

      {/* Navigation Menu */}
      <List sx={{ flex: 1, pt: 2 }}>
        {menuItems
          .filter(item => item.roles.includes(user?.role))
          .map((item) => {
            const isActive = location.pathname === item.path || 
                           (item.path !== '/dashboard' && location.pathname.startsWith(item.path));
            
            return (
              <ListItem key={item.text} disablePadding sx={{ px: 2, mb: 1 }}>
                <ListItemButton 
                  onClick={() => handleNavigation(item.path)}
                  sx={{
                    borderRadius: 2,
                    bgcolor: isActive ? `${orgConfig.color}15` : 'transparent',
                    color: isActive ? orgConfig.color : 'text.primary',
                    '&:hover': {
                      bgcolor: isActive ? `${orgConfig.color}20` : `${orgConfig.color}08`,
                    },
                    py: 1.5
                  }}
                >
                  <ListItemIcon sx={{ 
                    color: isActive ? orgConfig.color : 'text.secondary',
                    minWidth: 45
                  }}>
                    {item.icon}
                  </ListItemIcon>
                  <ListItemText 
                    primary={item.text}
                    primaryTypographyProps={{
                      fontWeight: isActive ? 700 : 500,
                      fontSize: '0.95rem'
                    }}
                  />
                </ListItemButton>
              </ListItem>
            );
          })}
      </List>

      <Divider />

      {/* User Info Footer */}
      <Box sx={{ p: 2, bgcolor: 'background.default' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Avatar sx={{ 
            bgcolor: orgConfig.color,
            width: 45,
            height: 45,
            fontSize: '1.2rem',
            fontWeight: 700
          }}>
            {user?.fullName?.charAt(0)}
          </Avatar>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography variant="subtitle2" noWrap sx={{ fontWeight: 600 }}>
              {user?.fullName}
            </Typography>
            <Typography variant="caption" color="text.secondary" noWrap>
              {user?.role === 'admin' ? 'مدير النظام' :
               user?.role === 'university_admin' ? 'مدير الجامعة' :
               user?.role === 'registrar' ? 'موظف قبول' : 'عارض'}
            </Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* AppBar */}
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          mr: { sm: `${drawerWidth}px` },
          bgcolor: 'white',
          borderBottom: '1px solid',
          borderColor: 'divider'
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ ml: 2, display: { sm: 'none' }, color: 'text.primary' }}
          >
            <MenuIcon />
          </IconButton>
          
          <Box sx={{ flexGrow: 1 }} />

          {/* Notifications */}
          <IconButton color="inherit" sx={{ color: 'text.primary' }}>
            <Badge badgeContent={3} color="error">
              <NotificationsIcon />
            </Badge>
          </IconButton>

          {/* User Menu */}
          <IconButton onClick={handleMenu} sx={{ ml: 1 }}>
            <Avatar sx={{ 
              bgcolor: orgConfig.color,
              width: 40,
              height: 40,
              fontSize: '1rem',
              fontWeight: 600
            }}>
              {user?.fullName?.charAt(0)}
            </Avatar>
          </IconButton>
          
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleClose}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            transformOrigin={{ vertical: 'top', horizontal: 'left' }}
            sx={{ mt: 1 }}
          >
            <Box sx={{ px: 2, py: 1.5, minWidth: 200 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                {user?.fullName}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {user?.email || user?.username}
              </Typography>
            </Box>
            <Divider />
            <MenuItem onClick={handleClose}>
              <ListItemIcon>
                <PersonIcon fontSize="small" />
              </ListItemIcon>
              <ListItemText>الملف الشخصي</ListItemText>
            </MenuItem>
            <Divider />
            <MenuItem onClick={handleLogout}>
              <ListItemIcon>
                <LogoutIcon fontSize="small" color="error" />
              </ListItemIcon>
              <ListItemText>
                <Typography color="error">تسجيل الخروج</Typography>
              </ListItemText>
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      {/* Sidebar */}
      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{ keepMounted: true }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { 
              boxSizing: 'border-box', 
              width: drawerWidth,
              borderRight: 'none',
              boxShadow: 3
            },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', sm: 'block' },
            '& .MuiDrawer-paper': { 
              boxSizing: 'border-box', 
              width: drawerWidth,
              borderRight: '1px solid',
              borderColor: 'divider'
            },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>

      {/* Main Content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          minHeight: '100vh',
          bgcolor: 'background.default'
        }}
      >
        <Toolbar />
        <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
          <Outlet />
        </Container>
      </Box>
    </Box>
  );
}
