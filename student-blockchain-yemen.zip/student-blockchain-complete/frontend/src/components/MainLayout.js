import React, { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  Box,
  Drawer,
  AppBar,
  Toolbar,
  List,
  Typography,
  Divider,
  IconButton,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Avatar,
  Menu,
  MenuItem,
  Badge,
  Chip,
  Collapse,
  Tooltip,
  useTheme,
  useMediaQuery,
  alpha
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  People as PeopleIcon,
  SwapHoriz as SwapHorizIcon,
  Logout as LogoutIcon,
  Person as PersonIcon,
  Notifications as NotificationsIcon,
  School as SchoolIcon,
  AdminPanelSettings as AdminIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  Search as SearchIcon,
  Add as AddIcon,
  ExpandLess,
  ExpandMore,
  Business as BusinessIcon,
  Security as SecurityIcon,
  History as HistoryIcon,
  CheckCircle as CheckCircleIcon,
  Settings as SettingsIcon,
  Storage as StorageIcon,
  NetworkCheck as NetworkIcon,
  VerifiedUser as VerifiedIcon
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';

const drawerWidth = 280;
const drawerCollapsedWidth = 72;

export default function MainLayout() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [notificationAnchor, setNotificationAnchor] = useState(null);
  const [openSubMenu, setOpenSubMenu] = useState({});

  const isMinistry = user?.universityId === 'MINISTRY';

  const handleDrawerToggle = () => {
    if (isMobile) {
      setMobileOpen(!mobileOpen);
    } else {
      setCollapsed(!collapsed);
    }
  };

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleNotificationMenu = (event) => {
    setNotificationAnchor(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleNotificationClose = () => {
    setNotificationAnchor(null);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleNavigation = (path) => {
    navigate(path);
    if (isMobile) {
      setMobileOpen(false);
    }
  };

  const handleSubMenuToggle = (key) => {
    setOpenSubMenu(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  // Get organization config based on user type
  const getOrgConfig = () => {
    if (isMinistry) {
      return {
        name: 'وزارة التعليم العالي',
        nameEn: 'Ministry of Higher Education',
        color: '#1565c0',
        gradient: 'linear-gradient(135deg, #1565c0 0%, #0d47a1 100%)',
        icon: <AdminIcon sx={{ fontSize: 36 }} />,
        type: 'ministry'
      };
    } else {
      return {
        name: user?.universityId || 'الجامعة',
        nameEn: 'University',
        color: '#2e7d32',
        gradient: 'linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%)',
        icon: <SchoolIcon sx={{ fontSize: 36 }} />,
        type: 'university'
      };
    }
  };

  const orgConfig = getOrgConfig();

  // Menu items configuration
  const menuItems = [
    { 
      text: 'لوحة التحكم', 
      icon: <DashboardIcon />, 
      path: '/dashboard',
      roles: ['admin', 'university_admin', 'registrar', 'viewer']
    },
    { 
      text: 'إدارة الطلاب', 
      icon: <PeopleIcon />, 
      path: '/students',
      roles: ['admin', 'university_admin', 'registrar', 'viewer'],
      subItems: [
        { text: 'جميع الطلاب', path: '/students', icon: <PeopleIcon /> },
        { text: 'إضافة طالب', path: '/students/create', icon: <AddIcon /> },
        { text: 'البحث عن طالب', path: '/students/search', icon: <SearchIcon /> }
      ]
    },
    { 
      text: 'طلبات النقل', 
      icon: <SwapHorizIcon />, 
      path: '/transfers',
      roles: ['admin', 'university_admin', 'registrar', 'viewer'],
      subItems: [
        { text: 'جميع الطلبات', path: '/transfers', icon: <SwapHorizIcon /> },
        { text: 'طلب نقل جديد', path: '/transfers/create', icon: <AddIcon /> }
      ]
    },
    { 
      text: 'طلبات الموافقة', 
      icon: <CheckCircleIcon />, 
      path: '/approvals',
      roles: ['admin', 'university_admin', 'registrar'],
      badge: 3
    },
    // Ministry-only items
    { 
      text: 'إدارة الجامعات', 
      icon: <BusinessIcon />, 
      path: '/universities',
      roles: ['admin'],
      ministryOnly: true
    },
    { 
      text: 'حالة الشبكة', 
      icon: <NetworkIcon />, 
      path: '/network',
      roles: ['admin'],
      ministryOnly: true
    },
    { 
      text: 'سجل التدقيق', 
      icon: <HistoryIcon />, 
      path: '/audit',
      roles: ['admin', 'university_admin'],
    },
    { 
      text: 'الإعدادات', 
      icon: <SettingsIcon />, 
      path: '/settings',
      roles: ['admin', 'university_admin']
    }
  ];

  // Filter menu items based on role and ministry status
  const filteredMenuItems = menuItems.filter(item => {
    if (item.ministryOnly && !isMinistry) return false;
    return item.roles.includes(user?.role);
  });

  const currentWidth = collapsed && !isMobile ? drawerCollapsedWidth : drawerWidth;

  const drawer = (
    <Box sx={{ 
      height: '100%', 
      display: 'flex', 
      flexDirection: 'column',
      bgcolor: 'background.paper'
    }}>
      {/* Organization Header */}
      <Box sx={{ 
        p: collapsed ? 1.5 : 2.5,
        background: orgConfig.gradient,
        color: 'white',
        textAlign: 'center',
        minHeight: collapsed ? 80 : 140,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        transition: 'all 0.3s ease'
      }}>
        <Box sx={{ 
          mb: collapsed ? 0 : 1.5,
          transition: 'all 0.3s ease'
        }}>
          {orgConfig.icon}
        </Box>
        {!collapsed && (
          <>
            <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 0.5, lineHeight: 1.3 }}>
              نظام التحقق من بيانات الطلاب
            </Typography>
            <Typography variant="caption" sx={{ opacity: 0.9 }}>
              {orgConfig.name}
            </Typography>
            <Chip 
              label={isMinistry ? 'الوزارة' : 'جامعة'}
              size="small"
              sx={{ 
                mt: 1,
                bgcolor: 'rgba(255,255,255,0.2)',
                color: 'white',
                fontWeight: 600,
                fontSize: '0.7rem'
              }}
            />
          </>
        )}
      </Box>

      {/* Collapse Button */}
      {!isMobile && (
        <Box sx={{ 
          display: 'flex', 
          justifyContent: collapsed ? 'center' : 'flex-end',
          p: 1,
          borderBottom: 1,
          borderColor: 'divider'
        }}>
          <IconButton 
            onClick={handleDrawerToggle}
            size="small"
            sx={{ 
              bgcolor: alpha(orgConfig.color, 0.1),
              '&:hover': { bgcolor: alpha(orgConfig.color, 0.2) }
            }}
          >
            {collapsed ? <ChevronRightIcon /> : <ChevronLeftIcon />}
          </IconButton>
        </Box>
      )}

      {/* Navigation Menu */}
      <Box sx={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', py: 1 }}>
        <List>
          {filteredMenuItems.map((item) => {
            const isActive = location.pathname === item.path || 
                           (item.path !== '/dashboard' && location.pathname.startsWith(item.path));
            const hasSubItems = item.subItems && item.subItems.length > 0;
            const isSubMenuOpen = openSubMenu[item.text];

            return (
              <React.Fragment key={item.text}>
                <ListItem disablePadding sx={{ px: collapsed ? 0.5 : 1.5, mb: 0.5 }}>
                  <Tooltip title={collapsed ? item.text : ''} placement="left" arrow>
                    <ListItemButton 
                      onClick={() => {
                        if (hasSubItems && !collapsed) {
                          handleSubMenuToggle(item.text);
                        } else {
                          handleNavigation(item.path);
                        }
                      }}
                      sx={{
                        borderRadius: 2,
                        minHeight: 48,
                        justifyContent: collapsed ? 'center' : 'flex-start',
                        bgcolor: isActive ? alpha(orgConfig.color, 0.12) : 'transparent',
                        color: isActive ? orgConfig.color : 'text.primary',
                        '&:hover': {
                          bgcolor: isActive ? alpha(orgConfig.color, 0.16) : alpha(orgConfig.color, 0.08),
                        },
                        px: collapsed ? 1 : 2
                      }}
                    >
                      <ListItemIcon sx={{ 
                        color: isActive ? orgConfig.color : 'text.secondary',
                        minWidth: collapsed ? 0 : 40,
                        justifyContent: 'center'
                      }}>
                        {item.badge ? (
                          <Badge badgeContent={item.badge} color="error">
                            {item.icon}
                          </Badge>
                        ) : item.icon}
                      </ListItemIcon>
                      {!collapsed && (
                        <>
                          <ListItemText 
                            primary={item.text}
                            primaryTypographyProps={{
                              fontWeight: isActive ? 600 : 500,
                              fontSize: '0.9rem'
                            }}
                          />
                          {hasSubItems && (
                            isSubMenuOpen ? <ExpandLess /> : <ExpandMore />
                          )}
                        </>
                      )}
                    </ListItemButton>
                  </Tooltip>
                </ListItem>

                {/* Sub Menu */}
                {hasSubItems && !collapsed && (
                  <Collapse in={isSubMenuOpen} timeout="auto" unmountOnExit>
                    <List component="div" disablePadding>
                      {item.subItems.map((subItem) => {
                        const isSubActive = location.pathname === subItem.path;
                        return (
                          <ListItem key={subItem.text} disablePadding sx={{ px: 1.5 }}>
                            <ListItemButton 
                              onClick={() => handleNavigation(subItem.path)}
                              sx={{
                                borderRadius: 2,
                                mr: 2,
                                bgcolor: isSubActive ? alpha(orgConfig.color, 0.08) : 'transparent',
                                '&:hover': { bgcolor: alpha(orgConfig.color, 0.08) }
                              }}
                            >
                              <ListItemIcon sx={{ 
                                color: isSubActive ? orgConfig.color : 'text.secondary',
                                minWidth: 36
                              }}>
                                {subItem.icon}
                              </ListItemIcon>
                              <ListItemText 
                                primary={subItem.text}
                                primaryTypographyProps={{
                                  fontSize: '0.85rem',
                                  fontWeight: isSubActive ? 600 : 400
                                }}
                              />
                            </ListItemButton>
                          </ListItem>
                        );
                      })}
                    </List>
                  </Collapse>
                )}
              </React.Fragment>
            );
          })}
        </List>
      </Box>

      <Divider />

      {/* User Info Footer */}
      <Box sx={{ 
        p: collapsed ? 1 : 2, 
        bgcolor: alpha(orgConfig.color, 0.04),
        transition: 'all 0.3s ease'
      }}>
        <Box sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: collapsed ? 0 : 1.5,
          justifyContent: collapsed ? 'center' : 'flex-start'
        }}>
          <Avatar sx={{ 
            bgcolor: orgConfig.color,
            width: collapsed ? 36 : 42,
            height: collapsed ? 36 : 42,
            fontSize: collapsed ? '0.9rem' : '1.1rem',
            fontWeight: 700
          }}>
            {user?.fullName?.charAt(0)}
          </Avatar>
          {!collapsed && (
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography variant="subtitle2" noWrap sx={{ fontWeight: 600 }}>
                {user?.fullName}
              </Typography>
              <Typography variant="caption" color="text.secondary" noWrap>
                {user?.role === 'admin' ? 'مدير النظام' :
                 user?.role === 'university_admin' ? 'مدير الجامعة' :
                 user?.role === 'registrar' ? 'موظف قبول' : 'عارض'}
              </Typography>
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: '#f5f7fa' }}>
      {/* AppBar */}
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          width: { md: `calc(100% - ${currentWidth}px)` },
          mr: { md: `${currentWidth}px` },
          bgcolor: 'white',
          borderBottom: '1px solid',
          borderColor: 'divider',
          transition: 'width 0.3s ease, margin 0.3s ease'
        }}
      >
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <IconButton
              color="inherit"
              edge="start"
              onClick={handleDrawerToggle}
              sx={{ mr: 2, color: 'text.primary', display: { md: 'none' } }}
            >
              <MenuIcon />
            </IconButton>
            
            <Box sx={{ display: { xs: 'none', sm: 'flex' }, alignItems: 'center', gap: 1 }}>
              <VerifiedIcon sx={{ color: orgConfig.color, fontSize: 28 }} />
              <Box>
                <Typography variant="subtitle1" sx={{ fontWeight: 700, color: 'text.primary', lineHeight: 1.2 }}>
                  نظام التحقق من بيانات الطلاب
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Blockchain Student Verification System
                </Typography>
              </Box>
            </Box>
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {/* Notifications */}
            <Tooltip title="الإشعارات">
              <IconButton 
                onClick={handleNotificationMenu}
                sx={{ color: 'text.primary' }}
              >
                <Badge badgeContent={3} color="error">
                  <NotificationsIcon />
                </Badge>
              </IconButton>
            </Tooltip>

            {/* User Menu */}
            <Tooltip title="الحساب">
              <IconButton onClick={handleMenu}>
                <Avatar sx={{ 
                  bgcolor: orgConfig.color,
                  width: 38,
                  height: 38,
                  fontSize: '0.95rem',
                  fontWeight: 600
                }}>
                  {user?.fullName?.charAt(0)}
                </Avatar>
              </IconButton>
            </Tooltip>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Notification Menu */}
      <Menu
        anchorEl={notificationAnchor}
        open={Boolean(notificationAnchor)}
        onClose={handleNotificationClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
        transformOrigin={{ vertical: 'top', horizontal: 'left' }}
        PaperProps={{ sx: { width: 320, maxHeight: 400 } }}
      >
        <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
            الإشعارات
          </Typography>
        </Box>
        <MenuItem onClick={handleNotificationClose}>
          <Box>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              طلب نقل جديد
            </Typography>
            <Typography variant="caption" color="text.secondary">
              طلب نقل للطالب أحمد محمد - منذ 5 دقائق
            </Typography>
          </Box>
        </MenuItem>
        <MenuItem onClick={handleNotificationClose}>
          <Box>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              موافقة على نقل
            </Typography>
            <Typography variant="caption" color="text.secondary">
              تمت الموافقة على نقل سارة علي - منذ ساعة
            </Typography>
          </Box>
        </MenuItem>
        <Divider />
        <MenuItem onClick={() => { handleNotificationClose(); navigate('/approvals'); }}>
          <Typography variant="body2" color="primary" sx={{ width: '100%', textAlign: 'center' }}>
            عرض جميع الإشعارات
          </Typography>
        </MenuItem>
      </Menu>

      {/* User Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
        transformOrigin={{ vertical: 'top', horizontal: 'left' }}
        PaperProps={{ sx: { width: 240 } }}
      >
        <Box sx={{ px: 2, py: 1.5 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
            {user?.fullName}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {user?.email || user?.username}
          </Typography>
          <Chip 
            label={isMinistry ? 'الوزارة' : user?.universityId}
            size="small"
            sx={{ mt: 1, display: 'block', width: 'fit-content' }}
          />
        </Box>
        <Divider />
        <MenuItem onClick={() => { handleClose(); navigate('/settings'); }}>
          <ListItemIcon>
            <PersonIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>الملف الشخصي</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => { handleClose(); navigate('/settings'); }}>
          <ListItemIcon>
            <SettingsIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>الإعدادات</ListItemText>
        </MenuItem>
        <Divider />
        <MenuItem onClick={handleLogout}>
          <ListItemIcon>
            <LogoutIcon fontSize="small" color="error" />
          </ListItemIcon>
          <ListItemText>
            <Typography color="error">تسجيل الخروج</Typography>
          </ListItemText>
        </MenuItem>
      </Menu>

      {/* Sidebar Drawer */}
      <Box
        component="nav"
        sx={{ 
          width: { md: currentWidth }, 
          flexShrink: { md: 0 },
          transition: 'width 0.3s ease'
        }}
      >
        {/* Mobile Drawer */}
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{ keepMounted: true }}
          sx={{
            display: { xs: 'block', md: 'none' },
            '& .MuiDrawer-paper': { 
              boxSizing: 'border-box', 
              width: drawerWidth,
              borderLeft: 'none'
            },
          }}
          anchor="right"
        >
          {drawer}
        </Drawer>

        {/* Desktop Drawer */}
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', md: 'block' },
            '& .MuiDrawer-paper': { 
              boxSizing: 'border-box', 
              width: currentWidth,
              borderLeft: '1px solid',
              borderColor: 'divider',
              transition: 'width 0.3s ease',
              overflowX: 'hidden'
            },
          }}
          anchor="right"
          open
        >
          {drawer}
        </Drawer>
      </Box>

      {/* Main Content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          width: { md: `calc(100% - ${currentWidth}px)` },
          minHeight: '100vh',
          transition: 'width 0.3s ease',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        <Toolbar />
        <Box sx={{ flex: 1, p: { xs: 2, sm: 3 }, overflow: 'auto' }}>
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
}
