import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Box } from '@mui/material';
import { useAuth } from './context/AuthContext';

// Pages
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import StudentList from './pages/StudentList';
import StudentCreate from './pages/StudentCreate';
import StudentView from './pages/StudentView';
import TransferList from './pages/TransferList';
import TransferCreate from './pages/TransferCreate';
import AuditLog from './pages/AuditLog';
import NetworkStatus from './pages/NetworkStatus';
import UniversityManagement from './pages/UniversityManagement';
import ApprovalRequests from './pages/ApprovalRequests';
import StudentSearch from './pages/StudentSearch';
import Settings from './pages/Settings';

// Components
import MainLayout from './components/MainLayout';
import PrivateRoute from './components/PrivateRoute';
import Loading from './components/Loading';

function App() {
  const { loading } = useAuth();

  if (loading) {
    return <Loading />;
  }

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />

        {/* Protected Routes */}
        <Route
          path="/"
          element={
            <PrivateRoute>
              <MainLayout />
            </PrivateRoute>
          }
        >
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          
          {/* Student Routes */}
          <Route path="students">
            <Route index element={<StudentList />} />
            <Route path="create" element={<StudentCreate />} />
            <Route path="search" element={<StudentSearch />} />
            <Route path=":id" element={<StudentView />} />
          </Route>

          {/* Transfer Routes */}
          <Route path="transfers">
            <Route index element={<TransferList />} />
            <Route path="create" element={<TransferCreate />} />
          </Route>

          {/* Approval Requests */}
          <Route path="approvals" element={<ApprovalRequests />} />

          {/* Ministry-only Routes */}
          <Route path="universities" element={<UniversityManagement />} />
          <Route path="network" element={<NetworkStatus />} />
          <Route path="audit" element={<AuditLog />} />

          {/* Settings */}
          <Route path="settings" element={<Settings />} />
        </Route>

        {/* 404 */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Box>
  );
}

export default App;
