# API Documentation

## Base URL
```
http://localhost:3000/api
```

## Authentication

All protected endpoints require a JWT token in the Authorization header:
```
Authorization: Bearer <your_jwt_token>
```

---

## Authentication Endpoints

### Login
```http
POST /api/auth/login
```

**Request Body:**
```json
{
  "username": "admin",
  "password": "admin123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": "1",
      "username": "admin",
      "role": "admin",
      "universityId": "MINISTRY",
      "fullName": "System Administrator",
      "email": "admin@ministry.gov"
    },
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### Register
```http
POST /api/auth/register
```

**Request Body:**
```json
{
  "username": "new_user",
  "password": "password123",
  "email": "user@university.edu",
  "fullName": "Full Name",
  "universityId": "UNI001",
  "role": "registrar"
}
```

### Get Profile
```http
GET /api/auth/profile
```

**Headers:**
```
Authorization: Bearer <token>
```

### Refresh Token
```http
POST /api/auth/refresh
```

**Request Body:**
```json
{
  "refreshToken": "your_refresh_token_here"
}
```

---

## Student Endpoints

### Create Student
```http
POST /api/students
```

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "studentId": "STU001",
  "nationalId": "1234567890",
  "fullName": "أحمد محمد علي",
  "fullNameEn": "Ahmed Mohammed Ali",
  "dateOfBirth": "2000-05-15",
  "nationality": "SA",
  "email": "ahmed@example.com",
  "phone": "+966501234567",
  "college": "كلية علوم الحاسب",
  "major": "علوم الحاسب",
  "enrollmentDate": "2020-09-01",
  "expectedGraduation": "2024-06-30",
  "gpa": 3.75,
  "totalCredits": 90,
  "academicLevel": "junior"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Student created successfully",
  "data": {
    "studentId": "STU001",
    "fullName": "أحمد محمد علي",
    "currentUniversity": "UNI001",
    "status": "active",
    "createdAt": "2024-11-22T10:30:00.000Z"
  }
}
```

### Get Student
```http
GET /api/students/:id
```

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "studentId": "STU001",
    "nationalId": "***hidden***",
    "fullName": "أحمد محمد علي",
    "fullNameEn": "Ahmed Mohammed Ali",
    "currentUniversity": "UNI001",
    "college": "كلية علوم الحاسب",
    "major": "علوم الحاسب",
    "gpa": 3.75,
    "status": "active"
  }
}
```

### Update Student
```http
PUT /api/students/:id
```

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "gpa": 3.85,
  "totalCredits": 100,
  "academicLevel": "senior"
}
```

### Get Student History
```http
GET /api/students/:id/history
```

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "studentId": "STU001",
    "history": [
      {
        "txId": "abc123...",
        "timestamp": "2024-11-22T10:30:00.000Z",
        "isDelete": false,
        "value": {
          "studentId": "STU001",
          "gpa": 3.75,
          "updatedBy": "UNI001"
        }
      }
    ]
  }
}
```

### Search Students
```http
GET /api/students/search?name=Ahmed&university=UNI001
```

**Query Parameters:**
- `name` (optional): Student name
- `nationalId` (optional): National ID
- `university` (optional): University ID

### Get Students by University
```http
GET /api/universities/:universityId/students
```

**Headers:**
```
Authorization: Bearer <token>
```

---

## Transfer Endpoints

### Request Transfer
```http
POST /api/transfers
```

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "studentId": "STU001",
  "fromUniversity": "UNI001",
  "toUniversity": "UNI002",
  "reason": "Student wishes to transfer for personal reasons and has met all requirements"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Transfer request created successfully",
  "data": {
    "transferId": "TRF1700123456789",
    "studentId": "STU001",
    "fromUniversity": "UNI001",
    "toUniversity": "UNI002",
    "status": "pending",
    "approvals": {
      "fromUniversity": false,
      "toUniversity": true,
      "ministry": false
    },
    "requestedAt": "2024-11-22T10:30:00.000Z"
  }
}
```

### Approve Transfer
```http
PUT /api/transfers/:id/approve
```

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "message": "Transfer approval recorded",
  "data": {
    "transferId": "TRF1700123456789",
    "status": "pending",
    "approvals": {
      "fromUniversity": true,
      "toUniversity": true,
      "ministry": false
    }
  }
}
```

### Reject Transfer
```http
PUT /api/transfers/:id/reject
```

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "reason": "Student has outstanding financial obligations"
}
```

### Get Transfer Details
```http
GET /api/transfers/:id
```

**Headers:**
```
Authorization: Bearer <token>
```

### Get Pending Transfers
```http
GET /api/transfers/pending
```

**Headers:**
```
Authorization: Bearer <token>
```

---

## User Roles

### admin (Ministry Administrator)
- Full access to all operations
- Can view all students across universities
- Can manage universities
- Can approve/reject all transfers

### university_admin (University Administrator)
- Can manage own university students
- Can approve transfers for own university
- Limited view of other university students

### registrar (Registrar)
- Can create and update own university students
- Can request transfers
- Cannot approve transfers

### viewer (Read-only)
- Can only view students from own university
- Cannot modify any data

---

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "message": "Validation error message"
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "message": "No token provided"
}
```

### 403 Forbidden
```json
{
  "success": false,
  "message": "Insufficient permissions"
}
```

### 404 Not Found
```json
{
  "success": false,
  "message": "Student not found"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "message": "Internal server error"
}
```

---

## Rate Limiting

- **Limit:** 100 requests per 15 minutes per IP
- **Response when exceeded:**
```json
{
  "success": false,
  "message": "Too many requests from this IP, please try again later"
}
```

---

## Testing with cURL

### Login Example
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }'
```

### Create Student Example
```bash
curl -X POST http://localhost:3000/api/students \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "nationalId": "1234567890",
    "fullName": "أحمد محمد",
    "dateOfBirth": "2000-01-01",
    "college": "كلية الهندسة",
    "major": "هندسة برمجيات",
    "enrollmentDate": "2020-09-01"
  }'
```

---

## Testing with Postman

1. Import the API collection (if provided)
2. Set environment variable `baseUrl` to `http://localhost:3000/api`
3. Login to get access token
4. Use token in subsequent requests

---

## Default Test Users

| Username | Password | Role | University |
|----------|----------|------|------------|
| admin | admin123 | admin | MINISTRY |
| ksu_admin | ksu123 | university_admin | UNI001 |
| ksu_registrar | registrar123 | registrar | UNI001 |

---

## Notes

- All timestamps are in ISO 8601 format (UTC)
- Sensitive data (National ID, Phone) is encrypted on blockchain
- Student IDs are auto-generated if not provided
- All operations are logged on the blockchain
- History is immutable and can be audited
