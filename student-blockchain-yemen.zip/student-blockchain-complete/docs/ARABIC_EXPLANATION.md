# شرح شامل للمشروع - نظام التحقق من بيانات الطلاب باستخدام البلوك تشين

## 📚 محتويات الشرح

1. [نظرة عامة](#نظرة-عامة)
2. [المفاهيم الأساسية](#المفاهيم-الأساسية)
3. [البنية المعمارية](#البنية-المعمارية)
4. [شرح الكود بالتفصيل](#شرح-الكود-بالتفصيل)
5. [مبادئ Clean Code المطبقة](#مبادئ-clean-code-المطبقة)
6. [كيفية التشغيل](#كيفية-التشغيل)
7. [أمثلة عملية](#أمثلة-عملية)

---

## نظرة عامة

### ما هو المشروع؟

هذا مشروع **Proof of Concept (PoC)** لنظام يحل مشكلة حقيقية في قطاع التعليم العالي:

**المشكلة:**
- عندما ينتقل طالب من جامعة لأخرى، يعتمد النظام على وثائق ورقية
- يمكن تزوير هذه الوثائق بسهولة
- لا يوجد نظام موثوق للتحقق من صحة البيانات الأكاديمية
- العمليات بطيئة وتستغرق وقتاً طويلاً

**الحل:**
نظام بلوك تشين يوفر:
- ✅ سجلات أكاديمية غير قابلة للتعديل أو التزوير
- ✅ تحقق فوري من بيانات الطلاب
- ✅ تتبع كامل لجميع التعديلات
- ✅ عمليات نقل آمنة وسريعة بين الجامعات

---

## المفاهيم الأساسية

### 1. ما هو البلوك تشين؟

**بشكل مبسط:**
البلوك تشين هو دفتر رقمي موزع يسجل المعاملات بشكل آمن وغير قابل للتعديل.

**تشبيه:**
تخيل دفتر حسابات:
- كل صفحة = كتلة (Block)
- كل سطر في الصفحة = معاملة (Transaction)
- مجموع الصفحات = السلسلة (Chain)

**الفرق:**
- الدفتر العادي: شخص واحد يمتلكه ويمكن تعديله
- البلوك تشين: نسخ متعددة عند أطراف مختلفة، لا يمكن تعديلها

### 2. ما هو Hyperledger Fabric؟

**تعريف:**
منصة بلوك تشين مصممة خصيصاً للمؤسسات والحكومات (وليس للعملات الرقمية).

**لماذا Fabric وليس Ethereum؟**
- ✅ خاص (Permissioned) - فقط الجهات المصرح لها
- ✅ أسرع في المعاملات
- ✅ لا يحتاج عملة رقمية أو رسوم
- ✅ خصوصية أفضل للبيانات الحساسة

### 3. العقود الذكية (Smart Contracts)

**تعريف:**
برامج تعمل على البلوك تشين وتنفذ قواعد العمل تلقائياً.

**في مشروعنا:**
```javascript
// مثال: إنشاء طالب جديد
async createStudent(studentData) {
    // 1. التحقق من الصلاحيات
    // 2. التحقق من صحة البيانات
    // 3. حفظ في البلوك تشين
    // 4. إرسال إشعار
}
```

---

## البنية المعمارية

### الطبقات الثلاث

```
الطبقة 1: الواجهة الأمامية (Frontend)
         ↓ REST API
الطبقة 2: الواجهة الخلفية (Backend)
         ↓ Fabric SDK
الطبقة 3: البلوك تشين (Blockchain)
```

### 1. الطبقة الأمامية (Frontend)

**التقنية:** React

**الوظيفة:**
- عرض البيانات للمستخدم
- استقبال المدخلات
- التواصل مع الـ API

**المكونات:**
```
frontend/
├── src/
│   ├── components/      # مكونات قابلة لإعادة الاستخدام
│   ├── pages/          # صفحات التطبيق
│   ├── services/       # التواصل مع API
│   ├── context/        # إدارة الحالة
│   └── utils/          # وظائف مساعدة
```

### 2. الطبقة الخلفية (Backend API)

**التقنية:** Node.js + Express

**الوظيفة:**
- استقبال طلبات HTTP
- المصادقة والتفويض
- تطبيق قواعد العمل
- التواصل مع البلوك تشين

**البنية:**
```
api/
├── src/
│   ├── controllers/    # معالجة طلبات HTTP
│   ├── services/       # منطق العمل
│   ├── middleware/     # المصادقة والتحقق
│   └── routes/         # تعريف المسارات
```

### 3. طبقة البلوك تشين

**التقنية:** Hyperledger Fabric

**المكونات:**
1. **العقد النظيرة (Peer Nodes):** تحتفظ بنسخة من الدفتر
2. **عقد الترتيب (Orderer):** ترتب المعاملات
3. **العقود الذكية (Chaincode):** تنفذ المنطق
4. **قاعدة البيانات (CouchDB):** تخزن الحالة الحالية

---

## شرح الكود بالتفصيل

### 1. العقد الذكي (Smart Contract)

**الملف:** `chaincode/student-records/lib/studentContract.js`

#### وظيفة إنشاء طالب:

```javascript
async createStudent(ctx, studentData) {
    // 1. تحليل البيانات من JSON
    const student = JSON.parse(studentData);
    
    // 2. التحقق من صحة البيانات
    this._validateStudentData(student);
    
    // 3. التحقق من عدم وجود الطالب مسبقاً
    const exists = await this._studentExists(ctx, student.studentId);
    if (exists) {
        throw new Error('الطالب موجود مسبقاً');
    }
    
    // 4. الحصول على معرف الجامعة المنفذة للعملية
    const callerOrg = await this._getCallerOrganization(ctx);
    
    // 5. إضافة بيانات إضافية
    student.createdBy = callerOrg;
    student.createdAt = new Date().toISOString();
    
    // 6. تشفير البيانات الحساسة
    student.nationalId = this._hashData(student.nationalId);
    
    // 7. حفظ في البلوك تشين
    await ctx.stub.putState(student.studentId, Buffer.from(JSON.stringify(student)));
    
    // 8. إرسال حدث (Event)
    await ctx.stub.setEvent('StudentCreated', ...);
    
    return student;
}
```

**الشرح:**
- `ctx`: سياق المعاملة (يحتوي على معلومات الشبكة)
- `ctx.stub`: واجهة للتعامل مع دفتر الأستاذ
- `putState()`: حفظ البيانات في البلوك تشين
- `setEvent()`: إرسال إشعار للمستمعين

#### وظيفة الحصول على الطالب:

```javascript
async getStudent(ctx, studentId) {
    // 1. قراءة البيانات من البلوك تشين
    const studentBytes = await ctx.stub.getState(studentId);
    
    // 2. التحقق من وجود البيانات
    if (!studentBytes || studentBytes.length === 0) {
        throw new Error('الطالب غير موجود');
    }
    
    // 3. تحويل من Buffer إلى Object
    const student = JSON.parse(studentBytes.toString());
    
    // 4. التحقق من الصلاحيات
    const callerOrg = await this._getCallerOrganization(ctx);
    const isMinistry = await this._isMinistry(ctx);
    
    // 5. إخفاء البيانات الحساسة عن الجامعات الأخرى
    if (!isMinistry && student.currentUniversity !== callerOrg) {
        delete student.nationalId;
        delete student.phone;
    }
    
    return student;
}
```

**مبدأ Clean Code المطبق:** 
- Single Responsibility: كل وظيفة تقوم بشيء واحد فقط
- وضوح الأسماء: `getStudent` واضح أكثر من `get`
- التحقق من الأخطاء: نتأكد من وجود البيانات قبل استخدامها

### 2. الخدمات (Services)

**الملف:** `api/src/services/studentService.js`

```javascript
class StudentService {
    async createStudent(studentData, universityId) {
        try {
            // 1. توليد معرف إذا لم يكن موجوداً
            if (!studentData.studentId) {
                studentData.studentId = this._generateStudentId();
            }
            
            // 2. التحقق من صحة البيانات
            this._validateStudentData(studentData);
            
            // 3. تعيين الجامعة
            studentData.currentUniversity = universityId;
            
            // 4. إرسال إلى البلوك تشين
            const result = await fabricNetwork.createStudent(studentData);
            
            return {
                success: true,
                message: 'تم إنشاء الطالب بنجاح',
                data: result
            };
        } catch (error) {
            throw {
                success: false,
                message: error.message,
                error: error
            };
        }
    }
    
    _validateStudentData(student) {
        // التحقق من الحقول المطلوبة
        const requiredFields = [
            'nationalId', 'fullName', 'dateOfBirth',
            'college', 'major', 'enrollmentDate'
        ];
        
        for (const field of requiredFields) {
            if (!student[field]) {
                throw new Error(`الحقل ${field} مطلوب`);
            }
        }
        
        // التحقق من صحة رقم الهوية
        if (!/^\d{10}$/.test(student.nationalId)) {
            throw new Error('رقم الهوية يجب أن يكون 10 أرقام');
        }
        
        // التحقق من صحة البريد الإلكتروني
        if (student.email && !this._isValidEmail(student.email)) {
            throw new Error('صيغة البريد الإلكتروني غير صحيحة');
        }
    }
}
```

**لماذا فصل الـ Service عن الـ Controller؟**
- Controller: يتعامل مع HTTP فقط
- Service: يحتوي على منطق العمل
- سهولة الاختبار: يمكن اختبار Service بدون HTTP
- إعادة الاستخدام: Service يمكن استخدامه من أماكن مختلفة

### 3. المسارات (Routes)

**الملف:** `api/src/routes/index.js`

```javascript
// مثال: مسار إنشاء طالب
router.post(
    '/students',                    // المسار
    authenticate,                   // التحقق من تسجيل الدخول
    authorize('admin', 'registrar'),// التحقق من الصلاحيات
    studentController.createStudent // تنفيذ العملية
);
```

**التسلسل:**
1. طلب POST يصل إلى `/api/students`
2. Middleware `authenticate` يتحقق من JWT token
3. Middleware `authorize` يتحقق من الدور
4. Controller يستقبل الطلب
5. Controller يستدعي Service
6. Service يستدعي Fabric Network
7. يتم الحفظ في البلوك تشين
8. النتيجة ترجع عبر نفس المسار

### 4. المصادقة (Authentication)

**الملف:** `api/src/middleware/auth.js`

```javascript
const authenticate = async (req, res, next) => {
    try {
        // 1. الحصول على الـ token من الـ header
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                message: 'لم يتم تقديم token'
            });
        }
        
        // 2. استخراج الـ token
        const token = authHeader.substring(7);
        
        // 3. التحقق من صحة الـ token
        const decoded = authService.verifyAccessToken(token);
        
        // 4. الحصول على بيانات المستخدم
        const user = authService.getUserById(decoded.userId);
        
        // 5. إرفاق المستخدم بالطلب
        req.user = user;
        
        // 6. المتابعة
        next();
    } catch (error) {
        return res.status(401).json({
            message: 'token غير صحيح أو منتهي الصلاحية'
        });
    }
};
```

**JWT (JSON Web Token):**
- رمز مشفر يحتوي على معلومات المستخدم
- يُرسل مع كل طلب للتحقق من الهوية
- آمن ولا يمكن تزويره

---

## مبادئ Clean Code المطبقة

### 1. أسماء واضحة وذات معنى

**❌ سيء:**
```javascript
function create(d) {
    // ماذا يفعل؟
}
```

**✅ جيد:**
```javascript
function createStudent(studentData) {
    // واضح ومفهوم
}
```

### 2. وظائف صغيرة ومركزة

**مبدأ Single Responsibility:**
```javascript
// كل وظيفة تقوم بشيء واحد فقط

// ❌ سيء: وظيفة تقوم بأشياء كثيرة
function processStudent(data) {
    // validate
    // save to db
    // send email
    // log
}

// ✅ جيد: تقسيم إلى وظائف صغيرة
function validateStudent(data) { }
function saveStudent(data) { }
function sendEmailNotification(email) { }
function logStudentCreation(studentId) { }
```

### 3. DRY (Don't Repeat Yourself)

```javascript
// بدلاً من تكرار التحقق في كل مكان
if (!/^\d{10}$/.test(nationalId)) {
    throw new Error('...');
}

// نستخدم وظيفة مشتركة
function validateNationalId(nationalId) {
    if (!/^\d{10}$/.test(nationalId)) {
        throw new Error('...');
    }
}
```

### 4. معالجة الأخطاء بشكل صحيح

```javascript
try {
    const result = await studentService.createStudent(data);
    res.status(201).json(result);
} catch (error) {
    console.error('خطأ في إنشاء الطالب:', error);
    res.status(400).json({
        success: false,
        message: error.message
    });
}
```

### 5. التعليقات المفيدة

```javascript
// ✅ جيد: شرح "لماذا" وليس "ماذا"
// نقوم بتشفير رقم الهوية لحماية خصوصية الطالب
student.nationalId = this._hashData(student.nationalId);

// ❌ سيء: شرح واضح من الكود نفسه
// تعيين التاريخ الحالي
student.createdAt = new Date().toISOString();
```

### 6. البنية الطبقية (Layered Architecture)

```
Controller  → يتعامل مع HTTP
   ↓
Service     → منطق العمل
   ↓
Repository  → الوصول للبيانات (Blockchain)
```

**فوائد:**
- سهولة الاختبار
- سهولة الصيانة
- إعادة الاستخدام
- فصل المسؤوليات

---

## كيفية التشغيل

### المتطلبات الأساسية

```bash
# Node.js
node --version  # يجب أن يكون >= 18.0.0

# Docker
docker --version
docker-compose --version
```

### خطوات التشغيل

#### 1. تثبيت المكتبات

```bash
# في مجلد الـ API
cd api
npm install

# في مجلد الـ Chaincode
cd ../chaincode/student-records
npm install
```

#### 2. تشغيل شبكة Fabric (مبسطة)

في بيئة حقيقية، ستحتاج إلى:
```bash
cd network
./scripts/network.sh up
./scripts/deployCC.sh
```

**للـ PoC:** يمكنك محاكاة الاستجابات بدون شبكة حقيقية.

#### 3. تشغيل الـ API

```bash
cd api
npm run dev
```

الخادم سيعمل على: `http://localhost:3000`

### اختبار الـ API

```bash
# تسجيل الدخول
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }'

# ستحصل على token، استخدمه في الطلبات القادمة

# إنشاء طالب
curl -X POST http://localhost:3000/api/students \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "nationalId": "1234567890",
    "fullName": "أحمد محمد",
    "dateOfBirth": "2000-01-01",
    "college": "كلية الحاسب",
    "major": "علوم حاسب",
    "enrollmentDate": "2020-09-01"
  }'
```

---

## أمثلة عملية

### سيناريو 1: إنشاء طالب جديد

**الخطوات:**
1. موظف القبول يسجل دخوله
2. يملأ نموذج الطالب الجديد
3. النظام يتحقق من البيانات
4. يُرسل إلى البلوك تشين
5. يُحفظ بشكل دائم

**الكود:**
```javascript
// Frontend
const createStudent = async (studentData) => {
    const response = await fetch('/api/students', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(studentData)
    });
    return response.json();
};

// Backend Controller
async createStudent(req, res) {
    const result = await studentService.createStudent(
        req.body, 
        req.user.universityId
    );
    res.status(201).json(result);
}

// Service
async createStudent(studentData, universityId) {
    this._validateStudentData(studentData);
    return await fabricNetwork.createStudent(studentData);
}

// Smart Contract
await ctx.stub.putState(studentId, studentData);
```

### سيناريو 2: نقل طالب

**الخطوات:**
1. الجامعة المستقبلة تطلب النقل
2. يُرسل طلب إلى الجامعة الأصلية
3. الجامعة الأصلية توافق
4. يُرسل للوزارة للمراجعة
5. الوزارة توافق
6. يتم النقل تلقائياً

**الحالات (States):**
```
pending → approved_by_source → approved_by_ministry → completed
```

---

## نصائح مهمة للتطوير

### 1. ابدأ صغيراً

لا تحاول بناء كل شيء دفعة واحدة:
1. ابدأ بعملية واحدة (مثل: إنشاء طالب)
2. اختبرها جيداً
3. انتقل للعملية التالية

### 2. اختبر باستمرار

```bash
# اختبر كل وظيفة بعد كتابتها
npm test

# اختبر الـ API يدوياً
# استخدم Postman أو curl
```

### 3. استخدم Git

```bash
git add .
git commit -m "أضف وظيفة إنشاء الطالب"
```

### 4. وثق كل شيء

- اكتب تعليقات للوظائف المعقدة
- حدث الـ README
- وثق الـ API

---

## الخلاصة

### ما تعلمته من هذا المشروع

1. **البلوك تشين:**
   - كيف يعمل
   - متى نستخدمه
   - Hyperledger Fabric

2. **Clean Code:**
   - أهمية الأسماء الواضحة
   - Single Responsibility
   - DRY principle

3. **البنية المعمارية:**
   - Layered Architecture
   - Separation of Concerns
   - API Design

4. **الأمان:**
   - JWT Authentication
   - Role-Based Access Control
   - Data Encryption

### النقاط المهمة

- ✅ البلوك تشين ليس الحل لكل شيء
- ✅ Clean Code يوفر الوقت على المدى الطويل
- ✅ التخطيط الجيد أهم من الكود السريع
- ✅ الاختبار ضروري وليس اختيارياً

### الخطوات القادمة

1. إكمال الواجهة الأمامية
2. إضافة المزيد من الاختبارات
3. تحسين الأداء
4. إضافة ميزات جديدة

---

## أسئلة شائعة

### س: لماذا Node.js وليس لغة أخرى؟

**ج:** 
- سريع في التطوير
- JavaScript في Frontend و Backend
- مكتبات Fabric SDK ممتازة
- مجتمع كبير

### س: هل يمكن استخدام قاعدة بيانات عادية بدلاً من البلوك تشين؟

**ج:** 
يمكن، لكن ستفقد:
- عدم قابلية التعديل
- الأمان الموزع
- التدقيق التلقائي
- الثقة بين الأطراف

### س: كم يستغرق تطوير هذا المشروع؟

**ج:**
- PoC بسيط: 2-3 أسابيع
- نظام متكامل: 2-3 أشهر
- نظام production-ready: 6+ أشهر

---

**بالتوفيق في مشروعك! 🚀**
